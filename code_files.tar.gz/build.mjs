// Builds the site into dist/ (what vps-server.mjs serves):
//   static/                      → dist/                    fonts, icons, sign-in, home and admin pages
//   pages-src/<platform>/*.html  → dist/<platform>/*.html   the PC editions' pages with a few exact, checked edits
//   src/*.js                     → dist/assets/             bundled with the unchanged game engines
// Every page edit must match exactly once. If a PC edition's page changes shape, the build stops with a clear
// message instead of shipping a half-patched page.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const here = path.dirname(fileURLToPath(import.meta.url));
const p = (...x) => path.join(here, ...x);
const version = JSON.parse(fs.readFileSync(p('package.json'), 'utf8')).version;

fs.rmSync(p('dist'), { recursive: true, force: true });
fs.cpSync(p('static'), p('dist'), { recursive: true });

function patch(file, html, edits) {
  for (const [what, from, to] of edits) {
    const parts = html.split(from);
    if (parts.length !== 2) throw new Error(`build: "${what}" should match exactly once in ${file}, but matched ${parts.length - 1} times. The page changed; update build.mjs.`);
    html = parts.join(to);
  }
  return html;
}

const icons = fs.readdirSync(p('static', 'icons')).filter(f => f.endsWith('.svg')).map(f => f.slice(0, -4));
const START = ['socket.io script + start of page code', '<script src="/socket.io/socket.io.js"></script>\n<script>\n(() => {', '<script>\nwindow.__arcadeStart = (() => {'];
const end = script => ['end of page code', '})();\n</script>\n</body>', `});\n</script>\n<script src="/assets/${script}.js?v=${version}"></script>\n</body>`];
const KEEP_OPEN = ['keep-it-open tip', "<li><b>Keep the black window open.</b> It's the game server. Closing it stops the games (points are saved).</li>", '<li><b>Keep the overlay open.</b> The games run inside it. Closing it stops the games (coins are saved). In OBS, untick “Shutdown source when not visible” on the browser source.</li>'];
const LOST = ['lost-connection message', "'Lost connection to the app. Is the black window still open?'", "'Waiting for your overlay. The games run inside it: add the overlay link to OBS (or click “Open overlay”) and keep it open.'"];
const OVERLAY_LINK = ['overlay link', "const overlayUrl = location.origin + '/overlay';", 'const overlayUrl = window.ARCADE.overlayUrl;'];
const PREVIEW_LINK = ['overlay preview link', "$('#openOverlay').href = overlayUrl + '?preview';", "$('#openOverlay').href = window.ARCADE.previewUrl;"];

const PAGES = {
  youtube: {
    overlay: [],
    panel: [
      ['direct-mode help', 'but YouTube sometimes answers with a bot check; if that happens, switch to “My own browser”.', 'but YouTube sometimes answers with a bot check; if that happens, paste your live video link instead of the handle.'],
      ['web styles', '</head>', '<style>#modeChips [data-mode="browser"]{display:none}</style>\n</head>'] // no "My own browser" mode on the web
    ]
  },
  tiktok: {
    overlay: [],
    panel: [
      // TikTok LIVE Studio refuses "localhost"; on the web the normal https link works there too.
      ['LIVE Studio link', "let studioUrl = location.protocol + '//localtest.me:' + (location.port || 80) + '/overlay';", 'let studioUrl = window.ARCADE.overlayUrl;'],
      ['LIVE Studio guide', 'paste the <b>TikTok LIVE Studio</b> link from the Dashboard (it starts with <code>http://localtest.me</code>, because LIVE Studio rejects “localhost”). It points straight back to this PC.', 'paste the <b>TikTok LIVE Studio</b> link from the Dashboard.'],
      // The site's server reads the chat with the site's own key: no connection modes or personal key here.
      ['web styles', '</head>', '<style>.row:has(> #modeChips),#modeHelp,details:has(#signKey),details:has(#altUrls){display:none}</style>\n</head>']
    ]
  }
};

for (const [platform, pages] of Object.entries(PAGES)) {
  fs.mkdirSync(p('dist', platform), { recursive: true });
  const overlay = patch(`${platform}/overlay.html`, fs.readFileSync(p('pages-src', platform, 'overlay.html'), 'utf8'), [
    ['icon list', '/*ICON_LIST*/[]', JSON.stringify(icons)], // the PC server fills this in per request
    START, end(`overlay-${platform}`), ...pages.overlay
  ]);
  fs.writeFileSync(p('dist', platform, 'overlay.html'), overlay);
  const panel = patch(`${platform}/panel.html`, fs.readFileSync(p('pages-src', platform, 'panel.html'), 'utf8'), [
    START, end('panel-boot'), OVERLAY_LINK, PREVIEW_LINK, LOST, KEEP_OPEN, ...pages.panel
  ]);
  fs.writeFileSync(p('dist', platform, 'panel.html'), panel);
}

// ---------- scripts ----------
await build({
  entryPoints: {
    'overlay-youtube': p('src', 'overlay-youtube.js'), 'overlay-tiktok': p('src', 'overlay-tiktok.js'),
    'panel-boot': p('src', 'panel-boot.js'), site: p('src', 'site.js'), admin: p('src', 'admin.js')
  },
  outdir: p('dist', 'assets'),
  bundle: true,
  format: 'iife',
  target: ['chrome103'], // OBS 29+ browser sources
  minify: true,
  legalComments: 'none',
  // The engines' Store uses node:fs / node:path; in the browser those are the in-memory stand-ins.
  alias: { 'node:fs': p('src', 'vfs.js'), 'node:path': p('src', 'vpath.js') },
  // engine*/ai.js reads this to find Gemini; on the web it goes through this site's server, which holds the key.
  define: { 'process.env.GEMINI_BASE_URL': '"/api/ai"' },
  logLevel: 'warning'
});

const kb = f => `${(fs.statSync(p('dist', 'assets', `${f}.js`)).size / 1024).toFixed(0)} KB`;
console.log(`Built dist/ for v${version}: overlay-youtube ${kb('overlay-youtube')}, overlay-tiktok ${kb('overlay-tiktok')}, panel-boot ${kb('panel-boot')}, site ${kb('site')}, admin ${kb('admin')}, ${icons.length} icons`);
