# Stream Arcade: web edition for YouTube Live and TikTok LIVE

One website with both sets of chat games (Slots, Gamble, Fishing, Duel, Heist, Boss Raid, Raffle, Tug of War,
Buddy the host bot). A streamer signs in, picks YouTube or TikTok, copies a private overlay link into OBS or
TikTok LIVE Studio, and connects their channel. It runs on your own server (VPS).

**To put it on a server, follow [DEPLOY-VPS.md](DEPLOY-VPS.md).**

The two PC editions are not changed by anything in this folder and keep working on their own.

## Accounts

There is no sign-up. Only an admin creates accounts, in the admin panel (`/admin`).

| Type | Can use | Ends |
|---|---|---|
| **Admin** | Everything, plus the admin panel | Never. The last admin can't be deleted or demoted |
| **Paid** | YouTube and TikTok, all features | Optional paid-until date. After it the account is **locked** (data kept) until an admin extends it |
| **Trial** | YouTube and TikTok, all features | 12 hours after the **first sign-in**, then the account **and all its data are deleted**. A trial nobody signed in to is deleted after 7 days |

- The first admin is created from `ADMIN_USERNAME` / `ADMIN_PASSWORD` in the server's `.env` on the first start.
- Passwords are stored only as scrypt hashes. Five wrong passwords lock an account for 15 minutes.
- Changing or resetting a password signs that account out everywhere.
- An account that is deleted, switched off or out of time is cut off within a minute: its panel returns to the
  sign-in page and its overlay stops with a message.

## How it works

The game engines are the PC editions' own code (`engine/` for YouTube, `engine-tiktok/` for TikTok, unchanged
copies). An engine runs **inside the streamer's overlay page**, so the overlay must stay open while streaming.

| Part | Where it runs |
|---|---|
| Game engine, timers, Buddy | The overlay page (OBS browser source / LIVE Studio link source) |
| Control panel | Any browser, signed in. Talks to the overlay through the server's live channel (`/live`) |
| YouTube chat | The server asks YouTube (`/api/yt/...`), one short request every 1–3 seconds per streamer |
| TikTok chat | The server holds one chat connection per connected TikTok streamer (the PC edition's own bridge) and passes the events to that streamer's overlay |
| Google answers (`!ask`) | The server (`/api/ai/...`), which adds the user's saved Gemini key |
| Accounts, coins, settings | One SQLite file on the server (`arcade.db`). YouTube and TikTok have separate coins and settings per user |

## Try it on your PC

```bash
npm install
```

Create `.env` with `ADMIN_USERNAME=` and `ADMIN_PASSWORD=` lines (see `.env.example`), then:

```bash
npm run dev
```

Open `http://localhost:3000`. It uses port 3000, never the PC editions' ports (4545 / 4546), and keeps its
database in `web/data/`.

## For streamers using the site

- **The overlay must be open for the games to run.** In OBS, leave "Shutdown source when not visible" unticked.
- **Treat the overlay link like a stream key.** If it was shown on stream, click **New overlay link** in the
  control panel: the old links stop at once.
- A second overlay on the same account (a preview tab, or wide + vertical) only displays; one overlay runs the games.
- **Import coins** brings in `data/points.json` from a PC edition, into the platform whose panel you are on.

## What is different from the PC editions

- No "My own browser" connection mode (a server can't open a Chrome window on your PC).
- TikTok uses the signing service (Euler Stream) with **one key for the whole server**, set by the admin. The
  per-streamer key box is hidden.
- The control panel lists the top 1,000 viewers (the PC editions list everyone). All viewers are still saved.
- The Gemini key is saved on the server and shows as `saved-on-server` afterwards.
- The YouTube viewer count is not shown when YouTube doesn't send it.
- A round in progress and cooldowns restart if the overlay is reloaded, as when a PC edition is restarted.

## Limits you should know

- **Not unlimited.** Every streamer's chat is read from your server's one IP address. YouTube and TikTok can
  slow down or block an address that reads many chats. How many streamers one server carries is found by trying.
- **TikTok signing.** The free Euler Stream allowance is small and shared. Several TikTok streamers at once need
  a paid Euler Stream plan.
- Both chat connections use unofficial methods, the same ones the PC editions use. Either platform can change
  or block them.
- Coins are only as trustworthy as the streamer: the engine runs in the streamer's own overlay. One user cannot
  reach another user's data: the server checks every request.

## Files

| Path | What it is |
|---|---|
| `engine/`, `engine-tiktok/`, `pages-src/`, `static/fonts`, `static/icons`, `server/tiktok-bridge/tiktok.js` | Unchanged copies from the PC editions. Don't edit: change the PC edition and run `npm run sync` |
| `src/engine-host.js`, `src/engine-host-tiktok.js` | The web versions of each `server.js`: same handlers and panel commands |
| `src/web-store.js`, `src/vfs.js` | Runs a PC edition's `Store` in the browser and sends changes to the database |
| `src/bus.js`, `src/link.js` | Replace socket.io: overlay ⇄ panel messages, and which overlay runs the engine |
| `src/yt-web-bridge.js`, `shared/yt-core.js`, `server/yt.js` | YouTube chat |
| `src/tt-web-bridge.js`, `server/tiktok.js` | TikTok chat |
| `src/overlay-*.js`, `src/panel-boot.js`, `src/site.js`, `src/admin.js` | Start each page |
| `server/accounts.js`, `server/auth.js`, `server/db.js`, `server/router.js`, `server/hub.js` | Accounts and user types, sessions and hashing, the database, `/api`, the live channel |
| `vps-server.mjs` | The server process |
| `build.mjs` | Builds `dist/`. Stops with a clear message if a PC edition's page changes shape |
| `deploy/`, `DEPLOY-VPS.md` | Service file, Caddy config, deployment guide |
| `test/` | `npm test` |

## Tests

```bash
npm test
```

- **Engine parity (YouTube and TikTok):** one scripted stream is played through the PC edition's `Store` on a
  real folder and through the browser build. Every event, the final coins and everything saved must match.
- **Host coverage (both):** every panel command in each `server.js` exists in the web host, with the same code.
- **Copies (both):** the engines, pages, fonts, icons and TikTok bridge are byte-for-byte the PC editions'.
- **YouTube parser parity:** same handler calls as the PC edition's `handleAction()`.
- **Accounts:** only an admin creates users; user types; trial deleted with its data after its hours; paid
  locked at its date; sessions; users and platforms kept apart; keys never sent to a browser; link rotation.
- **Live channel and TikTok manager:** real WebSockets on a local port, with a stand-in TikTok connection.

The tests that compare against the PC editions are skipped when their folders aren't found.
