# Running Stream Arcade on your PC: step by step

This runs the web edition on your own computer at `http://localhost:3000`, to try it before putting it on a
server. It does not touch the PC editions: it uses port 3000, never 4545 or 4546.

---

## 1. Check Node.js

Open PowerShell and run:

```bash
node --version
```

It must show `v22.13` or higher. If it is older or missing, install the current version from nodejs.org, then
open a new PowerShell window.

## 2. Go to the app folder

```bash
cd "E:\Live Game\YouTube-Live-Chat-Games-v2.2.0\web"
```

## 3. Install (first time only)

```bash
npm install
```

**Check:** it ends without `ERR!` lines.

## 4. Create your admin account settings (first time only)

Skip this step if `web\.env` already exists.

```bash
copy .env.example .env
```

```bash
notepad .env
```

Fill in these two lines and save:

```
ADMIN_USERNAME=your-admin-username
ADMIN_PASSWORD=your-admin-password
```

The admin account is created from these on the first start. Only a hash of the password is kept in the
database.

## 5. Start it

```bash
npm run dev
```

This builds the site and starts the server. **Leave this window open** while you use the app.

**Check:** the window shows `Listening on http://127.0.0.1:3000`. On the very first start it also shows
`Admin account "…" created`.

## 6. Sign in

Open **http://localhost:3000** in your browser and sign in with the admin username and password from step 4.

## 7. Create test users

1. Click **Admin panel**.
2. Create a **Paid** user (the paid-until date is optional).
3. Create a **Trial** user (12 hours from that user's first sign-in, then the account is deleted).
4. Click **Make a password** for each one and write it down: it is shown only once.

## 8. Try YouTube

1. Go back to the home page and open **YouTube Live**.
2. Open the overlay link in another browser tab. In OBS this would be a Browser source.
3. Click **Test overlay**. **Check:** demo cards appear on the overlay.
4. For real chat: paste the link of a YouTube channel that is live right now and click **Connect**.

## 9. Try TikTok

1. From the home page, open **TikTok LIVE**.
2. Open its overlay link in another tab and click **Test overlay**. **Check:** demo cards appear.
3. Real chat needs a TikTok account that is live at that moment.

## 10. Check the account types

1. Open a private browser window and sign in as the trial user. **Check:** the panel shows the time left.
2. In your admin window, disable or delete that user. **Check:** within about a minute the trial user's panel
   goes back to the sign-in page and its overlay stops with a message.

## 11. Run the automated tests (optional)

Stop the server first (step 12), then:

```bash
npm test
```

**Check:** all tests pass.

## 12. Stop it

Press **Ctrl+C** in the window from step 5.

Next time, only steps 2, 5 and 6 are needed. Your accounts and coins are kept in `web\data\arcade.db`.

---

## If something goes wrong

| Problem | What to do |
|---|---|
| PowerShell says `npm.ps1 cannot be loaded because running scripts is disabled` | Type `npm.cmd` instead of `npm` (for example `npm.cmd run dev`), or use Command Prompt (`cmd`) instead of PowerShell |
| `node:sqlite` is unknown | Node is too old. Redo step 1 |
| "No admin account yet" | Fill in `ADMIN_USERNAME` and `ADMIN_PASSWORD` in `.env` (step 4), then start again |
| "Wrong username or password" for the admin | The account is made only on the first start. To set a new password: put it in `ADMIN_PASSWORD`, add the line `ADMIN_PASSWORD_RESET=1`, start once, then remove that line |
| Locked out after wrong passwords | Wait 15 minutes, or reset as above |
| Port 3000 is already in use | Set `PORT=3001` in `.env` (not 4545 or 4546) and open `http://localhost:3001` |
| Start fresh with no accounts | Stop the server, delete the `web\data` folder, start again |
