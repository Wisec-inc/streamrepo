// The parts of the local edition's lib/youtube.js that don't depend on how the chat is fetched.
// parseMoney, parseTarget, normAuthor, roleOf and explainError are copied word for word.
// actionToEvents + applyEvent are handleAction() split in two: the server turns YouTube's chat items into
// small events, and the overlay calls the same handlers with them. test/yt-core.test.mjs checks both halves
// together against the original handleAction().

export class StepTimeout extends Error {}
export function withTimeout(promise, ms, what) {
  let t;
  return Promise.race([
    promise,
    new Promise((_, rej) => { t = setTimeout(() => rej(new StepTimeout(what)), ms); })
  ]).finally(() => clearTimeout(t));
}
export const STEP_TIMEOUT = { setup: 30_000, find: 30_000, chat: 30_000 };

// ---------- money: Super Chat amounts in any currency → approximate US dollars ----------
// Rough rates, good enough for fun points. Unknown currencies fall back to the Super Chat colour tier.
const USD_RATE = {
  USD: 1, EUR: 1.08, GBP: 1.27, CAD: 0.73, AUD: 0.66, NZD: 0.6, CHF: 1.13, JPY: 0.0067, KRW: 0.00073, CNY: 0.14,
  HKD: 0.128, TWD: 0.031, SGD: 0.75, MYR: 0.22, THB: 0.029, PHP: 0.017, IDR: 0.000062, VND: 0.00004, INR: 0.012,
  NPR: 0.0075, PKR: 0.0036, BDT: 0.0084, LKR: 0.0033, AED: 0.27, SAR: 0.27, QAR: 0.27, KWD: 3.25, EGP: 0.02,
  TRY: 0.029, RUB: 0.011, UAH: 0.024, PLN: 0.25, CZK: 0.043, HUF: 0.0027, RON: 0.22, SEK: 0.095, NOK: 0.093,
  DKK: 0.145, ISK: 0.0072, ZAR: 0.055, NGN: 0.00065, KES: 0.0077, BRL: 0.18, MXN: 0.055, ARS: 0.001, CLP: 0.0011,
  COP: 0.00025, PEN: 0.27, ILS: 0.27, BGN: 0.55, HRK: 0.14, RSD: 0.0092
};
const SYMBOLS = [
  ['CA$', 'CAD'], ['A$', 'AUD'], ['NZ$', 'NZD'], ['HK$', 'HKD'], ['NT$', 'TWD'], ['MX$', 'MXN'], ['R$', 'BRL'],
  ['S$', 'SGD'], ['US$', 'USD'], ['₹', 'INR'], ['€', 'EUR'], ['£', 'GBP'], ['¥', 'JPY'], ['₩', 'KRW'], ['₱', 'PHP'],
  ['₫', 'VND'], ['₺', 'TRY'], ['₽', 'RUB'], ['₦', 'NGN'], ['₪', 'ILS'], ['zł', 'PLN'], ['Rp', 'IDR'], ['RM', 'MYR'],
  ['$', 'USD']
];
// YouTube Super Chat colour tiers (header colour, RGB) → lowest US$ value of that tier
const TIER_USD = { '1565c0': 1, '00b8d4': 2, '00bfa5': 5, 'ffb300': 10, 'e65100': 20, 'c2185b': 50, 'd00000': 100, 'e62117': 100 };

export function parseMoney(text, colorInt) {
  const raw = String(text || '').trim();
  let currency = (raw.match(/\b([A-Z]{3})\b/) || [])[1];
  if (!currency) for (const [sym, code] of SYMBOLS) if (raw.includes(sym)) { currency = code; break; }
  let num = raw.replace(/[^\d.,]/g, '');
  if (/,\d{1,2}$/.test(num) && !/\.\d{1,2}$/.test(num)) num = num.replace(/\./g, '').replace(',', '.'); // 10,00 → 10.00
  else num = num.replace(/,/g, '');
  const value = parseFloat(num) || 0;
  let usd = currency && USD_RATE[currency] !== undefined ? value * USD_RATE[currency] : null;
  if (usd === null && Number.isFinite(colorInt)) {
    const hex = (colorInt >>> 0 & 0xffffff).toString(16).padStart(6, '0');
    usd = TIER_USD[hex] ?? null;
  }
  return { text: raw, currency: currency || '?', value, usd: usd ?? 1 };
}

// ---------- input: handle / channel link / video link ----------
export function parseTarget(input) {
  const s = String(input || '').trim();
  const vid = s.match(/(?:[?&]v=|youtu\.be\/|\/live\/|\/shorts\/|\/embed\/)([\w-]{11})/);
  if (vid) return { videoId: vid[1], label: vid[1] };
  const ch = s.match(/youtube\.com\/(channel\/UC[\w-]{22}|@[\w.\-]+|c\/[\w.\-]+|user\/[\w.\-]+)/i);
  if (ch) return { channelUrl: `https://www.youtube.com/${ch[1]}`, label: ch[1].replace(/^channel\//, '') };
  if (/^UC[\w-]{22}$/.test(s)) return { channelUrl: `https://www.youtube.com/channel/${s}`, label: s };
  const handle = s.replace(/^@/, '').replace(/\s+/g, '');
  if (!handle) return null;
  return { channelUrl: `https://www.youtube.com/@${handle}`, label: `@${handle}` };
}

export function normAuthor(a) {
  if (!a) return null;
  const name = String(a.name || '').trim();
  const username = name.replace(/^@/, '') || a.id || '';
  if (!username) return null;
  const thumbs = a.thumbnails || [];
  return {
    username,
    nickname: name.replace(/^@/, '') || username,
    avatar: a.avatar_thumbnail_url || thumbs[0]?.url || '', // first = largest
    channelId: a.id || ''
  };
}

// Live chat marks the channel owner and moderators with badges.
export function roleOf(a) {
  const badges = [...(a?.badges || [])];
  const has = t => badges.some(b => b?.icon_type === t || String(b?.tooltip || '').toUpperCase() === t);
  return { isMod: !!a?.is_moderator || has('MODERATOR'), isHost: !!a?.is_creator || has('OWNER') };
}

export function explainError(err, label) {
  const text = String(err?.message || err || '');
  const all = `${err?.constructor?.name || ''} ${text} ${err?.code || ''} ${err?.cause?.code || ''} ${err?.cause?.message || ''}`;
  if (err instanceof StepTimeout) return { kind: 'timeout', retry: 20_000, message: `YouTube didn't answer in time (${text}). Retrying in 20s.` };
  if (/fetch failed|ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ECONNRESET|ETIMEDOUT|ENETUNREACH|socket hang up|getaddrinfo|network/i.test(all)) {
    return { kind: 'network', retry: 20_000, message: `Can't reach YouTube from this PC (${text}). Check your internet, VPN or firewall. Retrying in 20s.` };
  }
  if (/Live Chat is not available|chat.*(disabled|off)/i.test(all)) {
    return { kind: 'nochat', retry: 60_000, message: 'This live stream has chat turned off. Turn chat on in YouTube Studio (Live chat → On). Retrying in 60s.' };
  }
  if (/not found|404|Failed to resolve URL|doesn't exist|does not exist/i.test(all)) {
    return { kind: 'notfound', retry: 60_000, message: `Couldn't find the channel ${label}. Check the handle or paste your channel or live video link. Retrying in 60s.` };
  }
  if (/sign in|confirm you.?re not a bot|429|too many/i.test(all)) {
    return { kind: 'blocked', retry: 120_000, message: 'YouTube is asking for a bot check right now. Paste your live video link instead of the handle, or wait; retrying in 2 min.' };
  }
  return { kind: 'other', retry: 20_000, message: `Couldn't connect: ${text}. Retrying in 20s.` };
}

// ---------- one chat action → events (server side; `action` is a parsed youtubei.js node) ----------
// connectedAt: when the overlay joined the chat; older messages are ignored, as in the local edition.
export function actionToEvents(action, connectedAt) {
  if (action?.type !== 'AddChatItemAction') return [];
  const item = action.item;
  if (!item) return [];
  const ts = Number(item.timestamp) || (Number(item.timestamp_usec) / 1000) || Date.now();
  if (connectedAt && ts < connectedAt - 15_000) return []; // ignore old messages
  const text = item.message?.toString?.() || '';

  switch (item.type) {
    case 'LiveChatTextMessage': {
      const u = normAuthor(item.author);
      if (!u) return [];
      return [{ t: 'chat', u, text, role: roleOf(item.author) }];
    }
    case 'LiveChatPaidMessage':
    case 'LiveChatPaidSticker': {
      const u = normAuthor(item.author);
      if (!u) return [];
      const money = parseMoney(item.purchase_amount, item.header_background_color ?? item.money_chip_background_color);
      return [{ t: 'superchat', u, m: { ...money, sticker: item.type === 'LiveChatPaidSticker', message: text }, text, role: roleOf(item.author) }];
    }
    case 'LiveChatMembershipItem': {
      const u = normAuthor(item.author);
      if (!u) return [];
      const milestone = item.header_primary_text?.toString?.() || '';
      if (milestone && /\d/.test(milestone)) return [{ t: 'milestone', u, text: milestone }];
      return [{ t: 'member', u }];
    }
    case 'LiveChatSponsorshipsGiftPurchaseAnnouncement': {
      const hd = item.header;
      const name = hd?.author_name?.toString?.() || '';
      const u = normAuthor({ name, id: item.author_external_channel_id, thumbnails: hd?.author_photo || [] });
      if (!u) return [];
      const count = Number((hd?.primary_text?.toString?.() || '').match(/\d+/)?.[0]) || 1;
      return [{ t: 'gifts', u, count }];
    }
    case 'LiveChatSponsorshipsGiftRedemptionAnnouncement': {
      const u = normAuthor(item.author);
      return u ? [{ t: 'member', u }] : [];
    }
    default:
      return [];
  }
}

// ---------- one event → the same handler calls as handleAction() (overlay side) ----------
// h: { chat, join, member, milestone, superchat, giftMemberships }   seen: Set of usernames already welcomed
export function applyEvent(ev, h, seen) {
  const first = u => {
    if (seen.has(u.username)) return;
    seen.add(u.username);
    h.join?.(u); // YouTube doesn't report viewers joining, so we welcome on their first message
  };
  switch (ev.t) {
    case 'chat':
      first(ev.u);
      h.chat(ev.u, ev.text, [], ev.role);
      return;
    case 'superchat':
      first(ev.u);
      h.superchat(ev.u, ev.m);
      if (ev.text) h.chat(ev.u, ev.text, [], ev.role);
      return;
    case 'milestone':
      h.milestone?.(ev.u, ev.text);
      return;
    case 'member':
      h.member(ev.u);
      return;
    case 'gifts':
      h.giftMemberships(ev.u, ev.count);
      return;
  }
}
