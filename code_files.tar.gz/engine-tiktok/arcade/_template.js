// TEMPLATE: how to add a new game. Copy this file, rename it, then:
//   1. Solo game → add it to SOLO_GAMES in solo.js.  Group game → add it to GROUP_GAMES in group.js.
//   2. Add its settings under `games.<id>` in lib/defaults.js (at least { enabled: true }).
//   3. Restart the app. !help <id> and !odds <id> work automatically from guide() and odds().
// The overlay shows any unknown game with a simple generic card; add a drawing for it in public/overlay.html if you like.
import { rand, fmt } from './index.js';

// ---- a SOLO game: plays instantly when someone types the command ----
export const coinflip = {
  id: 'coinflip', name: 'Coin Flip', emoji: '🪙', commands: ['flip'],
  guide: a => [`Type !flip (bets ${fmt(a.eco.defaultBet)}) or !flip 500`, 'Heads you double it', 'Tails you lose it'],
  odds: () => ['Heads: 48% · pays ×2', 'Tails: 52%', 'Pays back 96%'],
  play(a, u, args) {
    const p = a.parseBet(u, args[0], a.cfg.games.coinflip); // handles default bet, "all", "half", shields and limits
    if (p.error) return a.error(u, p.error);
    a.addBet(u, p.bet); // feeds the community jackpot
    const heads = rand(1, 100) <= 48;
    const change = heads ? a.win(u, p.bet) : -a.lose(u, p.bet); // win() applies boosts, lose() respects the beginner shield
    a.result('coinflip', u, { bet: p.bet, change, heads }); // shows a result card (busy chat is handled for you)
  }
};

// ---- a GROUP game: runs as a round (picker → how to play → play → results) ----
export const crowd = {
  id: 'crowd', name: 'Crowd Count', emoji: '📣', commands: ['cheer'],
  hint: () => 'Type !cheer or tap the screen',
  guide: () => ['Type !cheer or tap', 'Reach 100 cheers together', 'Everyone who cheered gets 50'],
  odds: () => ['Free', 'Team goal: 100 cheers'],
  create: a => ({
    cheers: 0, people: new Map(), dirty: false,
    start(now) { this.endsAt = now + 30_000; this.dirty = true; },
    command(u) { this.people.set(a.key(u.username), u); this.cheers++; this.dirty = true; return true; },
    word() {}, chat() {},
    tap(u) { this.command(u); },
    tick(now) {
      if (now < this.endsAt) return null; // return a result object to finish the round
      if (!this.people.size) return { empty: true };
      const won = this.cheers >= 100;
      const players = [...this.people.values()].map(u => ({ ...a.pub(u), change: won ? a.win(u, 50) : 0 }));
      return { won, players, loot: players.reduce((s, x) => s + x.change, 0) };
    },
    view() { return { endsAt: this.endsAt, count: this.people.size, cheers: this.cheers, hint: 'Type !cheer or tap the screen' }; }
  })
};
