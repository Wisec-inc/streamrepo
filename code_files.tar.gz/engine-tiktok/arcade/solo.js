// Solo games: always open, one word to play. Each game is its own module:
//   { id, name, emoji, commands, guide(a) -> 3 steps, odds(a) -> lines, play(a, user, args, mentions) }
// `a` is the Arcade engine (wallet, settings, overlay events). See _template.js to add a new game.
import { rand, pick, fmt } from './index.js';

const pct = x => (x * 100 >= 10 ? (x * 100).toFixed(1) : (x * 100).toFixed(2)) + '%';

// ---------- SLOTS ----------
function slotMath(g) {
  const reel = g.reel.filter(r => r && r.symbol && r.weight > 0);
  const total = reel.reduce((s, r) => s + Number(r.weight), 0);
  const p = reel.map(r => r.weight / total);
  const triple = reel.map((r, i) => ({ symbol: r.symbol, pays: Number(r.pays), chance: p[i] ** 3 }));
  const pair = 3 * p.reduce((s, x) => s + x * x * (1 - x), 0);
  const back = triple.reduce((s, t) => s + t.chance * t.pays, 0) + pair * g.pairMultiplier;
  return { reel, total, triple, pair, back };
}

export const slots = {
  id: 'slots', name: 'Slots', emoji: '🎰', commands: ['slots'],
  guide: a => [`Type !slots (bets ${fmt(a.eco.defaultBet)}) or !slots 500 / all / half`, `Three the same pays ×4 to ×50 · any pair pays ×${a.cfg.games.slots.pairMultiplier}`, '7-7-7 also wins the community JACKPOT'],
  odds: a => {
    const m = slotMath(a.cfg.games.slots);
    return [
      `Any pair (×${a.cfg.games.slots.pairMultiplier}): ${pct(m.pair)}`,
      ...m.triple.map(t => `${t.symbol}${t.symbol}${t.symbol} (×${t.pays}): ${t.chance < 0.001 ? '1 in ' + fmt(1 / t.chance) : pct(t.chance)}`),
      `Pays back about ${Math.round(m.back * 100)}% plus the jackpot`
    ];
  },
  play(a, u, args) {
    const g = a.cfg.games.slots;
    const p = a.parseBet(u, args[0], g);
    if (p.error) return a.error(u, `!slots: ${p.error}`);
    const { reel, total } = slotMath(g);
    const spin = () => {
      let r = Math.random() * total;
      for (const x of reel) { r -= x.weight; if (r <= 0) return x; }
      return reel[reel.length - 1];
    };
    const got = [spin(), spin(), spin()];
    const [s1, s2, s3] = got.map(x => x.symbol);
    a.addBet(u, p.bet);
    let multiplier = 0;
    if (s1 === s2 && s2 === s3) multiplier = Number(got[0].pays);
    else if (s1 === s2 || s2 === s3 || s1 === s3) multiplier = g.pairMultiplier;

    let change, jackpot = 0, shielded = false;
    if (multiplier > 1) {
      change = a.win(u, Math.floor(p.bet * multiplier) - p.bet);
      if (multiplier === Number(got[0].pays) && s1 === s2 && s2 === s3 && String(s1).startsWith('7') && !a.isUnlimited(u.username)) {
        jackpot = Math.floor(a.store.state.jackpot);
        a.give(u, jackpot);
        a.store.state.jackpot = a.eco.jackpotStart;
        a.store.saveStateSoon();
        change += jackpot;
        a.log(`🎰 JACKPOT! ${u.username} hit 7-7-7 and won ${fmt(jackpot)}`);
      }
    } else {
      const lost = a.lose(u, p.bet - Math.floor(p.bet * multiplier));
      shielded = lost === 0 && !a.isUnlimited(u.username);
      change = -lost;
    }
    a.result('slots', u, { bet: p.bet, reels: [s1, s2, s3], symbols: reel.map(r => r.symbol), multiplier, change, jackpot, shielded });
  }
};

// ---------- GAMBLE ----------
export const gamble = {
  id: 'gamble', name: 'Gamble', emoji: '🎲', commands: ['gamble'],
  guide: a => [`Type !gamble (bets ${fmt(a.eco.defaultBet)}) or !gamble 500 / all / half`, 'A number from 1 to 100 rolls', `${a.cfg.games.gamble.winFrom} or more doubles your bet · ${a.cfg.games.gamble.tripleFrom} or more triples it`],
  odds: a => {
    const g = a.cfg.games.gamble;
    const dbl = Math.max(0, g.tripleFrom - g.winFrom) / 100, tri = Math.max(0, 101 - g.tripleFrom) / 100;
    return [`Double (roll ${g.winFrom}-${g.tripleFrom - 1}): ${pct(dbl)}`, `Triple (roll ${g.tripleFrom}+): ${pct(tri)}`, `Lose (roll 1-${g.winFrom - 1}): ${pct(1 - dbl - tri)}`, `Pays back ${Math.round((dbl * 2 + tri * 3) * 100)}%`];
  },
  play(a, u, args) {
    const g = a.cfg.games.gamble;
    const p = a.parseBet(u, args[0], g);
    if (p.error) return a.error(u, `!gamble: ${p.error}`);
    a.addBet(u, p.bet);
    const roll = rand(1, 100);
    const multiplier = roll >= g.tripleFrom ? 3 : roll >= g.winFrom ? 2 : 0;
    let change, shielded = false;
    if (multiplier) change = a.win(u, p.bet * (multiplier - 1));
    else {
      const lost = a.lose(u, p.bet);
      shielded = lost === 0 && !a.isUnlimited(u.username);
      change = -lost;
    }
    a.result('gamble', u, { bet: p.bet, roll, multiplier, change, shielded, winFrom: g.winFrom, tripleFrom: g.tripleFrom });
  }
};

// ---------- FISHING ----------
export const fish = {
  id: 'fish', name: 'Fishing', emoji: '🎣', commands: ['fish'], ownCooldown: true,
  guide: a => ['Type !fish — it is free', `One cast every ${Math.round(a.cfg.games.fish.cooldownSec / 60)} minutes`, 'Rarer fish pay more: Junk → Common → Rare → Epic → Legendary → Mythic'],
  odds: a => {
    const c = a.cfg.games.fish.catches;
    const total = c.reduce((s, x) => s + Number(x.chance), 0);
    return c.map(x => `${x.emoji} ${x.tier} (${fmt(x.coins)}): ${pct(x.chance / total)}`);
  },
  play(a, u) {
    const g = a.cfg.games.fish;
    const wait = g.cooldownSec * 1000 - (Date.now() - (u.fishAt || 0));
    if (wait > 0) return a.toast(`${u.nickname}: the fish need ${wait > 60_000 ? Math.ceil(wait / 60_000) + ' min' : Math.ceil(wait / 1000) + 's'} to come back 🎣`);
    u.fishAt = Date.now();
    const table = g.catches.filter(x => x.chance > 0);
    const total = table.reduce((s, x) => s + Number(x.chance), 0);
    let r = Math.random() * total, index = table.length - 1;
    for (let i = 0; i < table.length; i++) { r -= table[i].chance; if (r <= 0) { index = i; break; } }
    const c = table[index];
    const name = pick(String(c.names || c.tier).split(',').map(x => x.trim()).filter(Boolean));
    u.fish = u.fish || {};
    u.fish[c.tier] = (u.fish[c.tier] || 0) + 1;
    const change = a.win(u, Number(c.coins) || 0);
    const caught = Object.values(u.fish).reduce((s, n) => s + n, 0);
    a.result('fish', u, { change, fish: { tier: c.tier, level: index, name, emoji: c.emoji, coins: c.coins, count: u.fish[c.tier] }, caught, always: index >= 3 });
  }
};

// ---------- DUEL ----------
const record = (x, y, a) => {
  const w = x.rivals?.[a.key(y.username)] || 0, l = y.rivals?.[a.key(x.username)] || 0;
  return { w, l };
};

export const duel = {
  id: 'duel', name: 'Duel', emoji: '⚔️', commands: ['duel'],
  guide: a => [`Type !duel @name (bets ${fmt(a.eco.defaultBet)}) or !duel @name 500`, 'They type !accept or !decline', 'A coin flips: the winner takes both bets'],
  odds: () => ['Coin flip: 50% each', 'Winner takes both bets', 'Pays back 100%'],
  play(a, u, args, mentions) {
    const g = a.cfg.games.duel;
    const { targetArg, amountArg } = a.targetAndAmount(args);
    const t = a.resolveTarget(targetArg, mentions, { seenOnly: true });
    if (!t) return a.error(u, targetArg ? `!duel: can't find ${String(targetArg).replace(/^@?/, '@')} · they need to chat first` : '!duel: who? Use !duel @name');
    const uk = a.key(u.username), tk = a.key(t.username);
    if (uk === tk) return a.error(u, "You can't duel yourself 😅");
    if (t.banned) return a.error(u, `${t.nickname} can't play right now`);
    const p = a.parseBet(u, amountArg, g);
    if (p.error) return a.error(u, `!duel: ${p.error}`);
    if (!a.isUnlimited(tk) && t.points < p.bet) return a.error(u, `${t.nickname} only has ${fmt(t.points)} ${a.cur}`);
    if (a.duels.has(tk)) return a.error(u, `${t.nickname} already has a duel waiting`);
    for (const d of a.duels.values()) if (d.a === uk) return a.error(u, 'You already have a duel waiting');
    const d = { a: uk, b: tk, bet: p.bet, endsAt: Date.now() + g.acceptSeconds * 1000 };
    a.duels.set(tk, d);
    const r = record(u, t, a);
    a.emit('duel', { phase: 'challenge', a: a.pub(u), b: a.pub(t), bet: p.bet, endsAt: d.endsAt, rivalry: r.w + r.l ? `${r.w}-${r.l}` : '', currency: a.cur });
  },
  answer(a, u, accept) {
    const tk = a.key(u.username);
    const d = a.duels.get(tk);
    if (!d) return a.toast(`${u.nickname}: nobody has challenged you to a duel right now`);
    a.duels.delete(tk);
    const x = a.store.get(d.a), y = a.store.get(d.b);
    if (!x || !y) return;
    if (!accept) return a.emit('duel', { phase: 'declined', a: a.pub(x), b: a.pub(y), bet: d.bet });
    const short = p => !a.isUnlimited(p.username) && p.points < d.bet;
    if (short(x) || short(y)) return a.emit('duel', { phase: 'cancelled', a: a.pub(x), b: a.pub(y), bet: d.bet, reason: `${(short(x) ? x : y).nickname} doesn't have enough ${a.cur} anymore` });
    a.addBet(x, d.bet);
    a.addBet(y, d.bet);
    const xWins = Math.random() < 0.5;
    const w = xWins ? x : y, l = xWins ? y : x;
    const change = a.win(w, d.bet);
    a.lose(l, d.bet);
    w.rivals = w.rivals || {};
    w.rivals[a.key(l.username)] = (w.rivals[a.key(l.username)] || 0) + 1;
    const r = record(w, l, a);
    a.log(`⚔️ Duel: ${w.username} beat ${l.username} for ${d.bet} (rivalry ${r.w}-${r.l})`);
    a.emit('duel', { phase: 'result', a: a.pub(x), b: a.pub(y), winner: a.pub(w), loser: a.pub(l), bet: d.bet, change, rivalry: `${r.w}-${r.l}`, currency: a.cur });
  },
  expired(a, d) {
    const x = a.store.get(d.a), y = a.store.get(d.b);
    if (x && y) a.emit('duel', { phase: 'expired', a: a.pub(x), b: a.pub(y), bet: d.bet });
  }
};

export const SOLO_GAMES = [slots, gamble, fish, duel];
