// Staff commands (streamer + mods). Every action is written to data/staff-log.jsonl.
// Actions that touch many players wait for !confirm, and the last coin change can be undone with !undo (10 min).
import { fmt } from './index.js';

const DAY_KEY = () => new Date().toISOString().slice(0, 10);
const UNDO_MS = 10 * 60_000;
const CONFIRM_MS = 60_000;

function duration(raw, fallbackMin = 10) {
  const m = String(raw || '').toLowerCase().match(/^(\d+(?:\.\d+)?)(s|m|h)?$/);
  if (!m) return fallbackMin * 60_000;
  const n = parseFloat(m[1]);
  return Math.round(n * (m[2] === 's' ? 1000 : m[2] === 'h' ? 3_600_000 : 60_000));
}
const human = ms => (ms >= 3_600_000 ? `${+(ms / 3_600_000).toFixed(1)}h` : ms >= 60_000 ? `${Math.round(ms / 60_000)} min` : `${Math.round(ms / 1000)}s`);

// Picks the players a group action applies to. Returns { users, label } or { error }.
function selectGroup(a, words) {
  const all = Object.values(a.store.users).filter(u => !a.isUnlimited(u.username) && !u.banned);
  const [what, x] = words;
  switch (what) {
    case 'all': return { users: all, label: 'everyone' };
    case 'new': return { users: all.filter(u => a.isRookie(u)), label: `new players (first ${a.eco.rookieDays} days)` };
    case 'active': {
      const keys = new Set(a.activeChatters(10 * 60_000));
      return { users: all.filter(u => keys.has(a.key(u.username))), label: 'players who chatted in the last 10 min' };
    }
    case 'below': case 'above': {
      const n = a.parseAmount(x, 0);
      if (!Number.isFinite(n)) return { error: `Use e.g. !give ${what} 1000 200` };
      return { users: all.filter(u => (what === 'below' ? u.points < n : u.points > n)), label: `players ${what} ${fmt(n)}`, used: 2 };
    }
    case 'rank': {
      const m = String(x || '').match(/^#?(\d+)-#?(\d+)$/);
      if (!m) return { error: 'Use e.g. !give rank 50-500 100 (leaderboard places 50 to 500)' };
      const from = +m[1], to = +m[2];
      const list = a.store.top(1e7).slice(Math.max(0, from - 1), to).map(t => a.store.get(t.username)).filter(Boolean);
      return { users: list, label: `leaderboard places ${from}-${to}`, used: 2 };
    }
  }
  return null;
}

function remember(a, label, users) {
  a.undo = { label, at: Date.now(), before: Object.fromEntries(users.map(u => [a.key(u.username), u.points])) };
}

function confirmLater(a, u, text, run) {
  a.pending.set(a.key(u.username), { text, run, until: Date.now() + CONFIRM_MS });
  a.info('⚠️', 'Type !confirm', `${text} · ${u.nickname}, type !confirm within 60s (or ignore to cancel)`, { staff: true });
}

export function handleStaff(a, u, cmd, args, mentions) {
  const k = a.key(u.username);
  const streamer = a.isStreamer(k);
  const mod = a.isMod(k);
  if (!streamer && !mod) return false;
  const deny = what => { a.toast(`${u.nickname}: only the streamer can ${what}`); return true; };
  const done = (title, text, icon = '🛡️') => { a.staffLog(u, `${title}: ${text}`); a.info(icon, title, text, { staff: true }); return true; };
  const g = a.cfg.games;

  switch (cmd) {
    // ---------- coins for one player ----------
    case 'donate': {
      if (!a.canDonate(k)) return deny('donate');
      const { targetArg, amountArg } = a.targetAndAmount(args);
      const t = a.resolveTarget(targetArg, mentions);
      const amount = a.parseAmount(amountArg ?? '', 0);
      if (!t || !Number.isFinite(amount) || amount <= 0) { a.toast('Use !donate @name 500'); return true; }
      if (a.cfg.staff.donateMax > 0 && amount > a.cfg.staff.donateMax) { a.toast(`Max donation is ${fmt(a.cfg.staff.donateMax)}`); return true; }
      if (!streamer && a.cfg.staff.modDailyCap > 0) {
        const st = a.store.state;
        if (!st.modGiven || st.modGiven.day !== DAY_KEY()) st.modGiven = { day: DAY_KEY(), by: {} };
        const used = st.modGiven.by[k] || 0;
        if (used + amount > a.cfg.staff.modDailyCap) { a.toast(`${u.nickname}: mods can give ${fmt(a.cfg.staff.modDailyCap)} a day · ${fmt(Math.max(0, a.cfg.staff.modDailyCap - used))} left today`); return true; }
        st.modGiven.by[k] = used + amount;
        a.store.saveStateSoon();
      }
      remember(a, `donate ${amount} to ${t.username}`, [t]);
      a.give(t, amount);
      a.staffLog(u, `donate ${amount} to ${t.username}`);
      a.emit('card', { kind: 'give', tier: amount >= a.eco.bigWinAt ? 'big' : 'small', user: a.pub(t), title: `🎁 ${t.nickname} got ${fmt(amount)} ${a.cur}`, text: `Gift from ${u.nickname}` });
      return true;
    }
    case 'take': {
      if (!streamer && !a.cfg.staff.modsCanTake) return deny('take coins');
      if (args[0] === 'above' || args[0] === 'below') {
        if (!streamer) return deny('take from groups');
        const sel = selectGroup(a, args);
        if (sel?.error) { a.toast(sel.error); return true; }
        const raw = args[2] || '';
        const pctMatch = raw.match(/^(\d+(?:\.\d+)?)%$/);
        if (!pctMatch) { a.toast('Use a percent, e.g. !take above 100000 5%'); return true; }
        const p = Math.min(parseFloat(pctMatch[1]), a.cfg.staff.takeMaxPercent);
        confirmLater(a, u, `Take ${p}% from ${sel.users.length} players: ${sel.label}`, () => {
          remember(a, `take ${p}% from ${sel.label}`, sel.users);
          let total = 0;
          for (const x of sel.users) { const n = Math.floor((x.points * p) / 100); a.store.add(x.username, -n); total += n; }
          return done('Coins taken', `${p}% from ${sel.users.length} players: ${sel.label} (${fmt(total)} total)`);
        });
        return true;
      }
      const { targetArg, amountArg } = a.targetAndAmount(args);
      const t = a.resolveTarget(targetArg, mentions);
      if (!t || !amountArg) { a.toast('Use !take @name 500 or !take @name 50%'); return true; }
      const n = Math.min(t.points, a.parseAmount(amountArg, t.points));
      if (!Number.isFinite(n) || n <= 0) { a.toast('Use !take @name 500 or !take @name 50%'); return true; }
      remember(a, `take ${n} from ${t.username}`, [t]);
      a.store.add(t.username, -n);
      a.stateSoon();
      return done('Coins taken', `${fmt(n)} from ${t.nickname} · now ${fmt(t.points)}`);
    }
    case 'set': {
      if (!streamer) return deny('set balances');
      const { targetArg, amountArg } = a.targetAndAmount(args);
      const t = a.resolveTarget(targetArg, mentions);
      const n = a.parseAmount(amountArg ?? '', 0);
      if (!t || !Number.isFinite(n)) { a.toast('Use !set @name 500'); return true; }
      remember(a, `set ${t.username} to ${n}`, [t]);
      a.store.set(t.username, n);
      a.stateSoon();
      return done('Balance set', `${t.nickname} → ${fmt(n)} ${a.cur}`);
    }
    case 'reset': {
      if (!streamer) return deny('reset balances');
      const t = a.resolveTarget(args[0], mentions);
      if (!t) { a.toast('Use !reset @name'); return true; }
      remember(a, `reset ${t.username}`, [t]);
      a.store.set(t.username, a.cfg.startingPoints);
      a.stateSoon();
      return done('Balance reset', `${t.nickname} → ${fmt(a.cfg.startingPoints)} ${a.cur}`);
    }
    case 'give': {
      const sel = selectGroup(a, args);
      if (!sel) return false; // normal !give @name 100 (the streamer's is free)
      if (!streamer) return deny('give to groups');
      if (sel.error) { a.toast(sel.error); return true; }
      const amount = a.parseAmount(args[sel.used || 1] ?? '', 0);
      if (!Number.isFinite(amount) || amount <= 0) { a.toast(`Add an amount, e.g. !give ${args.slice(0, sel.used || 1).join(' ')} 100`); return true; }
      if (!sel.users.length) { a.toast(`Nobody matches: ${sel.label}`); return true; }
      const run = () => {
        remember(a, `give ${amount} to ${sel.label}`, sel.users);
        for (const x of sel.users) a.give(x, amount);
        a.emit('card', { kind: 'give', tier: 'big', icon: '🎁', title: `${fmt(amount)} ${a.cur} for ${sel.users.length} players!`, text: `${sel.label} · from ${u.nickname}` });
        a.staffLog(u, `give ${amount} to ${sel.users.length} players (${sel.label})`);
        return true;
      };
      if (sel.users.length > 1) confirmLater(a, u, `Give ${fmt(amount)} to ${sel.users.length} players: ${sel.label} (${fmt(amount * sel.users.length)} total)`, run);
      else run();
      return true;
    }
    case 'confirm': {
      const p = a.pending.get(k);
      a.pending.delete(k);
      if (!p || Date.now() > p.until) { a.toast('Nothing waiting for !confirm'); return true; }
      p.run();
      return true;
    }
    case 'undo': {
      if (!streamer) return deny('undo');
      const x = a.undo;
      if (!x || Date.now() - x.at > UNDO_MS) { a.toast('Nothing to undo (only the last coin change, within 10 min)'); return true; }
      a.undo = null;
      for (const [key, pts] of Object.entries(x.before)) if (a.store.get(key)) a.store.set(key, pts);
      a.stateSoon();
      return done('Undone', `${x.label} (${Object.keys(x.before).length} player${Object.keys(x.before).length === 1 ? '' : 's'} restored)`, '↩️');
    }

    // ---------- fun ----------
    case 'coinrain': case 'rain': {
      if (a.rain) { a.toast('A coin rain is already falling'); return true; }
      const n = a.parseAmount(args[0] || a.eco.rainAmount, 0);
      a.startRain(Number.isFinite(n) && n > 0 ? n : a.eco.rainAmount, `${u.nickname} made it rain`);
      a.staffLog(u, `coin rain ${n}`);
      return true;
    }
    case '2x': case '3x': case 'mult': case 'boost': {
      if (String(args[0]).toLowerCase() === 'off') args = ['1', 'off'];
      let mult = cmd === '2x' ? 2 : cmd === '3x' ? 3 : parseFloat(args.shift());
      if (!Number.isFinite(mult) || mult < 1 || mult > 10) { a.toast('Use !2x 10m, !3x 5m or !mult 5 10m (1-10×)'); return true; }
      if (mult === 1 || args[0] === 'off') { a.store.state.boost = null; a.store.saveStateSoon(); a.stateSoon(); return done('Boost off', 'Winnings are back to normal', '⏱️'); }
      const ms = Math.min(duration(args[0]), 3 * 3_600_000);
      a.store.state.boost = { mult, until: Date.now() + ms, by: u.nickname };
      a.store.saveStateSoon();
      a.stateSoon();
      a.staffLog(u, `${mult}x boost for ${human(ms)}`);
      a.emit('card', { kind: 'boost', tier: 'big', icon: '🔥', title: `${mult}× WIN BOOST`, text: `Every win pays ${mult}× for ${human(ms)}!` });
      return true;
    }

    // ---------- game control ----------
    case 'start': {
      const id = a.findGame(args[0])?.id;
      if (!id || !a.group[id]) { a.toast('Use !start heist, raid, raffle or tug'); return true; }
      if (a.paused) { a.toast('Games are paused · type !resume first'); return true; }
      if (!g[id].enabled) { g[id].enabled = true; a.configChanged(); } // starting a switched-off game switches it back on
      if (a.rounds.phase !== 'idle') a.rounds.skip(`${u.nickname} started ${a.group[id].name}`);
      a.rounds.start(id);
      a.staffLog(u, `start ${id}`);
      return true;
    }
    case 'skip': {
      if (!a.rounds.skip(`skipped by ${u.nickname}`)) { a.toast('No group game is running'); return true; }
      a.staffLog(u, 'skip');
      return true;
    }
    case 'mode': {
      const v = String(args[0] || '').toLowerCase();
      const id = v === 'auto' || v === 'random' ? 'auto' : a.findGame(v)?.id;
      if (!id || (id !== 'auto' && !a.group[id])) { a.toast('Use !mode auto or !mode heist / raid / raffle / tug'); return true; }
      a.cfg.rounds.mode = id;
      if (id !== 'auto' && !g[id].enabled) g[id].enabled = true;
      a.configChanged();
      return done('Game mode', id === 'auto' ? 'Random group games' : `Only ${a.group[id].name} from now on`, '🎮');
    }
    case 'game': {
      const gm = a.findGame(args[0]);
      const on = String(args[1] || '').toLowerCase();
      if (!gm || !['on', 'off'].includes(on)) { a.toast('Use !game slots on / !game heist off'); return true; }
      g[gm.id].enabled = on === 'on';
      a.configChanged();
      if (on === 'off' && a.rounds.game?.id === gm.id) a.rounds.skip(`${gm.name} switched off`);
      return done(`${gm.name} ${on}`, on === 'on' ? 'Ready to play' : 'Switched off for now', gm.emoji);
    }
    case 'pausegames': case 'pause': {
      a.paused = true;
      a.rounds.skip('Games paused for a moment'); // nothing was charged yet, so stopping the round costs nobody anything
      a.stateSoon();
      return done('Games paused', 'Back in a moment', '⏸️');
    }
    case 'resume': case 'resumegames': {
      a.paused = false;
      a.rounds.nextAt = Date.now() + a.cfg.rounds.gapSeconds * 500;
      a.stateSoon();
      return done('Games are back', 'Play now: !slots !gamble !fish', '▶️');
    }
    case 'autopilot': {
      const on = String(args[0] || '').toLowerCase();
      if (!['on', 'off'].includes(on)) { a.toast('Use !autopilot on / off'); return true; }
      a.cfg.rounds.autopilot = on === 'on';
      if (on === 'on') a.rounds.nextAt = Date.now() + 10_000;
      a.configChanged();
      return done(`Autopilot ${on}`, on === 'on' ? 'Group games start on their own' : 'Group games only when staff type !start', '🤖');
    }
    case 'theme': case 'compact':
      a.toast(`!${cmd} arrives with the next update (Stage 2)`);
      return true;
    case 'gameban': case 'ungameban': {
      const t = a.resolveTarget(args[0], mentions);
      if (!t) { a.toast(`Use !${cmd} @name`); return true; }
      if (a.isStaff(t.username)) { a.toast("Staff can't be game-banned"); return true; }
      t.banned = cmd === 'gameban';
      a.store.savePointsSoon();
      return done(t.banned ? 'Game ban' : 'Game ban lifted', `${t.nickname} ${t.banned ? "can't play games now" : 'can play again'}`, t.banned ? '🚫' : '✅');
    }
    case 'resetseason': {
      if (!streamer) return deny('reset the season');
      const top = a.store.top(3);
      confirmLater(a, u, `NEW SEASON: everyone goes back to ${fmt(a.cfg.startingPoints)} ${a.cur}, top 3 keep a badge`, () => {
        const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        a.store.writeBackup(`season-backup-${stamp}.json`, a.store.users);
        const medals = ['🥇', '🥈', '🥉'];
        top.forEach((t, i) => { const x = a.store.get(t.username); if (x) x.badge = `${medals[i]} Season champ`; });
        for (const x of Object.values(a.store.users)) x.points = a.cfg.startingPoints;
        a.store.state.jackpot = a.eco.jackpotStart;
        a.store.state.heistLevel = 1;
        a.undo = null;
        a.store.savePointsNow();
        a.stateSoon();
        a.emit('card', { kind: 'season', tier: 'big', icon: '🏆', title: 'NEW SEASON!', text: top.length ? `Champions: ${top.map((t, i) => `${medals[i]} ${t.nickname}`).join('  ')}` : 'Everyone starts fresh' });
        a.staffLog(u, `reset season (backup season-backup-${stamp}.json)`);
        return true;
      });
      return true;
    }
  }
  return false;
}
