// Autopilot for group games: NEXT GAME picker → HOW TO PLAY card → the game → results → a short gap → repeat.
// Only one group game runs at a time. Rounds only start while chat is active. Staff can start, skip, pause or lock.
import { fmt } from './index.js';

export class Rounds {
  constructor(a) {
    this.a = a;
    this.phase = 'idle';
    this.game = null; // module
    this.round = null; // live instance
    this.last = '';
    this.nextAt = Date.now() + 20_000; // first round shortly after start-up
    this.phaseEnds = 0;
    this.lastView = 0;
    this.prejoin = [];
  }
  get cfg() { return this.a.cfg.rounds; }

  enabledGames() {
    return Object.values(this.a.group).filter(g => this.a.cfg.games[g.id]?.enabled);
  }
  choose() {
    const list = this.enabledGames();
    if (!list.length) return null;
    const mode = this.cfg.mode;
    const locked = mode && mode !== 'auto' ? list.find(g => g.id === mode) : null;
    if (locked) return locked; // an unknown or switched-off locked game falls back to random instead of stopping everything
    const fresh = list.filter(g => g.id !== this.last);
    const from = fresh.length ? fresh : list;
    return from[Math.floor(Math.random() * from.length)];
  }

  nextInfo() {
    if (this.phase !== 'idle') return { running: true, label: this.game ? `${this.game.emoji} ${this.game.name}` : '' };
    if (!this.cfg.autopilot || this.a.paused) return null;
    const mode = this.cfg.mode;
    const g = mode && mode !== 'auto' && this.a.cfg.games[mode]?.enabled ? this.a.group[mode] : null;
    return { at: this.nextAt, label: g ? `${g.emoji} ${g.name}` : 'Next game' };
  }

  // Start a round now (staff !start, a viewer's !heist when autopilot is off, or autopilot).
  start(id, { prejoin } = {}) {
    const g = id ? this.a.group[id] : this.choose();
    if (!g) return false;
    if (this.phase !== 'idle') return false;
    this.game = g;
    this.round = null;
    this.prejoin = prejoin ? [prejoin] : [];
    this.last = g.id;
    const now = Date.now();
    this.phase = 'picker';
    this.phaseEnds = now + this.cfg.pickerSeconds * 1000;
    this.a.emit('round', { phase: 'picker', game: this.meta(), choices: this.enabledGames().map(x => ({ id: x.id, name: x.name, emoji: x.emoji })), endsAt: this.phaseEnds });
    this.a.log(`🎮 Next group game: ${g.name}`);
    this.a.stateSoon();
    return true;
  }

  meta() { return this.game ? { id: this.game.id, name: this.game.name, emoji: this.game.emoji } : null; }

  skip(reason = 'skipped') {
    if (this.phase === 'idle') return false;
    const g = this.game;
    this.phase = 'idle';
    this.round = null;
    this.game = null;
    this.nextAt = Date.now() + this.cfg.gapSeconds * 1000;
    this.a.emit('round', { phase: 'end', game: g ? { id: g.id, name: g.name, emoji: g.emoji } : null, reason });
    this.a.stateSoon();
    return true; // bets are only settled at the end, so nothing is lost by skipping
  }

  tick(now) {
    const a = this.a;
    if (this.phase === 'idle') {
      if (!this.cfg.autopilot || a.paused || now < this.nextAt) return;
      if (a.activeChatters(this.cfg.activeWindowSec * 1000).length < Math.max(1, this.cfg.minActiveChatters)) {
        this.nextAt = now + 10_000; // quiet chat: check again in a bit
        return;
      }
      this.start();
      return;
    }
    if (a.paused && this.phase !== 'play') return;
    if (this.phase === 'picker' && now >= this.phaseEnds) {
      this.phase = 'howto';
      this.phaseEnds = now + this.cfg.howtoSeconds * 1000;
      a.emit('guide', { game: this.game.id, name: this.game.name, emoji: this.game.emoji, steps: this.game.guide(a), seconds: this.cfg.howtoSeconds, round: true });
      a.emit('round', { phase: 'howto', game: this.meta(), endsAt: this.phaseEnds });
    } else if (this.phase === 'howto' && now >= this.phaseEnds) {
      this.phase = 'play';
      this.round = this.game.create(a);
      this.round.start(now);
      for (const p of this.prejoin) p.tap ? this.round.tap(p.u, p.tap) : this.round.command(p.u, p.cmd, p.args);
      this.prejoin = [];
      this.emitView(true);
    } else if (this.phase === 'play') {
      const res = this.round.tick(now);
      if (res) return this.finish(res);
      if (this.round.dirty && now - this.lastView >= 300) this.emitView();
      else if (now - this.lastView >= 2000) this.emitView(); // keeps countdowns honest
    } else if (this.phase === 'result' && now >= this.phaseEnds) {
      this.phase = 'idle';
      this.game = null;
      this.round = null;
      this.nextAt = now + this.cfg.gapSeconds * 1000;
      a.emit('round', { phase: 'end' });
      a.stateSoon();
    }
  }

  emitView(first = false) {
    this.round.dirty = false;
    this.lastView = Date.now();
    this.a.emit('round', { phase: first ? 'play' : 'update', game: this.meta(), view: this.round.view(), currency: this.a.cur });
  }

  finish(res) {
    const a = this.a;
    if (res.empty) {
      a.emit('round', { phase: 'end', game: this.meta(), reason: 'Nobody joined this time' });
      this.phase = 'idle';
      this.game = null;
      this.round = null;
      this.nextAt = Date.now() + this.cfg.gapSeconds * 1000;
      a.stateSoon();
      return;
    }
    this.phase = 'result';
    this.phaseEnds = Date.now() + this.cfg.resultSeconds * 1000;
    a.emit('round', { phase: 'result', game: this.meta(), result: res, boost: a.boost(), currency: a.cur, endsAt: this.phaseEnds });
    a.stateSoon();
  }

  // ---------- input ----------
  ownsCommand(cmd) { return Object.values(this.a.group).some(g => g.commands.includes(cmd)); }

  command(u, cmd, args) {
    const a = this.a;
    if (this.phase === 'play' && this.game.commands.includes(cmd)) return this.round.command(u, cmd, args);
    const g = Object.values(a.group).find(x => x.commands.includes(cmd));
    if (this.phase === 'picker' || this.phase === 'howto') {
      if (g === this.game) { this.prejoin.push({ u, cmd, args }); return true; } // typed early: counts once it opens
    }
    // With autopilot off, a viewer's !heist starts a heist (like the classic Streamlabs heist).
    if (this.phase === 'idle' && g && g.id === 'heist' && cmd === 'heist' && !this.cfg.autopilot && a.cfg.games.heist.enabled) {
      this.start('heist', { prejoin: { u, cmd, args } });
      return true;
    }
    const n = this.nextInfo();
    const when = n?.at ? ` · next game in ${Math.max(1, Math.ceil((n.at - Date.now()) / 1000))}s` : '';
    const name = g ? `${g.emoji} ${g.name}` : 'That game';
    if (this.phase === 'idle') a.toast(`${name} isn't running right now${when}. Play now: !slots !gamble !fish`);
    else if (this.game && g !== this.game) {
      const now = Date.now();
      if (now - (this.wrongAt || 0) > 4000) { // one reminder every few seconds, not one per message
        this.wrongAt = now;
        a.toast(`${this.game.emoji} ${this.game.name} is on right now! ${this.game.hint ? this.game.hint(a) : ''}`);
      }
    }
    return true;
  }

  word(u, w) {
    if (this.phase === 'play') return this.round.word(u, w) ?? false;
    if ((this.phase === 'picker' || this.phase === 'howto') && this.game?.id === 'tug') { this.prejoin.push({ u, cmd: w, args: [] }); return true; }
    return false;
  }
  chat(u) { if (this.phase === 'play') this.round.chat(u); }
  tap(u, n) {
    if (this.phase === 'play') return this.round.tap(u, n);
    // tapping while the HOW TO PLAY card shows still gets you into a raffle
    if ((this.phase === 'picker' || this.phase === 'howto') && this.game?.id === 'raffle' && !this.prejoin.some(p => p.u === u)) this.prejoin.push({ u, tap: n });
  }

  snapshot() {
    if (this.phase === 'play') return { phase: 'play', game: this.meta(), view: this.round.view(), currency: this.a.cur };
    if (this.phase === 'picker' || this.phase === 'howto') return { phase: this.phase, game: this.meta(), endsAt: this.phaseEnds };
    return null;
  }
}

export const describeNext = r => (r?.at ? `in ${fmt(Math.ceil((r.at - Date.now()) / 1000))}s` : '');
