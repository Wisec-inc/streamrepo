// The host bot: a friendly on-screen character that welcomes people, thanks followers and gifters,
// keeps chat calm while the streamer is focused, answers !ask with Google, runs !daily and coin drops,
// pays the active-chatter bonus, and quietly ignores haters while posting something uplifting.
import { LINES } from './lines.js';

const fmt = n => Math.floor(Number(n) || 0).toLocaleString('en-US');
const MIN = 60_000;

const HOST_COMMANDS = new Set(['help', 'games', 'commands', 'cmds', 'claim', 'ask', 'q', 'focus', 'back', 'drop']);

// Built-in list of insults/slurs (English + Romanized Nepali/Hindi). Extra words can be added in settings.
const BLOCKED = [
  'idiot', 'stupid', 'moron', 'retard', 'retarded', 'loser', 'trash streamer', 'garbage streamer', 'worst streamer',
  'you suck', 'u suck', 'ugly', 'hate you', 'hate u', 'shut up', 'stfu', 'kys', 'kill yourself', 'kill urself', 'go die',
  'fuck you', 'fuck u', 'fuck off', 'f u', 'bitch', 'bastard', 'asshole', 'dick', 'pussy', 'slut', 'whore', 'cunt',
  'faggot', 'fag', 'nigger', 'nigga', 'dumbass', 'jackass',
  'muji', 'mugi', 'randi', 'rando', 'machikne', 'mchikne', 'chikne', 'chakka', 'lado', 'puti', 'geda', 'bhalu',
  'kutta', 'kutte', 'kutti', 'gadha', 'bhosdike', 'bhosdi', 'madarchod', 'behenchod', 'bhenchod', 'chutiya', 'chutiye',
  'harami', 'haramkhor', 'kamina', 'kamine'
];

const LEET = { '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '@': 'a', '$': 's' };
export function normalize(text) {
  return ' ' + String(text || '')
    .toLowerCase()
    .replace(/[013457@$]/g, c => LEET[c])
    .replace(/[^a-zऀ-ॿ\s]/g, ' ')
    .replace(/([a-z])\1+/g, '$1') // "stuuupid" -> "stupid"
    .replace(/\s+/g, ' ')
    .trim() + ' ';
}

const GOODBYE = /\b(bye+|byee+|bai|goodbye|good bye|gtg|g2g|got ?to go|gotta go|see (you|ya|u)|cya|take care|i'?m leaving|leaving now|jaanchu|janchu|jau hai|ma gaye|alvida|tata)\b/i;
const GOODNIGHT = /\b(gn|good ?night|gud ?night|goodnite|sleep(ing)? now|shubha ?ratri)\b/i;

export class Host {
  constructor({ store, games, ai, emit, log }) {
    this.store = store;
    this.games = games;
    this.ai = ai;
    this.emit = emit;
    this.log = log;

    this.welcomedThisStream = new Set();
    this.pendingWelcome = [];
    this.pendingFollow = [];
    this.active = new Map(); // key -> nickname, chatted in the current bonus window
    this.chatTimes = [];
    this.lastChatAt = 0;
    this.goodbyeAt = new Map();
    this.shareThanksAt = new Map();
    this.viewerHistory = [];
    this.focus = false;
    this.askQueue = [];
    this.askBusy = false;
    this.askCooldown = new Map();
    this.modBuffer = [];
    this.modBusy = false;
    this.drop = null;

    const now = Date.now();
    this.t = { bonus: now, nudge: now, focusMsg: 0, busy: 0, uplift: 0, viewerDrop: 0, moderation: now, nextDrop: now + this.#dropGap() };
    this.nudgeIndex = 0;
    this.timer = setInterval(() => this.#tick(), 1000);
  }

  get cfg() {
    return this.store.config;
  }

  get cur() {
    return this.cfg.currencyName;
  }

  streamerName() {
    if (this.cfg.host.streamerName) return this.cfg.host.streamerName;
    const rec = this.store.get(this.cfg.tiktokUsername);
    return rec?.nickname || this.cfg.tiktokUsername || 'the streamer';
  }

  // ---------- speaking ----------

  #fill(template, vars = {}) {
    const all = {
      streamer: this.streamerName(),
      currency: this.cur,
      start: fmt(this.cfg.startingPoints),
      follow: fmt(this.cfg.earn.followPoints),
      share: fmt(this.cfg.earn.sharePoints),
      bonus: fmt(this.cfg.earn.activeBonusPoints),
      minutes: this.cfg.earn.activeBonusMinutes,
      ...vars
    };
    return template.replace(/\{(\w+)\}/g, (m, k) => (all[k] !== undefined ? String(all[k]) : m));
  }

  #pick(key) {
    const list = LINES[key] || [];
    if (!list.length) return '';
    // avoid repeating the same line twice in a row
    this.lastPicked = this.lastPicked || {};
    let i = Math.floor(Math.random() * list.length);
    if (list.length > 1 && i === this.lastPicked[key]) i = (i + 1) % list.length;
    this.lastPicked[key] = i;
    return list[i];
  }

  // priority: 3 = answers / streamer's own message, 2 = thanks & events, 1 = welcomes, nudges, chit-chat
  say(text, { priority = 1, kind = 'info', ...extra } = {}) {
    if (!text) return;
    this.emit('host', { id: Date.now() + Math.random(), text, priority, kind, botName: this.cfg.host.botName, ...extra });
    this.log(`🤖 ${this.cfg.host.botName}: ${extra.question ? `[Q: ${extra.question}] ` : ''}${text}`);
  }

  sayLine(key, vars, opts) {
    this.say(this.#fill(this.#pick(key), vars), opts);
  }

  #names(list) {
    const n = list.map(x => x.nickname || x.username);
    if (n.length <= 1) return n[0] || '';
    if (n.length === 2) return `${n[0]} & ${n[1]}`;
    if (n.length === 3) return `${n[0]}, ${n[1]} & ${n[2]}`;
    return `${n[0]}, ${n[1]} & ${n.length - 2} others`;
  }

  #isStaffish(username) {
    return this.games.isStreamer(username);
  }

  // ---------- TikTok events ----------

  handleJoin(user) {
    if (!this.cfg.host.welcomes || !user) return;
    const rec = this.store.get(user.username);
    if (!rec || this.#isStaffish(rec.username)) return;
    const k = this.store.key(rec.username);
    if (this.welcomedThisStream.has(k)) return;
    this.welcomedThisStream.add(k);
    this.pendingWelcome.push({ username: rec.username, nickname: rec.nickname, returning: !!rec.welcomedBefore, at: Date.now() });
    rec.welcomedBefore = true;
    this.store.savePointsSoon();
  }

  handleFollow(user, points) {
    if (!user) return;
    this.pendingFollow.push({ username: user.username, nickname: user.nickname, points, at: Date.now() });
  }

  handleShare(user, points) {
    if (!user || points <= 0) return;
    const k = this.store.key(user.username);
    if (Date.now() - (this.shareThanksAt.get(k) || 0) < 10 * MIN) return;
    this.shareThanksAt.set(k, Date.now());
    this.sayLine('share', { names: user.nickname, points: fmt(points) }, { priority: 1, kind: 'thanks' });
  }

  handleGift(user, { giftName, count, points }) {
    if (!user || !this.cfg.host.giftThanks) return;
    const gift = `${giftName}${count > 1 ? ' x' + count : ''}`;
    this.sayLine('gift', { name: user.nickname, gift, points: fmt(points) }, { priority: 2, kind: 'gift' });
  }

  handleViewers(count) {
    const now = Date.now();
    this.viewerHistory.push({ t: now, n: count });
    this.viewerHistory = this.viewerHistory.filter(v => now - v.t < 3 * MIN);
    if (!this.cfg.host.viewerDropThanks) return;
    const peak = Math.max(...this.viewerHistory.map(v => v.n));
    if (peak - count >= Math.max(3, peak * 0.15) && now - this.t.viewerDrop > 10 * MIN) {
      this.t.viewerDrop = now;
      this.viewerHistory = [{ t: now, n: count }];
      this.sayLine('viewerDrop', {}, { priority: 1, kind: 'bye' });
    }
  }

  // ---------- chat ----------

  #blockedList() {
    const extra = String(this.cfg.moderation.blockedWords || '').split(/[,\n]+/).map(s => s.trim()).filter(Boolean);
    return [...BLOCKED, ...extra].map(w => normalize(w).trim()).filter(Boolean);
  }

  isHateful(text) {
    const t = normalize(text);
    return this.#blockedList().some(w => t.includes(` ${w} `));
  }

  // Called before the games see a message. Returns true if the message is hateful (and should be ignored).
  preCheck(user, text) {
    if (!user || this.games.isStreamer(user.username) || this.games.isMod(user.username)) return false;
    if (!this.isHateful(text)) return false;
    this.#onHate(user, 'word filter');
    return true;
  }

  #onHate(user, how) {
    const k = this.store.key(user.username);
    this.active.delete(k); // no chat bonus for this window
    this.pendingWelcome = this.pendingWelcome.filter(x => this.store.key(x.username) !== k); // and no welcome
    this.log(`🛡️ Ignored a hateful message from ${user.username} (${how}). Not shown, no points.`);
    if (!this.cfg.moderation.upliftMessages) return;
    if (Date.now() - this.t.uplift < 3 * MIN) return;
    this.t.uplift = Date.now();
    this.sayLine('uplift', {}, { priority: 2, kind: 'uplift' });
  }

  // Called after the games had a look. `handled` = a game command already used it.
  afterChat(user, text, role = {}, handled = false) {
    if (!user) return;
    const u = this.store.get(user.username);
    if (!u) return;
    const k = this.store.key(u.username);
    const now = Date.now();
    const msg = String(text || '').trim();
    const isStreamer = this.games.isStreamer(u.username);

    this.chatTimes.push(now);
    this.lastChatAt = now;
    if (!isStreamer) this.active.set(k, u.nickname);

    if (!isStreamer && !msg.startsWith('!') && this.cfg.ai.aiModeration && this.ai.hasKey) {
      this.modBuffer.push({ username: u.username, nickname: u.nickname, text: msg });
      if (this.modBuffer.length > 80) this.modBuffer.shift();
    }

    if (msg.startsWith('!')) {
      if (handled) return;
      const parts = msg.slice(1).split(/\s+/).filter(Boolean);
      const cmd = (parts.shift() || '').toLowerCase();
      if (HOST_COMMANDS.has(cmd)) this.#command(u, cmd, parts, msg);
      return;
    }

    // goodbyes
    if (!isStreamer && this.cfg.host.goodbyes && msg.length <= 60) {
      const night = GOODNIGHT.test(msg);
      if (night || GOODBYE.test(msg)) {
        if (now - (this.goodbyeAt.get(k) || 0) > 10 * MIN) {
          this.goodbyeAt.set(k, now);
          this.sayLine(night ? 'goodnight' : 'goodbye', { name: u.nickname }, { priority: 1, kind: 'bye' });
        }
      }
    }
  }

  #command(u, cmd, args, raw) {
    const staff = this.games.canDonate(u.username) || this.games.isMod(u.username);
    switch (cmd) {
      case 'help': case 'games': case 'commands': case 'cmds':
        return this.showHelp();
      case 'claim':
        return this.#claim(u);
      case 'ask': case 'q':
        return this.#ask(u, raw.replace(/^!\s*\w+\s*/, ''));
      case 'focus':
        if (staff) this.setFocus(true);
        return;
      case 'back':
        if (staff) this.setFocus(false);
        return;
      case 'drop':
        if (staff) this.startDrop();
        return;
    }
  }

  // ---------- !help ----------

  showHelp() {
    const g = this.cfg.games;
    const c = this.cur;
    const bet = fmt(this.cfg.economy.defaultBet);
    const rows = [['!coins', `your ${c} and rank`], ['!daily', `free ${c} every day 🔥`]];
    if (g.slots.enabled) rows.push(['!slots', `spin (bets ${bet}) 🎰`]);
    if (g.gamble.enabled) rows.push(['!gamble', 'roll 1-100 🎲']);
    if (g.fish.enabled) rows.push(['!fish', 'free catch every 2 min 🎣']);
    if (g.duel.enabled) rows.push(['!duel @name', '1v1 coin flip ⚔️']);
    const group = ['heist', 'raid', 'raffle', 'tug'].filter(id => g[id].enabled);
    if (group.length) rows.push(['Group games', 'start on their own: just do what the screen says 🎮']);
    if (this.cfg.drops.enabled) rows.push(['!claim', 'grab a coin drop 🎁']);
    if (this.cfg.ai.askEnabled && this.ai.hasKey) rows.push(['!ask …', 'ask me anything 🤔']);
    rows.push(['!top · !work', 'leaderboard · coins when broke']);
    rows.push(['!help slots', 'how any game works · !odds slots']);
    this.emit('card', {
      kind: 'help',
      icon: '🎮',
      title: 'How to play',
      sub: `One word plays · add a number, "all" or "half" to bet more`,
      rows
    });
  }

  // ---------- coin drops ----------

  #dropGap() {
    const m = Math.max(1, this.cfg?.drops?.everyMinutes ?? 15);
    return (m + (Math.random() * 0.4 - 0.2) * m) * MIN; // ±20% so it's a surprise
  }

  startDrop() {
    if (this.drop) return;
    const d = this.cfg.drops;
    this.drop = { endsAt: Date.now() + d.claimSeconds * 1000, max: d.winners, points: d.points, winners: [] };
    this.emit('drop', { phase: 'start', endsAt: this.drop.endsAt, max: d.winners, points: d.points, winners: [], currency: this.cur });
    this.sayLine('dropStart', { winners: d.winners, points: fmt(d.points) }, { priority: 2, kind: 'drop' });
    this.log(`🎁 Coin drop started (${d.winners} × ${d.points})`);
  }

  #claim(u) {
    if (!this.drop) return this.emit('toast', { text: `No drop right now ${u.nickname}, stay tuned 👀` });
    if (this.drop.winners.some(w => w.username === u.username)) return;
    if (this.games.isStreamer(u.username)) return;
    this.store.add(u.username, this.drop.points);
    this.drop.winners.push({ username: u.username, nickname: u.nickname, avatar: u.avatar });
    this.emit('drop', { phase: 'claim', endsAt: this.drop.endsAt, max: this.drop.max, points: this.drop.points, winners: this.drop.winners, currency: this.cur });
    this.#leaderboard();
    if (this.drop.winners.length >= this.drop.max) this.#endDrop();
  }

  #endDrop() {
    const drop = this.drop;
    if (!drop) return;
    this.drop = null;
    this.t.nextDrop = Date.now() + this.#dropGap();
    this.emit('drop', { phase: 'end', winners: drop.winners, points: drop.points, currency: this.cur });
    if (drop.winners.length) this.sayLine('dropEnd', { names: this.#names(drop.winners) }, { priority: 2, kind: 'drop' });
    else this.sayLine('dropEmpty', {}, { priority: 1, kind: 'drop' });
  }

  // ---------- focus mode ----------

  setFocus(on) {
    on = !!on;
    if (this.focus === on) return;
    this.focus = on;
    this.t.focusMsg = Date.now();
    this.emit('focus', { on, streamer: this.streamerName() });
    this.sayLine(on ? 'focusStart' : 'focusEnd', {}, { priority: 2, kind: 'focus' });
    this.log(on ? '🎮 Focus mode ON' : '💬 Focus mode OFF');
  }

  // ---------- !ask ----------

  #ask(u, question) {
    const q = question.trim();
    if (!this.cfg.ai.askEnabled) return;
    if (!this.ai.hasKey) return this.emit('toast', { text: '!ask is resting right now 😴 (no Google key set up yet)' });
    if (q.length < 3) return this.emit('toast', { text: `${u.nickname}, type your question after !ask, e.g. !ask how tall is Everest` });
    const k = this.store.key(u.username);
    const staff = this.games.isStreamer(u.username) || this.games.isMod(u.username);
    const wait = this.cfg.ai.askCooldownSec * 1000 - (Date.now() - (this.askCooldown.get(k) || 0));
    if (!staff && wait > 0) return this.emit('toast', { text: `${u.nickname}, you can ask again in ${Math.ceil(wait / 1000)}s 🙏` });
    if (this.askQueue.length >= 5) return this.emit('toast', { text: 'Lots of questions right now! Try again in a minute 🙏' });
    if (this.isHateful(q)) return this.#onHate(u, 'rude !ask');
    this.askCooldown.set(k, Date.now());
    this.askQueue.push({ u, q });
    this.emit('toast', { text: `🔎 Looking that up for ${u.nickname}…` });
    this.#processAsk();
  }

  async #processAsk() {
    if (this.askBusy) return;
    const job = this.askQueue.shift();
    if (!job) return;
    this.askBusy = true;
    try {
      const r = await this.ai.ask(job.q, { botName: this.cfg.host.botName, streamerName: this.streamerName(), streamerInfo: this.cfg.ai.streamerInfo });
      if (r.skip) this.sayLine('askSkip', {}, { priority: 2, kind: 'ask', question: job.q, asker: job.u.nickname });
      else this.say(r.answer, { priority: 3, kind: 'ask', question: job.q, asker: job.u.nickname });
    } catch (e) {
      this.log(`⚠️ !ask failed: ${e.message}`);
      this.emit('toast', { text: `Couldn't look that up right now, ${job.u.nickname}. Try again soon 🙏` });
      this.askCooldown.delete(this.store.key(job.u.username));
    } finally {
      this.askBusy = false;
      if (this.askQueue.length) setTimeout(() => this.#processAsk(), 500);
    }
  }

  // ---------- AI moderation (batched to stay inside the free limits) ----------

  async #runModeration() {
    if (this.modBusy || !this.modBuffer.length || !this.ai.ready) return;
    this.modBusy = true;
    const batch = this.modBuffer.splice(0, 40);
    try {
      const flagged = await this.ai.moderate(batch.map(m => m.text));
      const users = new Map();
      for (const i of flagged) users.set(batch[i].username, batch[i]);
      for (const m of users.values()) this.#onHate(m, 'AI check');
    } catch (e) {
      this.log(`⚠️ AI moderation skipped: ${e.message}`);
    } finally {
      this.modBusy = false;
    }
  }

  // ---------- timers ----------

  #leaderboard() {
    this.games.stateSoon();
    this.emit('leaderboard', null);
  }

  #recentChat(ms) {
    return Date.now() - this.lastChatAt < ms;
  }

  #tick() {
    const now = Date.now();
    const h = this.cfg.host;

    // batched welcomes
    if (this.pendingWelcome.length && (now - this.pendingWelcome[0].at >= h.welcomeBatchSec * 1000 || this.pendingWelcome.length >= 10)) {
      const list = this.pendingWelcome.splice(0);
      const allBack = list.every(x => x.returning);
      const key = list.length >= 3 ? 'welcomeGroup' : allBack ? 'welcomeBack' : 'welcomeNew';
      this.sayLine(key, { names: this.#names(list) }, { priority: 1, kind: 'welcome' });
    }

    // batched follow thanks
    if (this.pendingFollow.length && now - this.pendingFollow[0].at >= 5000) {
      const list = this.pendingFollow.splice(0);
      const paid = list.filter(x => x.points > 0);
      const points = paid[0]?.points || 0;
      if (list.length === 1) {
        this.say(points ? this.#fill(this.#pick('follow'), { names: list[0].nickname, points: fmt(points) }) : `Thank you for the follow, ${list[0].nickname}! 💛`, { priority: 2, kind: 'thanks' });
      } else {
        this.sayLine('followGroup', { names: this.#names(list), points: fmt(points) }, { priority: 2, kind: 'thanks' });
      }
    }

    // active-chatter bonus
    const e = this.cfg.earn;
    if (e.activeBonusPoints > 0 && now - this.t.bonus >= Math.max(1, e.activeBonusMinutes) * MIN) {
      this.t.bonus = now;
      const winners = [...this.active.entries()].filter(([k]) => !this.games.isUnlimited(k));
      this.active.clear();
      if (winners.length) {
        for (const [k] of winners) this.store.add(k, e.activeBonusPoints);
        this.games.rookieBoost(winners.map(([k]) => k));
        const vars = { points: fmt(e.activeBonusPoints), count: winners.length, names: winners[0][1] };
        this.sayLine(winners.length === 1 ? 'bonusOne' : 'bonusMany', vars, { priority: 2, kind: 'reward' });
        this.#leaderboard();
      }
    }

    // gentle nudges (only when people are around)
    if (h.nudgeMinutes > 0 && now - this.t.nudge >= h.nudgeMinutes * MIN) {
      this.t.nudge = now;
      if (this.#recentChat(10 * MIN)) {
        const keys = ['nudgeLike', 'nudgeFollow', 'nudgeHelp', 'nudgeShare', 'nudgeChat'];
        keys.push('nudgeDaily');
        if (this.cfg.ai.askEnabled && this.ai.hasKey) keys.push('nudgeAsk');
        const key = keys[this.nudgeIndex++ % keys.length];
        this.sayLine(key, {}, { priority: 1, kind: 'nudge' });
      }
    }

    // focus mode: calm, humble reminders
    if (this.focus && h.focusMessageMinutes > 0 && now - this.t.focusMsg >= h.focusMessageMinutes * MIN) {
      this.t.focusMsg = now;
      if (this.#recentChat(5 * MIN)) this.sayLine('focus', {}, { priority: 2, kind: 'focus' });
    }

    // busy chat: thank people for their patience (max every 12 min)
    this.chatTimes = this.chatTimes.filter(t => now - t < 3 * MIN);
    if (!this.focus && h.busyChatMessages && this.chatTimes.length >= 25 && now - this.t.busy >= 12 * MIN && now - this.t.focusMsg >= 5 * MIN) {
      this.t.busy = now;
      this.sayLine('busy', {}, { priority: 1, kind: 'focus' });
    }

    // coin drops (if the interval was shortened in settings, pull the next drop closer)
    const maxGap = Math.max(1, this.cfg.drops.everyMinutes) * 1.2 * MIN;
    if (this.t.nextDrop - now > maxGap) this.t.nextDrop = now + this.#dropGap();
    if (this.drop && now >= this.drop.endsAt) this.#endDrop();
    if (!this.drop && this.cfg.drops.enabled && now >= this.t.nextDrop) {
      if (this.#recentChat(5 * MIN)) this.startDrop();
      else this.t.nextDrop = now + MIN; // nobody around, check again in a minute
    }

    // AI moderation batch
    if (this.cfg.ai.aiModeration && now - this.t.moderation >= Math.max(10, this.cfg.ai.moderationIntervalSec) * 1000) {
      this.t.moderation = now;
      this.#runModeration();
    }
  }

  // for overlays that load mid-stream
  snapshot() {
    return {
      focus: { on: this.focus, streamer: this.streamerName() },
      drop: this.drop ? { phase: 'start', endsAt: this.drop.endsAt, max: this.drop.max, points: this.drop.points, winners: this.drop.winners, currency: this.cur } : null,
      botName: this.cfg.host.botName,
      askEnabled: this.cfg.ai.askEnabled && this.ai.hasKey,
      dailyEnabled: true
    };
  }

  stop() {
    clearInterval(this.timer);
  }
}
