// Stand-in for node:path (only what engine/store.js uses). The build points "node:path" at this file.
const join = (...parts) => parts.filter(Boolean).join('/').replace(/\/{2,}/g, '/');
export default { join };
export { join };
