// The TikTok overlay: the TikTok PC edition's engine (engine-tiktok/) with the web host.
import { Store } from '../engine-tiktok/store.js';
import { startEngine } from './engine-host-tiktok.js';
import { bootOverlay, bootFailed } from './overlay-common.js';

bootOverlay({ platform: 'tiktok', Store, startEngine }).catch(bootFailed);
