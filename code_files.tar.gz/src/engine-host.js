// The web edition's "server.js": wires the unchanged game engine (engine/) to the chat bridge, the overlay page
// and the control panel. It follows the local edition's server.js block by block (logging, games, handlers,
// panel commands, start) so the two are easy to compare. `bus` plays the part of socket.io's `io`.
import { Arcade } from '../engine/arcade/index.js';
import { Host } from '../engine/host.js';
import { GeminiAI } from '../engine/ai.js';
import { DEFAULT_CONFIG } from '../engine/defaults.js';
import { YtWebBridge } from './yt-web-bridge.js';
import { KEY_PLACEHOLDER } from './web-store.js';

export const USERS_TO_PANEL = 1000; // the panel's viewer list (the local edition sends everyone; a web message has a size limit)

// store: from createStore() · bus: EngineBus · api: { find, poll } for YouTube
// ai: { hasKey, onServer } says whether a Gemini key is saved on the server · reload: restarts the overlay page
export function startEngine({ store, bus, api, ai: aiInfo = { hasKey: false }, autoConnect = true, reload = () => {} }) {
  // The real Gemini key stays on the server. The engine only needs to know whether there is one.
  // (Demo mode has no server-side key store: there the key stays in this browser's settings, as in the local edition.)
  const applyKeyFlag = () => { if (aiInfo.onServer) store.config.ai.geminiApiKey = aiInfo.hasKey ? KEY_PLACEHOLDER : ''; };
  const updateConfig = next => { store.updateConfig(next); applyKeyFlag(); };
  applyKeyFlag();
  if (store.config.connectionMode !== 'service') store.config.connectionMode = 'service'; // no "My own browser" mode on the web

  // ---------- logging ----------
  const logs = [];
  function log(text) {
    const entry = { t: Date.now(), text };
    logs.push(entry);
    if (logs.length > 300) logs.shift();
    bus.emitPanel('log', entry);
    console.log(new Date().toLocaleTimeString(), text);
  }

  // ---------- games ----------
  const emit = (type, payload) => {
    if (type === 'leaderboard') { // old event name: refresh the panel list and the overlay's top 3
      pushUsersSoon();
      games?.stateSoon();
      return;
    }
    bus.emitAll(type, payload);
  };

  let games = null;
  games = new Arcade(store, emit, log, { platform: 'youtube' });
  games.onConfigChange = () => bus.emitPanel('config', store.config);
  const ai = new GeminiAI(() => store.config, log);
  const host = new Host({ store, games, ai, emit, log });
  const snapshot = () => ({ ...games.snapshot(), host: host.snapshot() });

  let usersTimer = null;
  function pushUsersSoon() {
    if (usersTimer) return;
    usersTimer = setTimeout(() => {
      usersTimer = null;
      bus.emitPanel('users', store.top(USERS_TO_PANEL));
    }, 800);
  }

  const handlers = {
    chat: (u, text, mentions, role = {}) => {
      if (host.preCheck(u, text)) return; // hateful: ignored, no points, host posts something uplifting
      if (String(text).startsWith('!')) log(`💬 ${role.isHost ? '[streamer] ' : role.isMod ? '[mod] ' : ''}${u.username}: ${text}`);
      const handled = games.handleChat(u, text, mentions, role);
      host.afterChat(u, text, role, handled);
      pushUsersSoon();
    },
    member: u => {
      log(`⭐ ${u.username} became a member`);
      const r = games.handleMember(u);
      host.handleFollow(r.user, r.points);
    },
    milestone: (u, text) => {
      log(`⭐ ${u.username}: ${text}`);
      games.handleJoin(u);
      const months = (String(text).match(/\d+\s*\w+/) || ['a while'])[0];
      host.sayLine('memberMilestone', { name: u.nickname, months }, { priority: 2, kind: 'thanks' });
    },
    superchat: (u, m) => {
      const points = Math.round(m.usd * (store.config.earn.superChatPointsPerDollar || 0));
      const r = games.award(u, points, { what: `${m.text} Super ${m.sticker ? 'Sticker' : 'Chat'}` });
      log(`💸 ${u.username} sent a ${m.text} Super ${m.sticker ? 'Sticker' : 'Chat'} (~$${m.usd.toFixed(2)} → +${r.points})`);
      host.handleGift(r.user, { giftName: `${m.text} Super ${m.sticker ? 'Sticker' : 'Chat'}`, count: 1, points: r.points });
    },
    giftMemberships: (u, count) => {
      const r = games.award(u, count * (store.config.earn.giftedMembershipPoints || 0), { what: `${count} gifted membership${count === 1 ? '' : 's'}` });
      log(`🎁 ${u.username} gifted ${count} membership${count === 1 ? '' : 's'} (+${r.points})`);
      host.handleGift(r.user, { giftName: `${count} gifted membership${count === 1 ? '' : 's'}`, count: 1, points: r.points });
    },
    join: u => {
      games.handleJoin(u);
      host.handleJoin(u);
      pushUsersSoon();
    },
    viewers: n => host.handleViewers(n)
  };

  const stream = new YtWebBridge({
    onStatus: s => bus.emitAll('status', s),
    onLog: log,
    handlers,
    api
  });

  // ---------- "sockets": a page said hello ----------
  bus.onHello(role => {
    bus.emitAll('status', stream.status);
    bus.emitAll('snapshot', snapshot());
    if (role !== 'panel') return;
    bus.emitPanel('config', store.config);
    bus.emitPanel('users', store.top(USERS_TO_PANEL));
    bus.emitPanel('logs', logs);
  });

  // Everything below is for the control panel only.
  const on = (ev, fn) => bus.onCommand(ev, fn);

  on('connectStream', async ({ username } = {}) => {
    updateConfig({ ...store.config, channel: String(username || '').trim(), connectionMode: 'service' });
    bus.emitPanel('config', store.config);
    await stream.connect(store.config.channel, { autoReconnect: store.config.autoReconnect });
  });

  on('disconnectStream', async () => {
    await stream.disconnect();
    log('⏹️ Disconnected by you');
  });

  on('saveConfig', next => {
    updateConfig({ ...next, connectionMode: 'service' });
    games.stateSoon();
    bus.emitPanel('config', store.config);
    bus.emitAll('snapshot', snapshot());
    log('💾 Settings saved');
  });

  on('resetConfig', () => {
    const keep = { channel: store.config.channel };
    updateConfig({ ...structuredClone(DEFAULT_CONFIG), ...keep, connectionMode: 'service' });
    bus.emitPanel('config', store.config);
    bus.emitAll('snapshot', snapshot());
    log('↩️ Settings reset to defaults');
  });

  on('simulate', ({ kind, username, nickname, text, amount, asMod, asHost } = {}) => {
    let name = String(username || 'test_viewer').replace(/^@/, '').trim() || 'test_viewer';
    if (asHost) name = (String(store.config.channel || '').match(/@([\w.\-]+)/) || [, 'streamer'])[1]; // "as streamer" sends from your own channel
    const u = { username: name, nickname: nickname || name, avatar: '' };
    switch (kind) {
      case 'chat': {
        // simulate an @mention
        const mentions = [];
        const m = String(text || '').match(/@([\w.]+)/);
        if (m) mentions.push({ username: m[1], nickname: m[1], avatar: '' });
        if (!stream.seenSim) stream.seenSim = new Set();
        if (!stream.seenSim.has(u.username)) { stream.seenSim.add(u.username); handlers.join(u); } // like the real bridge: welcome on first message
        return handlers.chat(u, text || '', mentions, { isMod: !!asMod, isHost: !!asHost });
      }
      case 'join': return handlers.join(u);
      case 'viewers': return handlers.viewers(Number(amount) || 0);
      case 'member': return handlers.member(u);
      case 'superchat': {
        const usd = Number(amount) || 5;
        return handlers.superchat(u, { text: `$${usd.toFixed(2)}`, currency: 'USD', value: usd, usd, sticker: false, message: '' });
      }
      case 'gifts': return handlers.giftMemberships(u, Number(amount) || 5);
    }
  });

  on('setPoints', ({ username, points }) => {
    if (!store.get(username)) store.touch({ username, nickname: username });
    store.set(username, points);
    log(`✏️ Set ${username} to ${points}`);
    emit('leaderboard', null);
  });

  on('addPoints', ({ username, amount }) => {
    if (!store.get(username)) store.touch({ username, nickname: username });
    store.add(username, Number(amount) || 0);
    log(`➕ Gave ${username} ${amount}`);
    emit('leaderboard', null);
  });

  on('addPointsMany', ({ usernames, amount }) => {
    const n = Math.floor(Number(amount) || 0);
    if (!Array.isArray(usernames) || n <= 0) return;
    let count = 0;
    for (const name of usernames) if (store.get(name)) { store.add(name, n); count++; }
    log(`🎁 Donated ${n} to ${count} viewer${count === 1 ? '' : 's'}`);
    emit('leaderboard', null);
  });

  on('addPointsAll', ({ amount }) => {
    for (const u of Object.values(store.users)) store.add(u.username, Number(amount) || 0);
    log(`🎉 Gave everyone ${amount}`);
    emit('leaderboard', null);
  });

  on('deleteUser', ({ username }) => {
    store.remove(username);
    log(`🗑️ Removed ${username}`);
    emit('leaderboard', null);
  });

  on('resetPoints', () => {
    store.resetAll();
    log(`↩️ Everyone reset to ${store.config.startingPoints}`);
    emit('leaderboard', null);
  });

  on('wipePoints', () => {
    store.wipeAll();
    log('🧹 All viewers deleted');
    emit('leaderboard', null);
  });

  on('cancelGames', () => {
    games.cancelAll();
    log('🛑 Group game and duel requests cancelled (nothing was charged)');
  });

  // Live controls: the panel types a chat command as the streamer (e.g. "!start raid", "!2x 10m").
  on('staffCommand', text => {
    const t = String(text || '').trim();
    if (!t) return;
    const name = games.ownName() || 'streamer';
    const u = { username: name, nickname: store.config.host.streamerName || name, avatar: '' };
    const m = t.match(/@([\w.]+)/);
    log(`🎛️ Panel: ${t}`);
    handlers.chat(u, t.startsWith('!') ? t : '!' + t, m ? [{ username: m[1], nickname: m[1], avatar: '' }] : [], { isHost: true });
  });
  on('liveState', (_, reply) => reply?.({ state: games.state(), round: games.rounds.snapshot(), phase: games.rounds.phase }));

  on('setFocus', v => host.setFocus(v));
  on('startDrop', () => host.startDrop());
  on('showHelp', () => host.showHelp());
  on('hostSay', text => {
    const t = String(text || '').trim().slice(0, 200);
    if (t) host.say(t, { priority: 3, kind: 'streamer' });
  });
  on('testAi', async (_, reply) => {
    try {
      const r = await ai.test();
      log(`✅ Google answers work (${r.model}): ${r.answer}`);
      reply?.({ ok: true, ...r });
    } catch (e) {
      log(`❌ Google answers test failed: ${e.message}`);
      reply?.({ ok: false, error: e.message });
    }
  });

  on('testOverlay', () => {
    // a few demo viewers, so the 5 s wait between solo games doesn't block the demo
    const people = ['Demo Viewer', 'Demo Sita', 'Demo Ram', 'Demo Gita'].map(n => ({ username: n.toLowerCase().replace(' ', '_'), nickname: n, avatar: '' }));
    people.forEach(handlers.join);
    const demo = [[0, '!help'], [1, '!daily'], [2, '!slots'], [3, '!gamble'], [0, '!fish'], [1, '!slots'], [2, '!coins'], [3, '!top']];
    demo.forEach(([p, t], i) => setTimeout(() => handlers.chat(people[p], t, []), 1500 + i * 2500));
  });

  // ---------- web edition only ----------
  // The panel saved or removed the Gemini key on the server.
  on('aiKeyChanged', ({ hasKey } = {}) => {
    aiInfo.hasKey = !!hasKey;
    applyKeyFlag();
    bus.emitPanel('config', store.config);
    bus.emitAll('snapshot', snapshot());
    log(hasKey ? '🔑 Google answers key saved' : '🔑 Google answers key removed');
  });
  // The panel imported coins or made a new overlay link: save what's here, then start again with the fresh data.
  on('reloadEngine', async () => {
    try { await store.flush(); } catch {}
    reload();
  });

  // ---------- start ----------
  if (store.config.channel && autoConnect && store.config.autoReconnect) {
    log(`🔁 Auto-connecting to @${store.config.channel}`);
    stream.connect(store.config.channel, { autoReconnect: true });
  }

  const shutdown = () => {
    store.flushOnExit();
    stream.disconnect();
  };

  return { store, games, host, ai, stream, handlers, snapshot, log, logs, shutdown };
}
