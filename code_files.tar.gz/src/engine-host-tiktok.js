// The web edition's "server.js" for TikTok: wires the unchanged TikTok game engine (engine-tiktok/) to the chat
// bridge, the overlay page and the control panel. It follows the TikTok PC edition's server.js block by block
// (logging, games, handlers, panel commands, start) so the two are easy to compare. `bus` plays `io`.
import { Arcade } from '../engine-tiktok/arcade/index.js';
import { Host } from '../engine-tiktok/host.js';
import { GeminiAI } from '../engine-tiktok/ai.js';
import { DEFAULT_CONFIG } from '../engine-tiktok/defaults.js';
import { TtWebBridge } from './tt-web-bridge.js';
import { KEY_PLACEHOLDER } from './web-store.js';

export const USERS_TO_PANEL = 1000; // the panel's viewer list (the PC edition sends everyone; a web message has a size limit)

// store: from createStore() · bus: EngineBus · link: the overlay's live link (TikTok chat arrives on it)
// ai: { hasKey, onServer } says whether a Gemini key is saved on the server · reload: restarts the overlay page
export function startEngine({ store, bus, link, ai: aiInfo = { hasKey: false }, autoConnect = true, reload = () => {}, makeBridge = opts => new TtWebBridge(opts) }) {
  // The real Gemini key stays on the server. The engine only needs to know whether there is one.
  const applyKeyFlag = () => { if (aiInfo.onServer) store.config.ai.geminiApiKey = aiInfo.hasKey ? KEY_PLACEHOLDER : ''; };
  // On the web the chat is always read by the site's server with the site's own signing key.
  const webOnly = cfg => ({ ...cfg, connectionMode: 'service', signApiKey: '' });
  const updateConfig = next => { store.updateConfig(webOnly(next)); applyKeyFlag(); };
  applyKeyFlag();
  if (store.config.connectionMode !== 'service') store.config.connectionMode = 'service';

  // ---------- logging ----------
  const logs = [];
  function log(text) {
    const entry = { t: Date.now(), text };
    logs.push(entry);
    if (logs.length > 300) logs.shift();
    bus.emitPanel('log', entry);
    console.log(new Date().toLocaleTimeString(), text);
  }

  // ---------- games ----------
  const emit = (type, payload) => {
    if (type === 'leaderboard') { // old event name: refresh the panel list and the overlay's top 3
      pushUsersSoon();
      games?.stateSoon();
      return;
    }
    bus.emitAll(type, payload);
  };
  let games = null;
  games = new Arcade(store, emit, log);
  games.onConfigChange = () => bus.emitPanel('config', store.config);
  const ai = new GeminiAI(() => store.config, log);
  const host = new Host({ store, games, ai, emit, log });
  const snapshot = () => ({ ...games.snapshot(), host: host.snapshot() });

  let usersTimer = null;
  function pushUsersSoon() {
    if (usersTimer) return;
    usersTimer = setTimeout(() => {
      usersTimer = null;
      bus.emitPanel('users', store.top(USERS_TO_PANEL));
    }, 800);
  }

  const handlers = {
    chat: (u, text, mentions, role = {}) => {
      if (host.preCheck(u, text)) return; // hateful: ignored, no points, host posts something uplifting
      if (String(text).startsWith('!')) log(`💬 ${role.isHost ? '[streamer] ' : role.isMod ? '[mod] ' : ''}${u.username}: ${text}`);
      const handled = games.handleChat(u, text, mentions, role);
      host.afterChat(u, text, role, handled);
      pushUsersSoon();
    },
    like: (u, n) => {
      games.handleLike(u, n);
      pushUsersSoon();
    },
    follow: u => {
      log(`➕ ${u.username} followed`);
      const r = games.handleFollow(u);
      host.handleFollow(r.user, r.points);
    },
    share: u => {
      log(`🔁 ${u.username} shared the LIVE`);
      const r = games.handleShare(u);
      host.handleShare(r.user, r.points);
    },
    gift: (u, g) => {
      const r = games.handleGift(u, g);
      log(`🎁 ${u.username} sent ${g.giftName} x${g.count} (${r.coins} coins → +${r.points})`);
      host.handleGift(r.user, { giftName: g.giftName, count: g.count, points: r.points });
    },
    join: u => {
      games.handleJoin(u);
      host.handleJoin(u);
      pushUsersSoon();
    },
    viewers: n => host.handleViewers(n)
  };

  const tiktok = makeBridge({
    onStatus: s => bus.emitAll('status', s),
    onLog: log,
    handlers,
    link
  });

  // ---------- "sockets": a page said hello ----------
  bus.onHello(role => {
    bus.emitAll('status', tiktok.status);
    bus.emitAll('snapshot', snapshot());
    if (role !== 'panel') return;
    bus.emitPanel('config', store.config);
    bus.emitPanel('users', store.top(USERS_TO_PANEL));
    bus.emitPanel('logs', logs);
  });

  // Everything below is for the control panel only.
  const on = (ev, fn) => bus.onCommand(ev, fn);

  on('connectTikTok', async ({ username } = {}) => {
    const cfg = { ...store.config, tiktokUsername: String(username || '').trim().replace(/^@/, '') };
    updateConfig(cfg);
    bus.emitPanel('config', store.config);
    await tiktok.connect(store.config.tiktokUsername, { autoReconnect: store.config.autoReconnect });
  });

  on('disconnectTikTok', async () => {
    await tiktok.disconnect();
    log('⏹️ Disconnected by you');
  });

  on('saveConfig', next => {
    updateConfig(next);
    games.stateSoon();
    bus.emitPanel('config', store.config);
    bus.emitAll('snapshot', snapshot());
    log('💾 Settings saved');
  });

  on('resetConfig', () => {
    const keep = { tiktokUsername: store.config.tiktokUsername, signApiKey: store.config.signApiKey };
    updateConfig({ ...structuredClone(DEFAULT_CONFIG), ...keep });
    bus.emitPanel('config', store.config);
    bus.emitAll('snapshot', snapshot());
    log('↩️ Settings reset to defaults');
  });

  on('simulate', ({ kind, username, nickname, text, amount, asMod, asHost } = {}) => {
    let name = String(username || 'test_viewer').replace(/^@/, '').trim() || 'test_viewer';
    if (asHost) name = store.config.tiktokUsername || 'streamer'; // "as streamer" always sends from your own account
    const u = { username: name, nickname: nickname || name, avatar: '' };
    switch (kind) {
      case 'chat': {
        // simulate TikTok's @mention list
        const mentions = [];
        const m = String(text || '').match(/@([\w.]+)/);
        if (m) mentions.push({ username: m[1], nickname: m[1], avatar: '' });
        return handlers.chat(u, text || '', mentions, { isMod: !!asMod, isHost: !!asHost });
      }
      case 'join': return handlers.join(u);
      case 'viewers': return handlers.viewers(Number(amount) || 0);
      case 'like': return handlers.like(u, Number(amount) || 15);
      case 'follow': return handlers.follow(u);
      case 'share': return handlers.share(u);
      case 'gift': return handlers.gift(u, { diamonds: Number(amount) || 1, giftName: 'Test Gift', count: 1 });
    }
  });

  on('setPoints', ({ username, points }) => {
    if (!store.get(username)) store.touch({ username, nickname: username });
    store.set(username, points);
    log(`✏️ Set ${username} to ${points}`);
    emit('leaderboard', null);
  });

  on('addPoints', ({ username, amount }) => {
    if (!store.get(username)) store.touch({ username, nickname: username });
    store.add(username, Number(amount) || 0);
    log(`➕ Gave ${username} ${amount}`);
    emit('leaderboard', null);
  });

  on('addPointsMany', ({ usernames, amount }) => {
    const n = Math.floor(Number(amount) || 0);
    if (!Array.isArray(usernames) || n <= 0) return;
    let count = 0;
    for (const name of usernames) if (store.get(name)) { store.add(name, n); count++; }
    log(`🎁 Donated ${n} to ${count} viewer${count === 1 ? '' : 's'}`);
    emit('leaderboard', null);
  });

  on('addPointsAll', ({ amount }) => {
    for (const u of Object.values(store.users)) store.add(u.username, Number(amount) || 0);
    log(`🎉 Gave everyone ${amount}`);
    emit('leaderboard', null);
  });

  on('deleteUser', ({ username }) => {
    store.remove(username);
    log(`🗑️ Removed ${username}`);
    emit('leaderboard', null);
  });

  on('resetPoints', () => {
    store.resetAll();
    log(`↩️ Everyone reset to ${store.config.startingPoints}`);
    emit('leaderboard', null);
  });

  on('wipePoints', () => {
    store.wipeAll();
    log('🧹 All viewers deleted');
    emit('leaderboard', null);
  });

  on('cancelGames', () => {
    games.cancelAll();
    log('🛑 Group game and duel requests cancelled (nothing was charged)');
  });

  // Live controls: the panel types a chat command as the streamer (e.g. "!start raid", "!2x 10m").
  on('staffCommand', text => {
    const t = String(text || '').trim();
    if (!t) return;
    const name = store.config.tiktokUsername || 'streamer';
    const u = { username: name, nickname: store.config.host.streamerName || name, avatar: '' };
    const m = t.match(/@([\w.]+)/);
    log(`🎛️ Panel: ${t}`);
    handlers.chat(u, t.startsWith('!') ? t : '!' + t, m ? [{ username: m[1], nickname: m[1], avatar: '' }] : [], { isHost: true });
  });
  on('liveState', (_, reply) => reply?.({ state: games.state(), round: games.rounds.snapshot(), phase: games.rounds.phase }));

  on('setFocus', v => host.setFocus(v));
  on('startDrop', () => host.startDrop());
  on('showHelp', () => host.showHelp());
  on('hostSay', text => {
    const t = String(text || '').trim().slice(0, 200);
    if (t) host.say(t, { priority: 3, kind: 'streamer' });
  });
  on('testAi', async (_, reply) => {
    try {
      const r = await ai.test();
      log(`✅ Google answers work (${r.model}): ${r.answer}`);
      reply?.({ ok: true, ...r });
    } catch (e) {
      log(`❌ Google answers test failed: ${e.message}`);
      reply?.({ ok: false, error: e.message });
    }
  });

  on('testOverlay', () => {
    // a few demo viewers, so the 5 s wait between solo games doesn't block the demo
    const people = ['Demo Viewer', 'Demo Sita', 'Demo Ram', 'Demo Gita'].map(n => ({ username: n.toLowerCase().replace(' ', '_'), nickname: n, avatar: '' }));
    people.forEach(handlers.join);
    const demo = [[0, '!help'], [1, '!daily'], [2, '!slots'], [3, '!gamble'], [0, '!fish'], [1, '!slots'], [2, '!coins'], [3, '!top']];
    demo.forEach(([p, t], i) => setTimeout(() => handlers.chat(people[p], t, []), 1500 + i * 2500));
  });

  // ---------- web edition only ----------
  on('aiKeyChanged', ({ hasKey } = {}) => {
    aiInfo.hasKey = !!hasKey;
    applyKeyFlag();
    bus.emitPanel('config', store.config);
    bus.emitAll('snapshot', snapshot());
    log(hasKey ? '🔑 Google answers key saved' : '🔑 Google answers key removed');
  });
  on('reloadEngine', async () => {
    try { await store.flush(); } catch {}
    reload();
  });

  // ---------- start ----------
  if (store.config.tiktokUsername && autoConnect && store.config.autoReconnect) {
    log(`🔁 Auto-connecting to @${store.config.tiktokUsername}`);
    tiktok.connect(store.config.tiktokUsername, { autoReconnect: true });
  }

  // Page closing or reloading: save. The server keeps the TikTok chat connection for a minute, so a reload
  // picks it straight back up; if the overlay stays closed, the server ends it.
  const shutdown = () => {
    store.flushOnExit();
  };

  return { store, games, host, ai, stream: tiktok, handlers, snapshot, log, logs, shutdown };
}
