// The web edition's storage. It runs the PC edition's own Store class (unchanged) on the in-memory file system
// in vfs.js, and sends what changed to a backend (the site's database, through /api/data/save).
import { vfs } from './vfs.js';

const DIR = '/data';
export const KEY_PLACEHOLDER = 'saved-on-server'; // shown instead of the real Gemini key, which never reaches the browser
const SAVE_GAP_MS = 400; // collects several writes into one request
const CHUNK = 400; // viewers per save request

// Store: the PC edition's Store class (engine/store.js or engine-tiktok/store.js)
// initial: { config, state, users }   backend: { save(payload) → Promise, beacon(payload) }
export function createStore(Store, initial, backend, { onSaveError = () => {} } = {}) {
  vfs.files.clear();
  const saved = new Map(); // viewer key -> JSON text as last sent to the backend
  for (const [k, u] of Object.entries(initial.users || {})) saved.set(k, JSON.stringify(u));
  if (initial.config && Object.keys(initial.config).length) vfs.files.set(`${DIR}/config.json`, JSON.stringify(initial.config));
  vfs.files.set(`${DIR}/points.json`, JSON.stringify(initial.users || {}));
  vfs.files.set(`${DIR}/state.json`, JSON.stringify(initial.state || {}));
  let savedConfig = initial.config ? JSON.stringify(initial.config) : '';
  let savedState = JSON.stringify(initial.state || {});

  // what still has to reach the backend
  const pending = { config: null, state: null, users: new Map(), removed: new Set(), wipe: false, lines: [], backups: [] };
  let timer = null;
  let busy = false;
  let failures = 0;
  let store = null;

  const hasPending = () => pending.config !== null || pending.state !== null || pending.users.size || pending.removed.size || pending.wipe || pending.lines.length || pending.backups.length;

  function collectUsers() {
    const users = store.users;
    const seen = new Set();
    for (const k in users) {
      seen.add(k);
      const text = JSON.stringify(users[k]);
      if (saved.get(k) !== text) {
        saved.set(k, text);
        pending.users.set(k, text);
        pending.removed.delete(k);
      }
    }
    if (seen.size < saved.size) {
      const gone = [...saved.keys()].filter(k => !seen.has(k));
      if (!seen.size && gone.length > 1) {
        pending.wipe = true;
        pending.users.clear();
        pending.removed.clear();
      } else for (const k of gone) { pending.removed.add(k); pending.users.delete(k); }
      for (const k of gone) saved.delete(k);
    }
  }

  // Takes up to CHUNK viewers (and everything else) out of the queue as one request body.
  function takePayload(chunk = CHUNK) {
    const p = {};
    if (pending.wipe) { p.wipe = true; pending.wipe = false; }
    if (pending.config !== null) { p.config = JSON.parse(pending.config); pending.config = null; }
    if (pending.state !== null) { p.state = JSON.parse(pending.state); pending.state = null; }
    if (pending.removed.size) { p.removed = [...pending.removed]; pending.removed.clear(); }
    if (pending.users.size) {
      p.users = {};
      let n = 0;
      for (const [k, text] of pending.users) {
        p.users[k] = JSON.parse(text);
        pending.users.delete(k);
        if (++n >= chunk) break;
      }
    }
    if (pending.lines.length) p.lines = pending.lines.splice(0, 200);
    if (pending.backups.length) p.backups = pending.backups.splice(0, 1);
    return p;
  }

  // A failed request goes back into the queue (newer changes win).
  function putBack(p) {
    if (p.wipe) pending.wipe = true;
    if (p.config && pending.config === null) pending.config = JSON.stringify(p.config);
    if (p.state && pending.state === null) pending.state = JSON.stringify(p.state);
    for (const k of p.removed || []) if (!pending.users.has(k)) pending.removed.add(k);
    for (const [k, u] of Object.entries(p.users || {})) if (!pending.users.has(k) && !pending.removed.has(k)) pending.users.set(k, JSON.stringify(u));
    if (p.lines) pending.lines.unshift(...p.lines);
    if (p.backups) pending.backups.unshift(...p.backups);
  }

  function schedule(ms = SAVE_GAP_MS) {
    if (timer || busy) return;
    timer = setTimeout(() => { timer = null; flush(); }, ms);
  }

  async function flush() {
    if (busy) return;
    clearTimeout(timer);
    timer = null;
    busy = true;
    try {
      while (hasPending()) {
        const p = takePayload();
        try {
          await backend.save(p);
          failures = 0;
        } catch (e) {
          putBack(p);
          failures++;
          onSaveError(e, failures);
          busy = false;
          return schedule(Math.min(30_000, 2000 * failures)); // try again, more slowly each time
        }
      }
    } finally {
      busy = false;
    }
  }

  vfs.onWrite = file => {
    if (!store) return; // still inside the Store constructor; handled just below
    const name = file.slice(DIR.length + 1);
    const text = vfs.files.get(file);
    if (name === 'points.json') collectUsers();
    else if (name === 'config.json') {
      const compact = JSON.stringify(JSON.parse(text));
      if (compact !== savedConfig) { savedConfig = compact; pending.config = compact; }
    } else if (name === 'state.json') {
      const compact = JSON.stringify(JSON.parse(text));
      if (compact !== savedState) { savedState = compact; pending.state = compact; }
    } else if (name.endsWith('.json')) {
      pending.backups.push({ name, data: JSON.parse(text) }); // season backups, the pre-arcade config
    }
    if (name === 'points.json') vfs.files.delete(file); // the viewer list lives in store.users; don't keep a second copy
    if (hasPending()) schedule();
  };
  vfs.onAppend = (file, text) => {
    const name = file.slice(DIR.length + 1);
    for (const line of text.split('\n')) if (line.trim()) { try { pending.lines.push({ file: name, entry: JSON.parse(line) }); } catch {} }
    schedule();
  };

  store = new Store(DIR);
  vfs.files.delete(`${DIR}/points.json`);
  // The constructor fills in new default settings and saves them: pick that up now.
  const compact = JSON.stringify(store.config);
  if (compact !== savedConfig) { savedConfig = compact; pending.config = compact; schedule(); }

  // Extras the web host uses (the engine itself only uses the original Store methods).
  store.flush = async () => { store.savePointsNow(); await flush(); };
  // For page unload: one last request the browser sends even while the page is closing.
  store.flushOnExit = () => {
    store.savePointsNow();
    clearTimeout(timer);
    timer = null;
    let guard = 0;
    while (hasPending() && guard++ < 20) backend.beacon(takePayload(120)); // small bodies: browsers cap closing-page requests at 64 KB
  };
  store.pendingSaves = () => hasPending() || busy;
  return store;
}
