// The sign-in page (/) and the home page after signing in (/app).
import { request, timeLeft } from './api.js';

const $ = s => document.querySelector(s);
const page = document.body.dataset.page;

request('/api/config').then(({ data }) => { if (data.version && $('#ver')) $('#ver').textContent = `v${data.version}`; });

async function loginPage() {
  const msg = (t, bad) => { $('#msg').textContent = t; $('#msg').classList.toggle('bad', !!bad); };
  const note = new URLSearchParams(location.search).get('msg');
  if (note) msg(note, true);
  else if ((await request('/api/me')).data.ok) return location.replace('/app'); // already signed in

  $('#loginForm').onsubmit = async e => {
    e.preventDefault();
    $('#loginBtn').disabled = true;
    msg('Signing in…');
    const { data } = await request('/api/login', { username: $('#username').value, password: $('#password').value });
    $('#loginBtn').disabled = false;
    if (!data.ok) return msg(data.error?.message || "Couldn't sign in", true);
    location.replace('/app');
  };
}

async function appPage() {
  const { status, data } = await request('/api/me');
  if (!data.ok) return location.replace('/' + (status === 401 && data.error?.kind === 'access' ? `?msg=${encodeURIComponent(data.error.message)}` : ''));
  const u = data.user;
  $('#who').textContent = u.username;
  $('#role').textContent = { admin: 'Admin', paid: 'Paid', trial: 'Trial' }[u.role] || u.role;
  $('#role').classList.add(u.role);
  $('#adminLink').hidden = u.role !== 'admin';
  const left = () => {
    if (u.role === 'trial') $('#left').textContent = u.endsAt ? `Your ${u.trialHours}-hour trial ends in ${timeLeft(u.endsAt - Date.now())}. After that this account and its data are deleted. Ask the admin for a paid account to keep it.` : '';
    else if (u.role === 'paid' && u.endsAt) $('#left').textContent = `Your paid time ends in ${timeLeft(u.endsAt - Date.now())} (${new Date(u.endsAt).toLocaleDateString()}).`;
    else $('#left').textContent = 'Pick where you stream. Each has its own coins and settings.';
  };
  left();
  setInterval(left, 30_000);

  $('#logout').onclick = async () => {
    await request('/api/logout', {});
    location.replace('/');
  };
  $('#pwForm').onsubmit = async e => {
    e.preventDefault();
    const m = $('#pwMsg');
    const { data: r } = await request('/api/password', { current: $('#cur').value, next: $('#next').value });
    m.classList.toggle('bad', !r.ok);
    m.textContent = r.ok ? 'Password changed. Other devices were signed out.' : r.error?.message || "Couldn't change the password";
    if (r.ok) e.target.reset();
  };
}

if (page === 'login') loginPage();
if (page === 'app') appPage();
