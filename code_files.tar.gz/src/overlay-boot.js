// Starts the overlay page. overlay.html's own code is wrapped in window.__arcadeStart by the build; this file
// decides whether this overlay runs the game engine or only displays (when another overlay already runs it),
// gives the page its socket, and then starts it.
import { createClient } from '@supabase/supabase-js';
import { siteConfig, sessionKeeper, makeCall, serverBackend, demoBackend } from './api.js';
import { localLink, realtimeLink } from './link.js';
import { EngineBus, RemoteSocket, elect, makeId } from './bus.js';
import { createStore } from './web-store.js';
import { startEngine } from './engine-host.js';

const qs = new URLSearchParams(location.search);

function notice(text) {
  const d = document.createElement('div');
  d.style.cssText = 'position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);max-width:80vw;padding:28px 36px;border-radius:24px;background:rgba(20,16,40,.92);color:#fff;font:800 34px/1.35 Nunito,system-ui,sans-serif;text-align:center;z-index:99999';
  d.textContent = text;
  document.body.appendChild(d);
}

async function main() {
  const site = await siteConfig();
  const token = qs.get('k') || '';
  const demo = !!site.demo || qs.has('demo');
  let link, backend, ytCall, keeper = null, hasAiKey = false;

  if (demo) {
    link = localLink('stream-arcade-demo');
    backend = demoBackend();
    ytCall = makeCall(null); // works only where the server has no accounts set up (your own PC, a test site)
  } else {
    if (!token) return notice('This overlay link is missing its key. Copy the overlay link again from your control panel.');
    keeper = sessionKeeper(async () => {
      const r = await fetch('/api/session', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ overlayToken: token }) });
      const s = await r.json().catch(() => null);
      if (!s?.ok) throw Object.assign(new Error(s?.error?.message || 'Could not sign in the overlay'), { status: r.status });
      return s;
    });
    try {
      await keeper.get();
    } catch (e) {
      if (e.status === 401 || e.status === 404) return notice('This overlay link is no longer valid. Copy the new overlay link from your control panel.');
      notice(`Can't reach the game server (${e.message}). Trying again…`);
      return setTimeout(() => location.reload(), 10_000);
    }
    hasAiKey = !!keeper.last().hasAiKey;
    const supabase = createClient(site.supabaseUrl, site.supabaseAnonKey, { auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false } });
    link = realtimeLink(supabase, `arcade-${keeper.last().channel}`);
    await link.ready;
    const call = makeCall(keeper);
    backend = serverBackend(call, keeper);
    ytCall = call;
    // Buddy's Google answers go through this site's server, which adds the saved key.
    const plainFetch = window.fetch.bind(window);
    window.fetch = async (input, init = {}) => {
      if (typeof input === 'string' && input.startsWith('/api/ai/')) {
        init = { ...init, headers: { ...(init.headers || {}), authorization: `Bearer ${await keeper.get()}` } };
      }
      return plainFetch(input, init);
    };
  }

  const me = { id: makeId(), since: Date.now(), preview: qs.has('preview') };
  const role = await elect(link, me, link.kind === 'local' ? 600 : 1800);

  if (role === 'display') {
    const socket = new RemoteSocket(link, 'display', { onEngineGone: () => location.reload() }); // the engine overlay closed: take over
    window.io = () => socket;
    window.__arcadeStart();
    socket.start();
    window.__arcade = { role };
    return;
  }

  let engine = null;
  const bus = new EngineBus(link, me, {
    onLoseRole: async () => { // a real OBS overlay opened while a preview tab was running the games: hand over
      try { await engine?.store.flush(); } catch {}
      location.reload();
    }
  });
  bus.start();

  let data;
  try {
    data = await backend.load();
  } catch (e) {
    notice(`Couldn't load your coins and settings (${e.message}). Trying again…`);
    return setTimeout(() => location.reload(), 10_000);
  }
  if (bus.lost) return;
  const store = createStore({ config: data.config, state: data.state, users: data.users }, backend, {
    onSaveError: (e, n) => { if (n === 1 || n % 10 === 0) console.warn('Saving failed, will retry:', e.message); }
  });

  window.io = () => bus.socket();
  window.__arcadeStart();
  engine = startEngine({
    store,
    bus,
    api: { find: b => ytCall('/api/yt/find', b), poll: b => ytCall('/api/yt/poll', b) },
    ai: { hasKey: demo ? !!store.config.ai.geminiApiKey : hasAiKey, onServer: !demo },
    reload: () => location.reload()
  });
  bus.page.fire('connect');
  bus.emitAll('status', engine.stream.status);
  bus.emitAll('snapshot', engine.snapshot());
  // Tell a panel that is already open to ask for everything.
  link.send({ k: 'engine', ...me });

  addEventListener('pagehide', () => engine.shutdown());
  window.__arcade = { role, engine };
}

main().catch(e => {
  console.error(e);
  notice(`The overlay couldn't start: ${e.message}`);
});
