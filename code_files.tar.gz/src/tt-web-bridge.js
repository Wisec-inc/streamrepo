// TikTok LIVE chat bridge, overlay side. TikTok's chat is a connection that stays open, so the site's server
// holds it (server/tiktok.js, running the PC edition's own TikTokBridge) and sends everything here over the
// overlay's live link: chat, likes, follows, shares, gifts, joins, viewer count, status and log lines.
// It has the same connect / disconnect / status shape the PC edition's bridge has.
export class TtWebBridge {
  // link: from socketLink() · handlers: { chat, like, follow, share, gift, join, viewers }
  constructor({ onStatus, onLog, handlers, link }) {
    this.onStatus = onStatus;
    this.onLog = onLog;
    this.h = handlers;
    this.link = link;
    this.wanted = false;
    this.status = { state: 'disconnected', username: '', viewers: 0, message: 'Not connected' };
    link.onServer(m => {
      if (!this.wanted) return; // late messages after Disconnect
      if (m.t === 'tt') {
        try { this.h[m.ev]?.(...(m.args || [])); } catch (e) { this.onLog(`⚠️ Skipped a TikTok event: ${e.message}`); }
      } else if (m.t === 'tt-status') this.setStatus(m.status);
      else if (m.t === 'tt-log') this.onLog(m.text);
    });
    // The link came back after a drop (or the server restarted): ask again. The server keeps the chat
    // connection for a minute, so a short drop loses nothing.
    link.onState(up => { if (up && this.wanted) this.#ask(); });
  }

  setStatus(patch) {
    this.status = { ...this.status, ...patch };
    this.onStatus(this.status);
  }
  #ask() { this.link.sendServer({ t: 'tt-connect', username: this.username, autoReconnect: this.autoReconnect }); }

  async connect(username, { autoReconnect = true } = {}) {
    const name = String(username || '').trim();
    if (!name) return this.setStatus({ state: 'error', message: 'Enter a TikTok username first' });
    this.wanted = true;
    this.username = name;
    this.autoReconnect = autoReconnect;
    this.setStatus({ state: 'connecting', username: name.replace(/^@/, ''), message: 'Connecting…' });
    this.#ask();
  }

  async disconnect() {
    this.wanted = false;
    this.link.sendServer({ t: 'tt-disconnect' });
    this.setStatus({ state: 'disconnected', viewers: 0, message: 'Not connected' });
  }
}
