// Starts a control panel page (YouTube or TikTok). The PC edition's panel code is wrapped in
// window.__arcadeStart by the build; this checks the sign-in, works out the private overlay link, connects the
// panel to the overlay that runs the games, and adds the web-only controls (account, new overlay link, import).
import { sessionKeeper, makeCall, request, pagePlatform, PLATFORM_NAMES, timeLeft } from './api.js';
import { socketLink } from './link.js';
import { RemoteSocket } from './bus.js';
import { KEY_PLACEHOLDER } from './web-store.js';

const platform = pagePlatform();
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const toLogin = why => location.replace('/' + (why ? `?msg=${encodeURIComponent(why)}` : ''));

function flash(text) {
  const t = document.querySelector('#toast');
  if (!t) return;
  t.textContent = text;
  t.classList.add('show');
  clearTimeout(flash.t);
  flash.t = setTimeout(() => t.classList.remove('show'), 2600);
}

async function main() {
  const keeper = sessionKeeper(async () => {
    const { status, data } = await request('/api/session', { platform });
    if (!data.ok) {
      if (status === 401 || status === 403) toLogin(data.error?.message);
      throw new Error(data.error?.message || `The server answered ${status}`);
    }
    return data;
  });
  await keeper.get();
  const account = keeper.last();
  let hasAiKey = !!account.hasAiKey;
  const call = makeCall(keeper);
  const overlayUrl = `${location.origin}/${platform}/overlay?k=${account.overlayToken}`;
  const link = socketLink(() => keeper.get(), { onKick: message => toLogin(message) });
  await link.ready;

  const socket = new RemoteSocket(link, 'panel');
  const send = socket.emit.bind(socket);
  socket.emit = (ev, a, cb) => {
    // The Gemini key goes straight to the server and is never sent to the overlay or shown again.
    if (ev === 'saveConfig' && a?.ai) {
      const typed = String(a.ai.geminiApiKey || '').trim();
      const changed = typed !== KEY_PLACEHOLDER && (typed !== '' || hasAiKey);
      let forward = typed === KEY_PLACEHOLDER ? KEY_PLACEHOLDER : ''; // what the overlay is told: "there is a key" or nothing
      if (changed) {
        forward = typed ? KEY_PLACEHOLDER : '';
        call('/api/account', { action: 'setKey', key: typed }).then(r => {
          if (!r.ok) return flash(r.error?.message || "Couldn't save the Google key");
          hasAiKey = !!r.hasAiKey;
          send('aiKeyChanged', { hasKey: hasAiKey });
        });
      }
      a = { ...a, ai: { ...a.ai, geminiApiKey: forward } };
    }
    return send(ev, a, cb);
  };

  window.ARCADE = { overlayUrl, previewUrl: overlayUrl + '&preview', version: '' };
  window.io = () => socket;
  window.__arcadeStart();
  socket.start();
  accountBar({ call, account, send });
}

// ---------- web-only controls, added above the page ----------
function accountBar({ call, account, send }) {
  const u = account.user;
  const bar = document.createElement('div');
  bar.id = 'webBar';
  bar.style.cssText = 'display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:0 auto 14px;max-width:1100px;padding:10px 14px;border-radius:12px;background:rgba(255,255,255,.06);font-size:14px';
  const btn = 'cursor:pointer;border:0;border-radius:8px;padding:7px 12px;font:inherit;font-weight:700;background:rgba(255,255,255,.12);color:inherit;text-decoration:none';
  const kind = { admin: 'Admin', paid: 'Paid', trial: 'Trial' }[u.role] || u.role;
  bar.innerHTML = `<b>${esc(PLATFORM_NAMES[platform])} games</b>
    <span><b>${esc(u.username)}</b> · ${esc(kind)}<span id="wbLeft"></span></span>
    <span style="flex:1"></span>
    <a href="/app" style="${btn}">Home</a>
    <button id="wbImport" style="${btn}" title="Bring the coins from the PC edition's data/points.json">Import coins</button>
    <button id="wbRotate" style="${btn}" title="Makes new private overlay links. The old links stop working.">New overlay link</button>
    <input id="wbFile" type="file" accept=".json,application/json" hidden>`;
  const main = document.querySelector('main') || document.body;
  main.parentNode.insertBefore(bar, main);

  if (u.endsAt) {
    const el = bar.querySelector('#wbLeft');
    const tick = () => {
      const ms = u.endsAt - Date.now();
      el.textContent = ` · ${u.role === 'trial' ? 'trial' : 'paid time'} ends in ${timeLeft(ms)}`;
      el.style.color = ms < 3600_000 ? '#ffcf3f' : '';
    };
    tick();
    setInterval(tick, 30_000);
  }

  bar.querySelector('#wbRotate').onclick = async () => {
    if (!confirm('Make a new overlay link?\n\nThe old links (YouTube and TikTok) stop working at once, so you must paste the new one into OBS or LIVE Studio. Use this if your link was shown on stream or shared by mistake.')) return;
    const r = await call('/api/account', { action: 'rotate' });
    if (!r.ok) return flash(r.error?.message || "Couldn't make a new link");
    location.reload();
  };
  const file = bar.querySelector('#wbFile');
  bar.querySelector('#wbImport').onclick = () => file.click();
  file.onchange = async () => {
    const f = file.files[0];
    file.value = '';
    if (!f) return;
    let users;
    try { users = JSON.parse(await f.text()); } catch { return flash("That file isn't a points.json"); }
    const list = Object.entries(users || {}).filter(([, v]) => v && typeof v === 'object' && v.username && Number.isFinite(Number(v.points)));
    if (!list.length) return flash("That file isn't a points.json (no viewers found in it)");
    if (!confirm(`Import ${list.length} viewers into your ${PLATFORM_NAMES[platform]} games?\n\nViewers with the same name here are replaced by the ones in the file. Everyone else is kept.`)) return;
    for (let i = 0; i < list.length; i += 400) {
      flash(`Importing… ${Math.min(i + 400, list.length)} / ${list.length}`);
      const r = await call('/api/account', { action: 'import', users: Object.fromEntries(list.slice(i, i + 400)) });
      if (!r.ok) return flash(r.error?.message || 'Import failed part-way. Nothing was removed; try again.');
    }
    flash(`Imported ${list.length} viewers`);
    send('reloadEngine'); // the overlay loads the new coins
  };
}

main().catch(e => {
  console.error(e);
  const d = document.createElement('div');
  d.style.cssText = 'margin:40px auto;max-width:640px;padding:20px;border-radius:12px;background:#3a1420;color:#fff;font:600 16px/1.5 system-ui,sans-serif';
  d.textContent = `The control panel couldn't start: ${e.message}. Reload the page; if it keeps happening, sign in again.`;
  document.body.prepend(d);
});
