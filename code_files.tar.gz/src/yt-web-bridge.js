// YouTube Live chat bridge for the web edition. Same job, status messages and retry times as the local
// edition's YouTubeBridge in "Direct" mode, but each step is one request to this site's own server
// (/api/yt/find, /api/yt/poll), because a web page isn't allowed to ask YouTube directly.
import { parseTarget, applyEvent } from '../shared/yt-core.js';

const sleep = ms => new Promise(r => setTimeout(r, ms));
const POLL_BUSY_MS = 1200; // chat is moving
const POLL_QUIET_MS = 2500; // nothing new last time
const META_EVERY_MS = 10_000; // viewer count

export class YtWebBridge {
  // api: { find(body) , poll(body) } → the JSON answer, or { ok:false, error:{ kind, retry, message } }
  constructor({ onStatus, onLog, handlers, api }) {
    this.onStatus = onStatus;
    this.onLog = onLog;
    this.h = handlers; // { chat, join, member, milestone, superchat, giftMemberships, viewers }
    this.api = api;
    this.wanted = false;
    this.retryTimer = null;
    this.status = { state: 'disconnected', username: '', viewers: 0, message: 'Not connected' };
  }

  setStatus(patch) {
    this.status = { ...this.status, ...patch };
    this.onStatus(this.status);
  }

  async connect(input, { autoReconnect = true } = {}) {
    const target = parseTarget(input);
    if (!target) {
      this.setStatus({ state: 'error', message: 'Enter your YouTube channel handle (e.g. @yourname) or your live video link first' });
      return;
    }
    await this.disconnect(false);
    this.wanted = true;
    this.autoReconnect = autoReconnect;
    this.target = target;
    this.input = String(input);
    this.attempts = 0;
    this.#attempt();
  }

  async #attempt() {
    if (!this.wanted) return;
    clearTimeout(this.retryTimer);
    this.attempts++;
    const started = Date.now();
    const secs = () => ((Date.now() - started) / 1000).toFixed(1);
    const label = this.target.label;
    this.setStatus({ state: 'connecting', username: label, message: `Step 1/2 · Looking for ${label}'s live stream…` });
    this.onLog(`🔌 Connecting to ${label} on YouTube (attempt ${this.attempts})`);
    const token = (this.token = Symbol('attempt'));

    const r = await this.api.find({ input: this.input });
    if (this.token !== token) return;
    if (!r.ok) {
      const e = r.error || { message: "Couldn't connect. Retrying in 20s.", retry: 20_000 };
      this.setStatus({ state: 'error', message: e.message });
      this.onLog(`❌ ${e.message}`);
      if (e.details) this.onLog(`   details: ${e.details}`);
      return this.#scheduleRetry(e.retry || 20_000);
    }
    if (!r.live) {
      if (r.videoId) {
        this.setStatus({ state: 'waiting', message: `That video isn't live (anymore). Waiting for ${label}'s next stream…` });
        this.onLog(`⏳ Video ${r.videoId} isn't live, retrying in 30s`);
      } else {
        this.setStatus({ state: 'waiting', message: `${label} isn't live yet. Checking again every 30s…` });
        this.onLog(`⏳ ${label} isn't live yet, checking again in 30s`);
      }
      return this.#scheduleRetry(30_000);
    }

    this.videoId = r.videoId;
    this.connectedAt = Date.now();
    this.seen = new Set();
    this.attempts = 0;
    this.setStatus({ state: 'connected', message: `Live with ${label}: "${String(r.title || '').slice(0, 70)}"` });
    this.onLog(`✅ Connected to ${label}'s live chat in ${secs()}s (video ${r.videoId})`);
    this.#loop(token, r.continuation, label);
  }

  async #loop(token, continuation, label) {
    const mine = () => this.token === token && this.wanted;
    let mcont = '';
    let fails = 0;
    let lastMeta = 0;
    while (mine()) {
      const wantMeta = Date.now() - lastMeta > META_EVERY_MS;
      if (wantMeta) lastMeta = Date.now();
      const r = await this.api.poll({ continuation, videoId: this.videoId, since: this.connectedAt, wantMeta, mcont });
      if (!mine()) return;
      if (!r.ok) {
        const e = r.error || { message: 'no answer', retry: 20_000 };
        if (++fails <= 10) {
          this.onLog(`⚠️ YouTube chat hiccup: ${String(e.details || e.message).slice(0, 160)} (it retries by itself)`);
          await sleep(2000);
          continue;
        }
        this.setStatus({ state: 'error', message: e.message });
        this.onLog(`❌ ${e.message}`);
        return this.#scheduleRetry(e.retry || 20_000);
      }
      fails = 0;
      if (r.mcont) mcont = r.mcont;
      if (r.viewers) {
        this.setStatus({ viewers: r.viewers });
        this.h.viewers?.(r.viewers);
      }
      for (const ev of r.events || []) {
        try {
          applyEvent(ev, this.h, this.seen);
        } catch (e) {
          this.onLog(`⚠️ Skipped a chat item: ${e.message}`);
        }
      }
      if (r.ended || !r.continuation) {
        this.setStatus({ state: 'waiting', message: 'The live stream ended. Waiting for the next one…' });
        this.onLog('🛑 Live stream ended, checking for a new one in 30s');
        return this.#scheduleRetry(30_000);
      }
      continuation = r.continuation;
      await sleep((r.events || []).length ? POLL_BUSY_MS : POLL_QUIET_MS);
    }
  }

  #scheduleRetry(ms) {
    if (!this.wanted || !this.autoReconnect) return;
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this.#attempt(), ms);
  }

  async disconnect(clearWanted = true) {
    if (clearWanted) this.wanted = false;
    clearTimeout(this.retryTimer);
    this.token = null;
    if (clearWanted) this.setStatus({ state: 'disconnected', viewers: 0, message: 'Not connected' });
  }
}
