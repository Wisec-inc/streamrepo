// Stand-ins for socket.io, so overlay.html and panel.html keep their own code.
//   EngineBus     the overlay that runs the game engine (plays the part of server.js's `io`)
//   RemoteSocket  the control panel, and extra overlays that only display
// Messages on the link:
//   { k:'engine', id, since, preview }      heartbeat from the engine overlay
//   { k:'claim',  id, since, preview }      an overlay asking "is an engine already running?"
//   { k:'who', role }                       a panel or display looking for the engine (answered by a heartbeat)
//   { k:'hello', role } / { k:'ping', role }   it found the engine and wants everything / it is still there
//   { k:'ev', room?, t, p }                 engine → pages   (room 'panel' = control panel only)
//   { k:'cmd', ev, a, rid? }                panel → engine   · { k:'reply', rid, p } engine → panel

const HEARTBEAT_MS = 4000;
const LOST_AFTER_MS = 13_000;
const PRESENT_MS = 30_000;
const clone = x => (x === undefined ? undefined : JSON.parse(JSON.stringify(x))); // same as going over a socket

export const makeId = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

class Listeners {
  #map = new Map();
  on(type, fn) {
    if (!this.#map.has(type)) this.#map.set(type, []);
    this.#map.get(type).push(fn);
  }
  fire(type, ...args) {
    for (const fn of this.#map.get(type) || []) { try { fn(...args); } catch (e) { console.error(`[${type}]`, e); } }
  }
}

// Who should run the engine when two overlays meet: a real (OBS) overlay beats a preview tab, then the older one.
export function outranks(a, b) {
  if (!!a.preview !== !!b.preview) return !a.preview;
  if (a.since !== b.since) return a.since < b.since;
  return a.id < b.id;
}

// Asks whether an engine is already running. Resolves 'engine' (nobody better answered) or 'display'.
export function elect(link, me, waitMs) {
  return new Promise(resolve => {
    let done = false;
    const finish = role => { if (!done) { done = true; resolve(role); } };
    link.onMessage(msg => {
      if (done) return;
      if (msg.k === 'engine' && outranks(msg, me)) finish('display');
      if (msg.k === 'claim' && msg.id !== me.id && outranks(msg, me)) finish('display');
    });
    link.send({ k: 'claim', ...me });
    setTimeout(() => finish('engine'), waitMs);
  });
}

export class EngineBus {
  // me: { id, since, preview }   onLoseRole: called when a better overlay takes over the engine
  constructor(link, me, { onLoseRole = () => {} } = {}) {
    this.link = link;
    this.me = me;
    this.page = new Listeners(); // this overlay page's own socket listeners
    this.commands = new Map();
    this.helloFn = () => {};
    this.panelSeen = 0;
    this.displaySeen = 0;
    this.lost = false;
    link.onMessage(msg => {
      if (this.lost) return;
      switch (msg.k) {
        case 'claim':
        case 'engine':
          if (msg.id === me.id) return;
          if (outranks(msg, me)) { this.lost = true; clearInterval(this.beat); onLoseRole(); } else this.#heartbeat();
          return;
        case 'who':
        case 'hello':
        case 'ping':
          if (msg.role === 'panel') this.panelSeen = Date.now(); else this.displaySeen = Date.now();
          if (msg.k === 'who') this.#heartbeat();
          if (msg.k === 'hello') this.helloFn(msg.role);
          return;
        case 'cmd': {
          this.panelSeen = Date.now();
          const fn = this.commands.get(msg.ev);
          if (!fn) return;
          const reply = msg.rid ? p => link.send({ k: 'reply', rid: msg.rid, p: clone(p) }) : undefined;
          try { Promise.resolve(fn(msg.a, reply)).catch(e => console.error(`[${msg.ev}]`, e)); } catch (e) { console.error(`[${msg.ev}]`, e); }
          return;
        }
      }
    });
  }

  #heartbeat() { this.link.send({ k: 'engine', ...this.me }); }
  start() {
    this.#heartbeat();
    this.beat = setInterval(() => this.#heartbeat(), HEARTBEAT_MS);
  }
  stop() { clearInterval(this.beat); }

  get panelPresent() { return Date.now() - this.panelSeen < PRESENT_MS; }
  get displayPresent() { return Date.now() - this.displaySeen < PRESENT_MS; }

  // like io.emit(): this overlay, plus the panel / extra overlays when one is open
  emitAll(type, payload) {
    const p = clone(payload);
    this.page.fire(type, p);
    if (this.displayPresent || (this.panelPresent && PANEL_NEEDS.has(type))) this.link.send({ k: 'ev', t: type, p });
  }
  // like io.to('panel').emit()
  emitPanel(type, payload) {
    if (this.panelPresent) this.link.send({ k: 'ev', room: 'panel', t: type, p: clone(payload) });
  }
  onCommand(ev, fn) { this.commands.set(ev, fn); }
  onHello(fn) { this.helloFn = fn; }

  // what overlay.html gets from io()
  socket() {
    return { on: (type, fn) => this.page.on(type, fn), emit() {} };
  }
}
// the only "everyone" events panel.html listens to
const PANEL_NEEDS = new Set(['status', 'focus', 'snapshot']);

export class RemoteSocket {
  // role: 'panel' or 'display'
  constructor(link, role, { onEngineGone = () => {} } = {}) {
    this.link = link;
    this.role = role;
    this.l = new Listeners();
    this.connected = false;
    this.engineId = '';
    this.lastBeat = 0;
    this.replies = new Map();
    this.rid = 0;
    this.startedAt = Date.now();
    this.onEngineGone = onEngineGone;
    link.onMessage(msg => {
      if (msg.k === 'engine') return this.#beat(msg);
      if (msg.k === 'ev') {
        if (msg.room === 'panel' && role !== 'panel') return;
        return this.l.fire(msg.t, msg.p);
      }
      if (msg.k === 'reply') {
        const fn = this.replies.get(msg.rid);
        this.replies.delete(msg.rid);
        return fn?.(msg.p);
      }
    });
  }

  #beat(msg) {
    this.lastBeat = Date.now();
    if (this.connected && msg.id === this.engineId) return;
    this.engineId = msg.id; // first contact, or the engine overlay was reloaded: ask for everything again
    this.connected = true;
    this.link.send({ k: 'hello', role: this.role });
    this.l.fire('connect');
  }

  start() {
    this.link.send({ k: 'who', role: this.role });
    this.timer = setInterval(() => {
      const now = Date.now();
      if (this.connected && now - this.lastBeat > LOST_AFTER_MS) {
        this.connected = false;
        this.l.fire('disconnect');
        this.onEngineGone();
      } else if (!this.connected) {
        this.link.send({ k: 'who', role: this.role });
        if (!this.waitingShown && now - this.startedAt > 3500) { this.waitingShown = true; this.l.fire('disconnect'); }
      } else if (now - (this.lastPing || 0) > 10_000) {
        this.lastPing = now;
        this.link.send({ k: 'ping', role: this.role });
      }
    }, 2000);
  }

  on(type, fn) { this.l.on(type, fn); }
  emit(ev, a, cb) {
    if (ev === 'hello') return; // the pages' own hello: the link already said it
    if (typeof a === 'function') { cb = a; a = undefined; }
    const msg = { k: 'cmd', ev, a: clone(a) };
    if (typeof cb === 'function') {
      msg.rid = `${this.sid ||= makeId()}-${++this.rid}`;
      this.replies.set(msg.rid, cb);
    }
    this.link.send(msg);
  }
}
