// Starts an overlay page (YouTube or TikTok). The PC edition's overlay code is wrapped in window.__arcadeStart
// by the build; this decides whether this overlay runs the game engine or only displays (when another overlay of
// the same account already runs it), gives the page its socket, and starts it.
import { sessionKeeper, makeCall, serverBackend } from './api.js';
import { socketLink } from './link.js';
import { EngineBus, RemoteSocket, elect, makeId } from './bus.js';
import { createStore } from './web-store.js';

const qs = new URLSearchParams(location.search);

function notice(text) {
  let d = document.querySelector('#arcadeNotice');
  if (!d) {
    d = document.createElement('div');
    d.id = 'arcadeNotice';
    d.style.cssText = 'position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);max-width:80vw;padding:28px 36px;border-radius:24px;background:rgba(20,16,40,.92);color:#fff;font:800 34px/1.35 Nunito,system-ui,sans-serif;text-align:center;z-index:99999';
    document.body.appendChild(d);
  }
  d.textContent = text;
}

// platform: 'youtube' | 'tiktok' · Store: that edition's Store class · startEngine: that edition's host
export async function bootOverlay({ platform, Store, startEngine }) {
  const token = qs.get('k') || '';
  if (!token) return notice('This overlay link is missing its key. Copy the overlay link again from your control panel.');

  const keeper = sessionKeeper(async () => {
    const r = await fetch('/api/session', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ overlayToken: token, platform }) });
    const s = await r.json().catch(() => null);
    if (!s?.ok) throw Object.assign(new Error(s?.error?.message || 'Could not sign in the overlay'), { status: r.status });
    return s;
  });
  try {
    await keeper.get();
  } catch (e) {
    if (e.status === 401 || e.status === 403 || e.status === 404) return notice(e.message || 'This overlay link is no longer valid. Copy the new overlay link from your control panel.');
    notice(`Can't reach the game server (${e.message}). Trying again…`);
    return setTimeout(() => location.reload(), 10_000);
  }
  const hasAiKey = !!keeper.last().hasAiKey;

  let engine = null;
  let ended = false;
  const link = socketLink(() => keeper.get(), {
    onKick: message => { // the account was deleted, switched off or ran out, or the overlay link was replaced
      ended = true;
      try { engine?.shutdown(); } catch {}
      document.querySelector('#stage')?.remove();
      notice(message);
    }
  });
  await link.ready;
  const call = makeCall(keeper);
  const backend = serverBackend(call, keeper);
  // Buddy's Google answers go through this site's server, which adds the saved key.
  const plainFetch = window.fetch.bind(window);
  window.fetch = async (input, init = {}) => {
    if (typeof input === 'string' && input.startsWith('/api/ai/')) {
      init = { ...init, headers: { ...(init.headers || {}), authorization: `Bearer ${await keeper.get()}` } };
    }
    return plainFetch(input, init);
  };

  const me = { id: makeId(), since: Date.now(), preview: qs.has('preview') };
  const role = await elect(link, me, 1800);
  if (ended) return;

  if (role === 'display') {
    const socket = new RemoteSocket(link, 'display', { onEngineGone: () => { if (!ended) location.reload(); } }); // the engine overlay closed: take over
    window.io = () => socket;
    window.__arcadeStart();
    socket.start();
    window.__arcade = { role, platform };
    return;
  }

  const bus = new EngineBus(link, me, {
    onLoseRole: async () => { // a real OBS overlay opened while a preview tab was running the games: hand over
      try { await engine?.store.flush(); } catch {}
      location.reload();
    }
  });
  bus.start();

  let data;
  try {
    data = await backend.load();
  } catch (e) {
    if (ended) return;
    notice(`Couldn't load your coins and settings (${e.message}). Trying again…`);
    return setTimeout(() => location.reload(), 10_000);
  }
  if (bus.lost || ended) return;
  const store = createStore(Store, { config: data.config, state: data.state, users: data.users }, backend, {
    onSaveError: (e, n) => { if (n === 1 || n % 10 === 0) console.warn('Saving failed, will retry:', e.message); }
  });

  window.io = () => bus.socket();
  window.__arcadeStart();
  engine = startEngine({
    store,
    bus,
    link,
    api: { find: b => call('/api/yt/find', b), poll: b => call('/api/yt/poll', b) },
    ai: { hasKey: hasAiKey, onServer: true },
    reload: () => location.reload()
  });
  bus.page.fire('connect');
  bus.emitAll('status', engine.stream.status);
  bus.emitAll('snapshot', engine.snapshot());
  link.send({ k: 'engine', ...me }); // tell a panel that is already open to ask for everything

  addEventListener('pagehide', () => engine.shutdown());
  window.__arcade = { role, platform, engine };
}

export function bootFailed(e) {
  console.error(e);
  notice(`The overlay couldn't start: ${e.message}`);
}
