// A tiny in-memory stand-in for node:fs, so the local edition's Store (engine/store.js) runs unchanged in a
// browser. The build points "node:fs" at this file. Writes are reported through vfs.onWrite / vfs.onAppend,
// and the web store turns them into saves to the backend.
const files = new Map();

export const vfs = {
  files,
  onWrite: null, // (path) => void, after a file was written or renamed into place
  onAppend: null // (path, text) => void
};

function missing(p) {
  const e = new Error(`ENOENT: no such file, open '${p}'`);
  e.code = 'ENOENT';
  return e;
}

const fs = {
  mkdirSync() {},
  existsSync: p => files.has(p),
  readFileSync(p) {
    if (!files.has(p)) throw missing(p);
    return files.get(p);
  },
  writeFileSync(p, text) {
    files.set(p, String(text));
    if (!p.endsWith('.tmp')) vfs.onWrite?.(p);
  },
  renameSync(from, to) {
    if (!files.has(from)) throw missing(from);
    files.set(to, files.get(from));
    files.delete(from);
    vfs.onWrite?.(to);
  },
  appendFileSync(p, text) {
    vfs.onAppend?.(p, String(text));
  }
};

export default fs;
