// The admin panel (/admin): create accounts, change their type, set paid-until, reset passwords, switch off,
// delete, and set the server's TikTok connection key. The server checks every request is from an admin.
import { request, timeLeft } from './api.js';

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const say = (el, text, bad) => { el.textContent = text; el.classList.toggle('bad', !!bad); };
const day = t => (t ? new Date(t).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '—');
const dateValue = t => (t ? new Date(t - new Date(t).getTimezoneOffset() * 60_000).toISOString().slice(0, 10) : '');
// a date picked in the form means "until the end of that day"
const endOfDay = v => (v ? new Date(`${v}T23:59:59`).getTime() : null);
let trialHours = 12;

function password() {
  const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const r = crypto.getRandomValues(new Uint32Array(14));
  return [...r].map(n => chars[n % chars.length]).join('');
}

function roleHelp() {
  const role = $('#cRole').value;
  $('#cUntilBox').hidden = role !== 'paid';
  $('#cHelp').textContent = role === 'trial' ? `Trial: ${trialHours} hours from their first sign-in, then the account and its data are deleted.`
    : role === 'paid' ? 'Paid: YouTube and TikTok. After the paid-until date the account is locked, not deleted.'
      : 'Admin: everything, including this page.';
}

function statusOf(u) {
  if (u.disabled) return '<span class="tag off">Switched off</span>';
  if (!u.active) return `<span class="tag off">${u.reason === 'paid-ended' ? 'Paid time ended' : 'Ended'}</span>`;
  if (u.locked) return '<span class="tag off">Locked (wrong passwords)</span>';
  return `<span class="dot ${u.online ? 'on' : ''}"></span>${u.online ? 'Online now' : 'Active'}`;
}
function endsOf(u) {
  if (u.role === 'admin') return '—';
  if (u.role === 'trial') return u.endsAt ? `in ${timeLeft(u.endsAt - Date.now())}` : 'not started';
  return u.paidUntil ? `${new Date(u.paidUntil).toLocaleDateString()}` : 'no end';
}

async function load() {
  const { status, data } = await request('/api/admin/users');
  if (!data.ok) {
    if (status === 401) return location.replace('/');
    if (status === 403) return location.replace('/app');
    return say($('#uMsg'), data.error?.message || "Couldn't load the accounts", true);
  }
  trialHours = data.trialHours;
  roleHelp();
  $('#count').textContent = `${data.users.length}`;
  $('#euler').placeholder = data.hasEulerKey ? 'a key is saved (paste a new one to replace it; leave empty and save to remove it)' : 'paste the key (none saved: the free shared allowance is used)';
  $('#rows').innerHTML = data.users.map(u => `<tr data-id="${esc(u.id)}" data-name="${esc(u.username)}" data-until="${u.paidUntil || ''}">
    <td><b>${esc(u.username)}</b>${u.you ? ' <span class="dim">(you)</span>' : ''}</td>
    <td><select data-act="role" ${u.you ? 'disabled' : ''} style="width:auto;padding:6px 9px">
      ${['admin', 'paid', 'trial'].map(r => `<option value="${r}" ${r === u.role ? 'selected' : ''}>${r[0].toUpperCase() + r.slice(1)}</option>`).join('')}</select></td>
    <td>${statusOf(u)}</td>
    <td>${day(u.firstLoginAt)}</td>
    <td>${endsOf(u)}</td>
    <td>${u.viewers.toLocaleString()}</td>
    <td class="acts">
      ${u.role === 'paid' ? '<button class="sm alt" data-act="until">Paid until</button>' : ''}
      <button class="sm alt" data-act="pass">Reset password</button>
      ${u.you ? '' : `<button class="sm alt" data-act="toggle" data-off="${u.disabled ? 1 : 0}">${u.disabled ? 'Switch on' : 'Switch off'}</button>
      <button class="sm danger" data-act="delete">Delete</button>`}
    </td></tr>`).join('');
}

async function update(id, patch, done) {
  const { data } = await request('/api/admin/users/update', { id, ...patch });
  say($('#uMsg'), data.ok ? done : data.error?.message || "Couldn't save", !data.ok);
  load();
}

$('#rows').addEventListener('change', e => {
  const sel = e.target.closest('select[data-act=role]');
  if (!sel) return;
  const tr = sel.closest('tr');
  const role = sel.value;
  if (role === 'trial' && !confirm(`Make ${tr.dataset.name} a Trial account?\n\nTrial accounts are deleted, with all their coins and settings, ${trialHours} hours after their first sign-in.`)) return load();
  update(tr.dataset.id, { role }, `${tr.dataset.name} is now ${role}.`);
});

$('#rows').addEventListener('click', async e => {
  const b = e.target.closest('button[data-act]');
  if (!b) return;
  const tr = b.closest('tr');
  const { id, name } = tr.dataset;
  if (b.dataset.act === 'until') {
    const v = prompt(`Paid until which date for ${name}? (YYYY-MM-DD)\nLeave empty for no end date.`, dateValue(Number(tr.dataset.until) || 0));
    if (v === null) return;
    if (v.trim() && !/^\d{4}-\d{2}-\d{2}$/.test(v.trim())) return say($('#uMsg'), 'Type the date as YYYY-MM-DD, for example 2027-01-31.', true);
    return update(id, { paidUntil: endOfDay(v.trim()) ?? '' }, v.trim() ? `${name} is paid until ${v.trim()}.` : `${name} has no end date.`);
  }
  if (b.dataset.act === 'pass') {
    const p = prompt(`New password for ${name} (8 or more characters).\nThey are signed out everywhere.`, password());
    if (p === null) return;
    return update(id, { password: p }, `Password for ${name} changed. Give it to them now: it isn't shown again.`);
  }
  if (b.dataset.act === 'toggle') return update(id, { disabled: b.dataset.off !== '1' }, b.dataset.off === '1' ? `${name} is switched on.` : `${name} is switched off and signed out.`);
  if (b.dataset.act === 'delete') {
    if (!confirm(`Delete ${name}?\n\nThis removes the account and all its coins, settings and logs for YouTube and TikTok. It can't be undone.`)) return;
    const { data } = await request('/api/admin/users/delete', { id });
    say($('#uMsg'), data.ok ? `${name} was deleted.` : data.error?.message || "Couldn't delete", !data.ok);
    load();
  }
});

$('#cRole').onchange = roleHelp;
$('#genPass').onclick = () => { $('#cPass').value = password(); };
$('#createForm').onsubmit = async e => {
  e.preventDefault();
  const body = { username: $('#cUser').value.trim(), password: $('#cPass').value, role: $('#cRole').value };
  if (body.role === 'paid') body.paidUntil = endOfDay($('#cUntil').value) ?? '';
  const { data } = await request('/api/admin/users/create', body);
  if (!data.ok) return say($('#cMsg'), data.error?.message || "Couldn't create the account", true);
  say($('#cMsg'), `Created ${body.username}. Password: ${body.password}  (copy it now: it isn't shown again)`);
  $('#cUser').value = '';
  $('#cPass').value = '';
  load();
};

$('#eulerForm').onsubmit = async e => {
  e.preventDefault();
  const { data } = await request('/api/admin/settings', { eulerKey: $('#euler').value.trim() });
  say($('#eMsg'), data.ok ? (data.hasEulerKey ? 'Key saved. It is used for new TikTok connections.' : 'Key removed. The free shared allowance is used.') : data.error?.message || "Couldn't save", !data.ok);
  $('#euler').value = '';
  load();
};
$('#refresh').onclick = load;

roleHelp();
load();
setInterval(load, 30_000);
