// Small helpers for talking to this site's own server (/api/...).

export const PLATFORM_NAMES = { youtube: 'YouTube', tiktok: 'TikTok' };
// The platform is the first part of the page address: /youtube/panel, /tiktok/overlay
export const pagePlatform = () => (location.pathname.split('/')[1] === 'tiktok' ? 'tiktok' : 'youtube');

// Plain JSON request with the sign-in cookie. → { status, data }
export async function request(path, body, method = body === undefined ? 'GET' : 'POST') {
  try {
    const res = await fetch(path, { method, credentials: 'same-origin', headers: body === undefined ? {} : { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    const data = await res.json().catch(() => null);
    return { status: res.status, data: data || { ok: false, error: { message: `The server answered ${res.status}` } } };
  } catch (e) {
    return { status: 0, data: { ok: false, error: { message: `Can't reach the server (${e.message})` } } };
  }
}

// Keeps a short-lived server session fresh. fetchNew() → { session, exp, ... } or throws.
export function sessionKeeper(fetchNew) {
  let cur = null;
  let inflight = null;
  return {
    async get() {
      if (cur && cur.exp - Date.now() > 60_000) return cur.session;
      inflight ||= fetchNew().then(s => { cur = s; return s; }).finally(() => { inflight = null; });
      return (await inflight).session;
    },
    peek: () => (cur && cur.exp > Date.now() ? cur.session : ''),
    last: () => cur,
    clear() { cur = null; }
  };
}

// POST JSON with the page's session. Never throws: failures come back as { ok:false, error:{ kind, retry, message } }.
export function makeCall(keeper) {
  return async function call(path, body) {
    for (let tries = 0; tries < 2; tries++) {
      try {
        const headers = { 'content-type': 'application/json' };
        headers.authorization = `Bearer ${await keeper.get()}`;
        const res = await fetch(path, { method: 'POST', headers, body: JSON.stringify(body || {}) });
        if (res.status === 401 && tries === 0) { keeper.clear(); continue; } // session ran out: get a new one, once
        const data = await res.json().catch(() => null);
        if (data && typeof data === 'object') return data;
        return { ok: false, error: { kind: 'other', retry: 20_000, message: `The server answered with an error (${res.status}). Retrying in 20s.` } };
      } catch (e) {
        return { ok: false, error: { kind: 'network', retry: 20_000, message: `Can't reach the server (${e.message}). Check your internet. Retrying in 20s.`, details: String(e.message) } };
      }
    }
  };
}

// Saving: the database, through the server.
export function serverBackend(call, keeper) {
  return {
    async load() {
      const r = await call('/api/data/load');
      if (!r.ok) throw new Error(r.error?.message || 'Could not load your data');
      return r;
    },
    async save(payload) {
      const r = await call('/api/data/save', payload);
      if (!r.ok) throw new Error(r.error?.message || 'Could not save');
    },
    beacon(payload) {
      const s = keeper.peek();
      if (!s) return;
      try {
        fetch('/api/data/save', { method: 'POST', keepalive: true, headers: { 'content-type': 'application/json', authorization: `Bearer ${s}` }, body: JSON.stringify(payload) }).catch(() => {});
      } catch {}
    }
  };
}

// "11 h 32 min", "45 min", "3 days"
export function timeLeft(ms) {
  if (ms <= 0) return 'ended';
  const min = Math.ceil(ms / 60_000);
  if (min < 60) return `${min} min`;
  if (min < 48 * 60) return `${Math.floor(min / 60)} h ${min % 60} min`;
  return `${Math.floor(min / 1440)} days`;
}
