// The YouTube overlay: the YouTube PC edition's engine (engine/) with the web host.
import { Store } from '../engine/store.js';
import { startEngine } from './engine-host.js';
import { bootOverlay, bootFailed } from './overlay-common.js';

bootOverlay({ platform: 'youtube', Store, startEngine }).catch(bootFailed);
