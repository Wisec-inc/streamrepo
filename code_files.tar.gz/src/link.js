// The message link between the overlay (where the game engine runs), the control panel and extra overlays:
// one WebSocket to this site's server (/live), which passes messages only between pages of the same account
// and platform. It reconnects by itself. Interface: send(msg), onMessage(fn), onState(fn), plus
// sendServer(msg) / onServer(fn) for messages to and from the server itself (TikTok chat, "access ended").

const BATCH_MS = 100; // several messages become one packet

// getSession(): → a fresh session string (it is refreshed for every reconnect). onKick(message): access ended.
export function socketLink(getSession, { onKick = () => {} } = {}) {
  const listeners = new Set();
  const stateListeners = new Set();
  const serverListeners = new Set();
  let ws = null;
  let up = false;
  let closed = false;
  let wait = 1000;
  let queue = [];
  let timer = null;
  let serverQueue = [];
  let readyDone;
  const ready = new Promise(r => { readyDone = r; });
  setTimeout(readyDone, 8000); // don't hold the page forever; it keeps trying by itself

  const each = (set, ...args) => { for (const fn of set) { try { fn(...args); } catch (e) { console.error(e); } } };
  const setUp = v => { if (v !== up) { up = v; each(stateListeners, up); } };

  async function open() {
    if (closed) return;
    let s;
    try {
      s = await getSession();
    } catch {
      return void setTimeout(open, (wait = Math.min(wait * 2, 15_000)));
    }
    if (closed) return;
    ws = new WebSocket(`${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/live?s=${encodeURIComponent(s)}`);
    ws.onopen = () => {
      wait = 1000;
      for (const m of serverQueue.splice(0)) ws.send(JSON.stringify({ srv: m }));
      setUp(true);
      readyDone();
    };
    ws.onmessage = e => {
      let m;
      try { m = JSON.parse(e.data); } catch { return; }
      if (m.srv) {
        if (m.srv.t === 'kick') { closed = true; onKick(m.srv.message || 'Your access has ended.'); }
        return each(serverListeners, m.srv);
      }
      for (const msg of m.b || []) each(listeners, msg);
    };
    ws.onclose = () => {
      setUp(false);
      if (!closed) setTimeout(open, (wait = Math.min(wait * 2, 15_000)));
    };
    ws.onerror = () => {};
  }
  open();

  const flush = () => {
    timer = null;
    const b = queue;
    queue = [];
    if (b.length && up) { try { ws.send(JSON.stringify({ b })); } catch {} }
  };
  return {
    ready,
    send(msg) {
      queue.push(msg);
      if (!timer) timer = setTimeout(flush, BATCH_MS);
    },
    flushNow() { clearTimeout(timer); flush(); },
    onMessage: fn => listeners.add(fn),
    onState: fn => { stateListeners.add(fn); fn(up); },
    // to and from the server itself
    sendServer(msg) {
      if (up) { try { return ws.send(JSON.stringify({ srv: msg })); } catch {} }
      serverQueue = serverQueue.filter(m => m.t !== msg.t).concat(msg); // only the latest of each kind matters
    },
    onServer: fn => serverListeners.add(fn),
    close() { closed = true; try { ws?.close(); } catch {} }
  };
}
