// TikTok LIVE chat for the web edition. TikTok's chat is a connection that stays open, so it lives here on the
// server: one per streamer who is connected, using the PC edition's own TikTokBridge (tiktok-bridge/tiktok.js,
// an unchanged copy). Everything the bridge reports (chat, likes, follows, shares, gifts, joins, viewer count,
// status, log lines) is passed to that streamer's overlay, where the game engine runs.
import { TikTokBridge } from './tiktok-bridge/tiktok.js';

const GRACE_MS = 60_000; // keep the chat connection this long after the overlay disappears (reloads, short drops)
const EVENTS = ['chat', 'like', 'follow', 'share', 'gift', 'join', 'viewers'];
const cleanName = u => String(u || '').trim().replace(/^https?:\/\/(www\.)?tiktok\.com\//i, '').replace(/^@/, '').replace(/\/live.*$/i, '').replace(/[/?#].*$/, '').toLowerCase();
// The bridge's hints were written for the PC app's own settings page.
const forWeb = text => String(text)
  .replace(/Add a free Euler Stream key under Advanced, or wait/g, 'Ask the site admin to add an Euler Stream key, or wait')
  .replace(/If this keeps happening, add a free Euler Stream key under Advanced\./g, 'If this keeps happening, tell the site admin.')
  .replace(/Get one at eulerstream\.com, paste it under Advanced, then press Connect\./g, 'Tell the site admin (it is set in the admin panel).')
  .replace(/create a free key at eulerstream\.com and paste it under Advanced/g, 'tell the site admin, who can add an Euler Stream key')
  .replace(/a free key from eulerstream\.com under Advanced, /g, '')
  .replace(/Can't reach TikTok from this PC/g, "The game server can't reach TikTok")
  .replace(/ Check your internet, VPN or firewall\./g, '');

// send(ws, msg): hub.send.  signKey(): the server-wide Euler Stream key ('' = the free shared service).
// makeBridge: for tests.
export function createTikTokManager({ send, signKey = () => '', max = Number(process.env.MAX_TIKTOK) || 300, makeBridge = opts => new TikTokBridge(opts) }) {
  const live = new Map(); // user id → { bridge, owner (socket), name, grace }

  function connect(ws, { username, autoReconnect = true } = {}) {
    const sid = ws.meta.sid;
    const name = cleanName(username);
    let e = live.get(sid);
    if (e) clearTimeout(e.grace);
    if (e && e.name === name && name && e.bridge.wanted) {
      e.owner = ws; // the overlay came back (reload): keep the chat connection, just point it at the new page
      return send(ws, { t: 'tt-status', status: { ...e.bridge.status, message: forWeb(e.bridge.status.message) } });
    }
    if (e) { e.bridge.disconnect().catch(() => {}); live.delete(sid); }
    if (live.size >= max) return send(ws, { t: 'tt-status', status: { state: 'error', username: name, viewers: 0, message: 'The server is at its limit of TikTok connections right now. Try again later.' } });
    e = { owner: ws, name };
    const handlers = Object.fromEntries(EVENTS.map(ev => [ev, (...args) => send(e.owner, { t: 'tt', ev, args })]));
    e.bridge = makeBridge({
      onStatus: s => send(e.owner, { t: 'tt-status', status: { ...s, message: forWeb(s.message) } }),
      onLog: text => send(e.owner, { t: 'tt-log', text: forWeb(text) }),
      handlers
    });
    live.set(sid, e);
    e.bridge.connect(username, { signApiKey: signKey(), autoReconnect: autoReconnect !== false, mode: 'service' }).catch(err => console.error('[tiktok]', err));
  }

  async function drop(sid) {
    const e = live.get(sid);
    if (!e) return;
    clearTimeout(e.grace);
    live.delete(sid);
    try { await e.bridge.disconnect(); } catch {}
  }

  // An overlay sent { srv: msg }
  function onMessage(ws, msg) {
    if (ws.meta.role !== 'overlay' || ws.meta.p !== 'tiktok') return;
    if (msg.t === 'tt-connect') connect(ws, msg);
    else if (msg.t === 'tt-disconnect') drop(ws.meta.sid);
  }
  function onClose(ws) {
    const e = live.get(ws.meta?.sid);
    if (!e || e.owner !== ws) return;
    clearTimeout(e.grace);
    e.grace = setTimeout(() => drop(ws.meta.sid), GRACE_MS);
    e.grace.unref?.();
  }
  const stopAll = () => Promise.all([...live.keys()].map(drop));
  return { onMessage, onClose, drop, stopAll, count: () => live.size, has: sid => live.has(sid) };
}
