// The site's database: one SQLite file on the server (Node's built-in node:sqlite, nothing to install).
// Accounts, and per user and per platform ('youtube' | 'tiktok'): settings, game state and viewers' coins.
// Every game-data function takes the user's id and the platform, so one user can never touch another's rows.
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

let d = null;
const stmts = new Map();
const q = sql => {
  if (!stmts.has(sql)) stmts.set(sql, d.prepare(sql));
  return stmts.get(sql);
};

export const PLATFORMS = ['youtube', 'tiktok'];
// same rule as the game's Store.key()
export const viewerKey = name => String(name || '').replace(/^@/, '').trim().toLowerCase();

// file: a path, or ':memory:' for tests
export function openDb(file) {
  closeDb();
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  d = new DatabaseSync(file);
  d.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000;
    CREATE TABLE IF NOT EXISTS users (
      id             TEXT PRIMARY KEY,
      username       TEXT NOT NULL UNIQUE COLLATE NOCASE,
      pass           TEXT NOT NULL,                 -- scrypt hash, never the password
      pass_version   INTEGER NOT NULL DEFAULT 1,    -- raised on every password change: older sign-ins stop working
      role           TEXT NOT NULL CHECK (role IN ('admin','paid','trial')),
      disabled       INTEGER NOT NULL DEFAULT 0,
      created_at     INTEGER NOT NULL,
      first_login_at INTEGER,                       -- a trial's 12 hours start here
      paid_until     INTEGER,                       -- paid users: optional end date (ms); NULL = no end
      overlay_token  TEXT NOT NULL UNIQUE,          -- the secret part of the overlay links
      ai_key         TEXT,                          -- Gemini key, encrypted
      fails          INTEGER NOT NULL DEFAULT 0,    -- wrong passwords in a row
      locked_until   INTEGER NOT NULL DEFAULT 0,
      note           TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS games (
      user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      platform TEXT NOT NULL,
      config   TEXT NOT NULL DEFAULT '{}',          -- data/config.json in the PC editions
      state    TEXT NOT NULL DEFAULT '{}',          -- data/state.json
      PRIMARY KEY (user_id, platform)
    );
    CREATE TABLE IF NOT EXISTS viewers (
      user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      platform   TEXT NOT NULL,
      key        TEXT NOT NULL,                     -- lowercase username
      data       TEXT NOT NULL,                     -- data/points.json, one viewer per row
      updated_at INTEGER NOT NULL,
      PRIMARY KEY (user_id, platform, key)
    );
    CREATE TABLE IF NOT EXISTS staff_log (
      id INTEGER PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      platform TEXT NOT NULL, file TEXT NOT NULL, entry TEXT NOT NULL, created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS backups (
      id INTEGER PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      platform TEXT NOT NULL, name TEXT NOT NULL, data TEXT, created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS staff_log_user ON staff_log (user_id, platform, id);
    CREATE INDEX IF NOT EXISTS backups_user ON backups (user_id, platform, id);
  `);
  return d;
}
export function closeDb() {
  stmts.clear();
  try { d?.close(); } catch {}
  d = null;
}
const tx = fn => {
  d.exec('BEGIN IMMEDIATE');
  try {
    const r = fn();
    d.exec('COMMIT');
    return r;
  } catch (e) {
    d.exec('ROLLBACK');
    throw e;
  }
};
const parse = (text, fallback) => { try { return JSON.parse(text); } catch { return fallback; } };

// ---------- settings (server-wide) ----------
export const getSetting = key => q('SELECT value FROM settings WHERE key = ?').get(key)?.value ?? '';
export const setSetting = (key, value) => { q('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, String(value)); };

// ---------- users ----------
export const userById = id => q('SELECT * FROM users WHERE id = ?').get(String(id)) || null;
export const userByUsername = name => q('SELECT * FROM users WHERE username = ?').get(String(name)) || null;
export const userByOverlayToken = token => q('SELECT * FROM users WHERE overlay_token = ?').get(String(token)) || null;
export const listUsers = () => q('SELECT * FROM users ORDER BY created_at').all();
export const countAdmins = () => q("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND disabled = 0").get().n;

export function insertUser(u) {
  q('INSERT INTO users (id, username, pass, role, created_at, paid_until, overlay_token, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(u.id, u.username, u.pass, u.role, u.created_at, u.paid_until ?? null, u.overlay_token, u.note || '');
  return userById(u.id);
}
const USER_COLS = new Set(['username', 'pass', 'pass_version', 'role', 'disabled', 'first_login_at', 'paid_until', 'overlay_token', 'ai_key', 'fails', 'locked_until', 'note']);
export function updateUser(id, patch) {
  const cols = Object.keys(patch).filter(c => USER_COLS.has(c));
  if (!cols.length) return;
  d.prepare(`UPDATE users SET ${cols.map(c => `${c} = ?`).join(', ')} WHERE id = ?`).run(...cols.map(c => patch[c] ?? null), String(id));
}
// Removes the account and, through the foreign keys, all its settings, coins, logs and backups.
export const deleteUser = id => { q('DELETE FROM users WHERE id = ?').run(String(id)); };
export const viewerCount = id => q('SELECT COUNT(*) AS n FROM viewers WHERE user_id = ?').get(String(id)).n;

// ---------- game data ----------
export function loadAll(id, platform) {
  const row = q('SELECT config, state FROM games WHERE user_id = ? AND platform = ?').get(id, platform);
  const users = {};
  for (const v of q('SELECT key, data FROM viewers WHERE user_id = ? AND platform = ?').all(id, platform)) users[v.key] = parse(v.data, {});
  return { config: parse(row?.config, {}), state: parse(row?.state, {}), users };
}

// One save from the overlay, applied all-or-nothing.
// { wipe?, config?, state?, removed?: [keys], users?: { key: {...} }, lines?: [{ file, entry }], backups?: [{ name, data }] }
export function saveGame(id, platform, p) {
  tx(() => {
    const now = Date.now();
    if (p.config || p.state) {
      q("INSERT INTO games (user_id, platform) VALUES (?, ?) ON CONFLICT(user_id, platform) DO NOTHING").run(id, platform);
      if (p.config) q('UPDATE games SET config = ? WHERE user_id = ? AND platform = ?').run(JSON.stringify(p.config), id, platform);
      if (p.state) q('UPDATE games SET state = ? WHERE user_id = ? AND platform = ?').run(JSON.stringify(p.state), id, platform);
    }
    if (p.wipe) q('DELETE FROM viewers WHERE user_id = ? AND platform = ?').run(id, platform);
    for (const k of p.removed || []) q('DELETE FROM viewers WHERE user_id = ? AND platform = ? AND key = ?').run(id, platform, k);
    const up = q('INSERT INTO viewers (user_id, platform, key, data, updated_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(user_id, platform, key) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at');
    for (const [k, u] of Object.entries(p.users || {})) up.run(id, platform, k, JSON.stringify(u), now);
    for (const l of p.lines || []) q('INSERT INTO staff_log (user_id, platform, file, entry, created_at) VALUES (?, ?, ?, ?, ?)').run(id, platform, String(l.file || '').slice(0, 80), JSON.stringify(l.entry ?? null), now);
    for (const b of p.backups || []) q('INSERT INTO backups (user_id, platform, name, data, created_at) VALUES (?, ?, ?, ?, ?)').run(id, platform, String(b.name).slice(0, 120), JSON.stringify(b.data ?? null), now);
  });
}
