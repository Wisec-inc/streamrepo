// The PC edition's "My own browser" mode opens a Chrome window on the streamer's PC. A server has no such
// window, so this stand-in exists only so tiktok.js (an unchanged copy) can be loaded. The web edition always
// uses the bridge's other mode ('service'), so this class is never started.
import { EventEmitter } from 'node:events';

export class BrowserReader extends EventEmitter {
  browserName = '';
  async open() {
    throw Object.assign(new Error('Browser mode is not available on the server'), { code: 'NO_BROWSER' });
  }
  async close() {}
}
