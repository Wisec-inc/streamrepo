// Wraps tiktok-live-connector: connect/disconnect, auto-retry while waiting for the
// stream to go live, and converts TikTok's raw events into simple objects for the games.
import { TikTokLiveConnection, WebcastEvent, ControlEvent, SignConfig } from 'tiktok-live-connector';
import { BrowserReader } from './browser-reader.js';

// The sign service client (Euler Stream) has no timeout of its own: one slow reply used to leave the app
// on "Connecting…" forever. Give every sign request 20 s.
SignConfig.baseOptions = { ...(SignConfig.baseOptions || {}), timeout: 20_000 };

export const STEP_TIMEOUT = { roomId: 30_000, live: 20_000, connect: 60_000 };
// "My own browser" mode: how long to wait for the first chat data, and how long silence means the page is stuck.
export const BROWSER_WAIT = { open: 60_000, first: Number(process.env.BROWSER_WAIT_FIRST_MS) || 60_000, idle: Number(process.env.BROWSER_WAIT_IDLE_MS) || 120_000, tick: Number(process.env.BROWSER_WAIT_TICK_MS) || 5000 };

class StepTimeout extends Error {}
function withTimeout(promise, ms, what) {
  let t;
  return Promise.race([
    promise,
    new Promise((_, rej) => { t = setTimeout(() => rej(new StepTimeout(what)), ms); })
  ]).finally(() => clearTimeout(t));
}

// Turns library errors into something a streamer can act on.
export function explainError(err, username) {
  const name = err?.constructor?.name || '';
  const text = String(err?.message || err || '');
  const all = `${name} ${text} ${err?.code || ''} ${err?.cause?.code || ''}`;
  if (err instanceof StepTimeout) {
    return { kind: 'timeout', retry: 20_000, message: `TikTok didn't answer in time (${text}). Retrying in 20s. If this keeps happening, add a free Euler Stream key under Advanced.` };
  }
  if (name.includes('Offline') || /offline|not live|isn't live|isn't online|LIVE has ended/i.test(text)) {
    return { kind: 'offline', retry: 30_000, message: `@${username} isn't live yet. Checking again every 30s…` };
  }
  if (/RateLimit|rate limit|429|too many/i.test(all)) {
    return { kind: 'ratelimit', retry: 60_000, message: 'The free connection service is busy (rate limit). Add a free Euler Stream key under Advanced, or wait; retrying in 60s.' };
  }
  if (/business plan|purchase one|pricing|paid plan|402/i.test(all)) {
    return { kind: 'paid', retry: 120_000, message: 'The connection service (Euler Stream) blocked a paid-only step. Make sure you are running the latest version of this app, which skips it. Retrying in 2 min.' };
  }
  if (/SignAPI|Premium|permission|api key|apikey|unauthori[sz]ed|401|403/i.test(all)) {
    return { kind: 'sign', retry: 60_000, message: 'The connection service needs a free API key. Get one at eulerstream.com, paste it under Advanced, then press Connect. Retrying in 60s.' };
  }
  if (/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ECONNRESET|ETIMEDOUT|ENETUNREACH|socket hang up|network|getaddrinfo|certificate|TLS/i.test(all)) {
    return { kind: 'network', retry: 20_000, message: `Can't reach TikTok from this PC (${text}). Check your internet, VPN or firewall. Retrying in 20s.` };
  }
  // "Failed to retrieve Room ID from all sources" carries the real reasons inside
  const subs = err?.config?.requestErrs || [];
  if (subs.length) {
    const subText = subs.map(x => `${x?.message || x} ${x?.code || ''} ${x?.cause?.code || ''}`);
    const net = /ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ECONNRESET|ETIMEDOUT|ENETUNREACH|socket hang up|getaddrinfo|timed? ?out/i;
    const netCount = subText.filter(t => net.test(t)).length;
    if (netCount > 0 && netCount >= subText.length - 1) { // TikTok itself unreachable (the last fallback may fail differently)
      return { kind: 'network', retry: 20_000, message: `Can't reach TikTok from this PC. Check your internet, VPN or firewall. Retrying in 20s.`, detail: subText.join(' | ') };
    }
  }
  if (/room ?id/i.test(text)) {
    return { kind: 'noroom', retry: 20_000, message: `Can't find a LIVE for @${username}. Check the spelling and that the LIVE has started. Retrying every 20s…`, detail: subs.map(x => String(x?.message || x).slice(0, 140)).join(' | ') };
  }
  return { kind: 'other', retry: 20_000, message: `Couldn't connect: ${text}. Retrying in 20s.` };
}

const firstUrl = img => (img && Array.isArray(img.urlList) && img.urlList[0]) || '';

export function normUser(raw) {
  if (!raw) return null;
  const username = raw.uniqueId || raw.displayId || raw.username || '';
  if (!username) return null;
  return {
    username,
    nickname: raw.nickname || username,
    avatar: raw.profilePictureUrl || firstUrl(raw.avatarThumb) || firstUrl(raw.avatarMedium) || ''
  };
}

export class TikTokBridge {
  constructor({ onStatus, onLog, handlers }) {
    this.onStatus = onStatus; // (statusObj) => void
    this.onLog = onLog; // (text) => void
    this.h = handlers; // { chat, like, follow, share, gift, join }
    this.conn = null;
    this.wanted = false;
    this.retryTimer = null;
    this.status = { state: 'disconnected', username: '', viewers: 0, message: 'Not connected' };
    this.seenGiftStreaks = new Map();
  }

  setStatus(patch) {
    this.status = { ...this.status, ...patch };
    this.onStatus(this.status);
  }

  async connect(username, { signApiKey = '', autoReconnect = true, mode = 'service' } = {}) {
    username = String(username || '').trim().replace(/^https?:\/\/(www\.)?tiktok\.com\//i, '').replace(/^@/, '').replace(/\/live.*$/i, '').replace(/[/?#].*$/, '');
    if (!username) {
      this.setStatus({ state: 'error', message: 'Enter a TikTok username first' });
      return;
    }
    await this.disconnect(false);
    if (mode !== 'browser') await this.#closeReader();
    this.mode = mode === 'browser' ? 'browser' : 'service';
    this.noData = 0;
    this.wanted = true;
    this.autoReconnect = autoReconnect;
    this.username = username;
    // The library caches its sign client on first use, so a key added later was ignored. Reset it when the key changes.
    const key = String(signApiKey || '').trim() || undefined;
    if (SignConfig.apiKey !== key) {
      SignConfig.apiKey = key;
      SignConfig.cachedInstance = undefined;
    }
    this.attempts = 0;
    this.shortDrops = 0;
    this.#attempt();
  }

  makeConnection(username, options) {
    return new TikTokLiveConnection(username, options);
  }

  async #closeReader() {
    clearInterval(this.browserWatch);
    this.browserToken = null;
    const r = this.reader;
    this.reader = null;
    if (r) await r.close();
  }

  // ---------- "My own browser" mode: read the chat from a real browser on this PC ----------
  async #attemptBrowser() {
    this.attempts = (this.attempts || 0) + 1;
    clearInterval(this.browserWatch);
    const url = (process.env.TIKTOK_LIVE_URL || 'https://www.tiktok.com/@{user}/live').replace('{user}', encodeURIComponent(this.username));
    const token = (this.browserToken = Symbol('browser'));
    const mine = () => this.browserToken === token && this.wanted;
    if (!this.noData) this.setStatus({ state: 'connecting', username: this.username, message: `Step 1/2 · Opening @${this.username}'s LIVE page in the app's browser window…` });
    if (!this.noData) this.onLog(`🖥️ Opening @${this.username}'s LIVE page in the app's own browser (no outside service, no limits)`);

    // A connection object that is never connected: it only decodes the data the browser page receives.
    const conn = this.makeConnection(this.username, { processInitialData: false, fetchRoomInfoOnConnect: false, enableExtendedGiftInfo: false });
    this.conn = conn;
    this.wire(conn);

    try {
      if (!this.reader) this.reader = new BrowserReader();
      const reader = this.reader;
      reader.removeAllListeners();
      let got = false;
      let lastActivity = Date.now();
      reader.on('activity', () => { lastActivity = Date.now(); });
      reader.on('result', result => {
        if (!mine()) return;
        if (!got) {
          got = true;
          this.noData = 0;
          this.attempts = 0;
          this.connectedAt = Date.now();
          this.setStatus({ state: 'connected', message: `Live with @${this.username} · reading chat through your own browser (no limits)` });
          this.onLog(`✅ Receiving @${this.username}'s LIVE chat through the browser window. Keep that window open (you can minimise it).`);
        }
        Promise.resolve(conn.processProtoMessageFetchResult(result)).catch(() => {});
      });
      reader.on('closed', () => {
        if (!mine()) return;
        this.reader = null;
        clearInterval(this.browserWatch);
        this.setStatus({ state: 'error', message: "The app's browser window was closed. It's needed to read the chat, so it reopens in 5s. (Minimise it instead of closing it.)" });
        this.onLog("🖥️ The app's browser window was closed, reopening in 5s");
        this.#scheduleRetry(5000);
      });

      await withTimeout(reader.open(url), BROWSER_WAIT.open, 'opening the LIVE page took too long');
      if (!mine()) return;
      const openedAt = Date.now();
      lastActivity = openedAt;
      if (!this.noData) this.setStatus({ message: `Step 2/2 · LIVE page open in ${reader.browserName}. Waiting for chat data…` });

      this.browserWatch = setInterval(() => {
        if (!mine()) return clearInterval(this.browserWatch);
        if (!got && Date.now() - openedAt > BROWSER_WAIT.first) {
          clearInterval(this.browserWatch);
          this.noData = (this.noData || 0) + 1;
          this.setStatus({
            state: 'waiting',
            message: `No chat data from @${this.username}'s LIVE page yet. If you're not live, it joins by itself when you start. If you ARE live, look at the app's browser window: TikTok may be showing a puzzle or a login there, solve it once. Checking again every minute.`
          });
          if (this.noData === 1) this.onLog(`⏳ No chat data yet from the LIVE page (not live, or TikTok wants a puzzle/login in the browser window). Rechecking every minute.`);
          this.#scheduleRetry(1000);
        } else if (got && Date.now() - lastActivity > BROWSER_WAIT.idle) {
          clearInterval(this.browserWatch);
          this.setStatus({ state: 'connecting', message: 'No chat data for a while. Reloading the LIVE page…' });
          this.onLog('🖥️ No chat data for a while, reloading the LIVE page');
          this.#scheduleRetry(1000);
        }
      }, BROWSER_WAIT.tick);
    } catch (err) {
      if (!mine()) return;
      const text = String(err?.message || err).split('\n')[0];
      const noBrowser = err?.code === 'NO_BROWSER';
      this.setStatus({
        state: 'error',
        message: noBrowser
          ? "Couldn't start Chrome or Edge on this PC. Install Google Chrome (google.com/chrome), or switch the connection to “Free service”. Retrying in 60s."
          : `Couldn't open the LIVE page in the browser (${text}). Check your internet. Retrying in 20s.`
      });
      this.onLog(`❌ Browser mode: ${text}`);
      if (!noBrowser) await this.#closeReader().catch(() => {});
      this.browserToken = token; // keep this attempt current so the retry below still runs
      this.#scheduleRetry(noBrowser ? 60_000 : 20_000);
    }
  }

  async #attempt() {
    if (!this.wanted) return;
    clearTimeout(this.retryTimer);
    if (this.mode === 'browser') return this.#attemptBrowser();
    this.attempts = (this.attempts || 0) + 1;
    const started = Date.now();
    const secs = () => ((Date.now() - started) / 1000).toFixed(1);
    this.setStatus({ state: 'connecting', username: this.username, message: `Step 1/2 · Looking for @${this.username}'s LIVE…` });
    this.onLog(`🔌 Connecting to @${this.username} (attempt ${this.attempts})${SignConfig.apiKey ? ' using your Euler key' : ''}`);

    const conn = this.makeConnection(this.username, {
      processInitialData: false,
      enableExtendedGiftInfo: false, // one less request; gift values come with each gift event
      signApiKey: SignConfig.apiKey
    });
    this.conn = conn;
    this.wire(conn);

    try {
      const roomId = await withTimeout(conn.fetchRoomId(), STEP_TIMEOUT.roomId, 'finding the LIVE took over 30s');
      if (this.conn !== conn) return;
      // TikTok keeps handing out the room of the LAST stream while the account is offline, and the library's own
      // offline check passes silently when TikTok returns no room details. Joining such a room gets the socket
      // closed with "payload_handler_im_enter_room", so check the live status ourselves first.
      let live = null;
      try {
        live = await withTimeout(conn.fetchIsLive(), STEP_TIMEOUT.live, 'live check');
      } catch (e) {
        this.onLog(`ℹ️ Couldn't check whether the LIVE is running (${String(e?.message || e).slice(0, 100)}), trying to join anyway`);
      }
      if (this.conn !== conn) return;
      this.lastLiveCheck = live;
      if (live === false) {
        this.conn = null;
        this.shortDrops = 0;
        this.setStatus({ state: 'waiting', message: `@${this.username} isn't live right now. Start your LIVE; checking again every 30s and joining automatically.` });
        this.onLog(`⏳ @${this.username} isn't live right now (TikTok reports the stream as ended), checking again in 30s`);
        return this.#scheduleRetry(30_000);
      }
      this.onLog(`🔎 Found room ${roomId} in ${secs()}s${live === true ? ' (TikTok says the LIVE is running)' : ''}, joining chat…`);
      this.setStatus({ message: 'Step 2/2 · Joining the LIVE chat…' });
      await withTimeout(conn.connect(roomId), STEP_TIMEOUT.connect, 'joining the chat took over 60s');
      if (this.conn !== conn) return;
      this.attempts = 0;
      this.connectedAt = Date.now();
      this.setStatus({ state: 'connected', message: `Live with @${this.username}` });
      this.onLog(`✅ Connected to @${this.username}'s LIVE in ${secs()}s`);
    } catch (err) {
      if (this.conn !== conn) return;
      // stop whatever the library is still doing for this attempt
      this.conn = null;
      try { await conn.disconnect(); } catch {}
      const e = explainError(err, this.username);
      const state = e.kind === 'offline' || e.kind === 'noroom' ? 'waiting' : 'error';
      this.setStatus({ state, message: e.message });
      this.onLog(`${state === 'waiting' ? '⏳' : '❌'} ${e.message}`);
      this.onLog(`   details: ${e.detail || `${err?.constructor?.name || 'Error'}: ${String(err?.message || err).slice(0, 200)}`}`);
      this.#scheduleRetry(e.retry);
    }
  }

  #scheduleRetry(ms) {
    if (!this.wanted || !this.autoReconnect) return;
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this.#attempt(), ms);
  }

  wire(conn) {
    const mine = () => this.conn === conn;

    conn.on(ControlEvent.DISCONNECTED, info => {
      if (!mine() || !this.wanted) return;
      if (conn.streamEnded) return; // the "stream ended" handler already took care of it
      this.conn = null;
      const lasted = this.connectedAt ? Date.now() - this.connectedAt : 0;
      this.connectedAt = 0;
      const code = info?.code ?? '?';
      const reason = String(info?.reason || '').slice(0, 120);
      const why = `code ${code}${reason ? `, "${reason}"` : ''}`;
      const mins = lasted >= 60_000 ? `${Math.round(lasted / 60_000)} min` : `${Math.round(lasted / 1000)}s`;
      // A connection that lasted a while and dropped is normal on TikTok: reconnect right away.
      // One that keeps dying within seconds is a loop: slow down and explain.
      this.shortDrops = lasted < 30_000 ? (this.shortDrops || 0) + 1 : 0;
      this.onLog(`🔌 TikTok closed the chat connection after ${mins} (${why})`);
      const refusedEntry = /enter_room/i.test(reason);
      if (refusedEntry && this.shortDrops >= 2) {
        // TikTok refused the "enter room" step itself
        const wait = Math.min(60, 15 * (this.shortDrops - 1));
        const liveNote = this.lastLiveCheck === true
          ? 'TikTok reports the LIVE as running, so it is refusing this connection itself. Try: a free key from eulerstream.com under Advanced, switching VPN on or off, or restarting the LIVE.'
          : 'This almost always means the LIVE is not running right now (TikTok still gives out the room of your last stream). Start the LIVE, or check the username.';
        this.setStatus({ state: this.lastLiveCheck === true ? 'error' : 'waiting', message: `TikTok won't let the app into the room (${why}). ${liveNote} Retrying in ${wait}s.` });
        this.#scheduleRetry(wait * 1000);
      } else if (this.shortDrops >= 3) {
        const wait = Math.min(60, 15 * (this.shortDrops - 2));
        this.setStatus({
          state: 'error',
          message: `TikTok keeps closing the connection seconds after it opens (${why}). Most often the free connection service is limiting you: create a free key at eulerstream.com and paste it under Advanced. Also check that the LIVE is still running. Retrying in ${wait}s.`
        });
        this.#scheduleRetry(wait * 1000);
      } else {
        const wait = this.shortDrops ? 5 : 2;
        this.setStatus({ state: 'connecting', message: `Connection dropped after ${mins}. Reconnecting in ${wait}s… (your points and games are safe)` });
        this.#scheduleRetry(wait * 1000);
      }
    });

    conn.on(ControlEvent.ERROR, e => {
      if (!mine()) return;
      const info = e?.info || e?.exception?.message || e?.message || 'unknown error';
      this.onLog(`⚠️ ${info}`);
    });

    conn.on(WebcastEvent.STREAM_END, () => {
      if (!mine()) return;
      clearInterval(this.browserWatch);
      this.noData = 0;
      conn.streamEnded = true;
      this.shortDrops = 0;
      this.setStatus({ state: 'waiting', message: 'Stream ended. Waiting for the next LIVE…' });
      this.onLog('🛑 Stream ended');
      this.#scheduleRetry(30_000);
    });

    conn.on(WebcastEvent.ROOM_USER, d => {
      if (!mine()) return;
      const v = Number(d?.viewerCount ?? d?.total ?? 0);
      if (v) {
        this.setStatus({ viewers: v });
        this.h.viewers?.(v);
      }
    });

    conn.on(WebcastEvent.CHAT, d => {
      const user = normUser(d?.user);
      const text = d?.comment ?? d?.content ?? '';
      if (!user) return;
      const mentions = [];
      for (const m of [d?.atUser, ...(d?.mentionUsers || [])]) {
        const n = normUser(m);
        if (n && !mentions.some(x => x.username === n.username)) mentions.push(n);
      }
      const id = d?.userIdentity || {};
      const role = {
        isMod: !!(id.isModeratorOfAnchor || d?.isModerator || d?.user?.isModerator),
        isHost: !!(id.isAnchor || user.username.toLowerCase() === String(this.username || '').toLowerCase())
      };
      this.h.chat(user, text, mentions, role);
    });

    conn.on(WebcastEvent.LIKE, d => {
      const user = normUser(d?.user);
      if (user) this.h.like(user, Number(d?.likeCount ?? d?.count ?? 1));
    });

    conn.on(WebcastEvent.FOLLOW, d => {
      const user = normUser(d?.user);
      if (user) this.h.follow(user);
    });

    conn.on(WebcastEvent.SHARE, d => {
      const user = normUser(d?.user);
      if (user) this.h.share(user);
    });

    conn.on(WebcastEvent.MEMBER, d => {
      const user = normUser(d?.user);
      if (user) this.h.join(user);
    });

    conn.on(WebcastEvent.GIFT, d => {
      const user = normUser(d?.user);
      if (!user) return;
      const gift = d?.giftDetails || d?.gift || {};
      const ext = d?.extendedGiftInfo || {};
      const giftType = Number(gift.giftType ?? gift.type ?? ext.type ?? 0);
      const diamonds = Number(gift.diamondCount ?? ext.diamond_count ?? ext.diamondCount ?? 0);
      const giftName = gift.giftName || gift.name || ext.name || 'Gift';
      const count = Math.max(1, Number(d?.repeatCount || 1));
      const repeatEnd = d?.repeatEnd === true || d?.repeatEnd === 1;
      // Streakable gifts fire many events; only count the final one.
      if (giftType === 1 && !repeatEnd) return;
      this.h.gift(user, { diamonds, giftName, count });
    });
  }

  async disconnect(clearWanted = true) {
    if (clearWanted) this.wanted = false;
    clearTimeout(this.retryTimer);
    const conn = this.conn;
    this.conn = null;
    if (conn) {
      try {
        await conn.disconnect();
      } catch {}
    }
    clearInterval(this.browserWatch);
    this.browserToken = null;
    if (clearWanted) {
      await this.#closeReader();
      this.setStatus({ state: 'disconnected', viewers: 0, message: 'Not connected' });
    }
  }
}
