// Signed sessions, cookies, password hashing, and encryption for the saved Gemini keys.
import crypto from 'node:crypto';

// One secret for the whole server. vps-server.mjs sets it at start: APP_SECRET from .env, or a random one that
// is generated once and kept in the database.
let appSecret = '';
export function setAppSecret(s) { appSecret = String(s || ''); }
const secret = purpose => {
  if (!appSecret) throw new Error('The server secret is not set');
  return crypto.createHash('sha256').update(`stream-arcade:${purpose}:${appSecret}`).digest();
};
const b64 = buf => Buffer.from(buf).toString('base64url');

export const newToken = () => crypto.randomBytes(24).toString('base64url');
export const newId = () => crypto.randomUUID();
export const tokenVersion = overlayToken => crypto.createHash('sha256').update(String(overlayToken)).digest('hex').slice(0, 12);

// ---------- sessions ----------
// payload: { sid, role: 'user' | 'panel' | 'overlay', ... }   ttlMs: how long it stays valid
export function signSession(payload, ttlMs) {
  const exp = Date.now() + ttlMs;
  const body = b64(JSON.stringify({ ...payload, exp }));
  const mac = b64(crypto.createHmac('sha256', secret('session')).update(body).digest());
  return { session: `${body}.${mac}`, exp };
}

export function readSession(token) {
  const [body, mac] = String(token || '').split('.');
  if (!body || !mac) return null;
  const want = crypto.createHmac('sha256', secret('session')).update(body).digest();
  const got = Buffer.from(mac, 'base64url');
  if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    return p && p.sid && p.exp > Date.now() ? p : null;
  } catch {
    return null;
  }
}

// The short session pages send with each request (panel and overlay).
export function sessionFrom(request) {
  const h = request.headers.get('authorization') || '';
  return h.startsWith('Bearer ') ? readSession(h.slice(7)) : null;
}

// ---------- the sign-in cookie ----------
export const COOKIE = 'sa_session';
export const COOKIE_MS = 7 * 24 * 3600_000;
export function cookieSession(request) {
  const m = (request.headers.get('cookie') || '').match(/(?:^|;\s*)sa_session=([^;]+)/);
  const s = m ? readSession(decodeURIComponent(m[1])) : null;
  return s && s.role === 'user' ? s : null;
}
export function setCookie(value, { secure, clear = false } = {}) {
  return `${COOKIE}=${clear ? '' : encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${clear ? 0 : Math.floor(COOKIE_MS / 1000)}${secure ? '; Secure' : ''}`;
}

// ---------- passwords (scrypt; only the hash is stored) ----------
export function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(password), salt, 32, { N: 16384, r: 8, p: 1 });
  return `scrypt$${b64(salt)}$${b64(hash)}`;
}
export function checkPassword(password, stored) {
  const [kind, salt, hash] = String(stored || '').split('$');
  if (kind !== 'scrypt' || !salt || !hash) return false;
  const want = Buffer.from(hash, 'base64url');
  const got = crypto.scryptSync(String(password), Buffer.from(salt, 'base64url'), want.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(got, want);
}

// ---------- Gemini keys are stored encrypted (AES-256-GCM), so a copy of the database alone doesn't reveal them ----------
export function encryptKey(plain) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', secret('ai-key'), iv);
  const data = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return `v1.${b64(iv)}.${b64(c.getAuthTag())}.${b64(data)}`;
}

export function decryptKey(stored) {
  try {
    const [v, iv, tag, data] = String(stored || '').split('.');
    if (v !== 'v1') return '';
    const d = crypto.createDecipheriv('aes-256-gcm', secret('ai-key'), Buffer.from(iv, 'base64url'));
    d.setAuthTag(Buffer.from(tag, 'base64url'));
    return Buffer.concat([d.update(Buffer.from(data, 'base64url')), d.final()]).toString('utf8');
  } catch {
    return ''; // the server secret changed: the streamer pastes the key again
  }
}
