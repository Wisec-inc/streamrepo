// The site's own live channel (replaces socket.io between the PC editions' server and pages).
// Each signed-in panel and each overlay opens one WebSocket to /live?s=<session>. Sockets are grouped by
// user + platform; a message from one is passed to the others in the same group and to nobody else.
// Messages are JSON:  { b: [...] }  page ⇄ page (see src/bus.js)   ·   { srv: {...} }  page ⇄ this server
import { WebSocketServer } from 'ws';
import { readSession } from './auth.js';
import { sessionUser } from './router.js';

const MAX_PER_ROOM = 12;

// onServerMessage(ws, msg): an overlay sent { srv: msg }.  onClose(ws): a socket went away.
export function createHub({ onServerMessage = () => {}, onClose = () => {} } = {}) {
  const wss = new WebSocketServer({ noServer: true, maxPayload: 1_500_000 });
  const rooms = new Map(); // "userId:platform" → Set of sockets
  const all = new Set();

  const send = (ws, srv) => { if (ws.readyState === 1) { try { ws.send(JSON.stringify({ srv })); } catch {} } };
  function kick(ws, message) {
    send(ws, { t: 'kick', message });
    try { ws.close(4001, 'access ended'); } catch {}
  }

  function attach(ws, session) {
    const room = `${session.sid}:${session.p}`;
    ws.meta = { sid: session.sid, p: session.p, role: session.role, session, room };
    ws.alive = true;
    if (!rooms.has(room)) rooms.set(room, new Set());
    const set = rooms.get(room);
    if (set.size >= MAX_PER_ROOM) return kick(ws, 'Too many pages are open on this account. Close some and reload.');
    set.add(ws);
    all.add(ws);
    ws.on('pong', () => { ws.alive = true; });
    ws.on('message', (data, isBinary) => {
      if (isBinary) return;
      let msg;
      try { msg = JSON.parse(data.toString()); } catch { return; }
      if (msg && msg.srv && typeof msg.srv === 'object') {
        try { onServerMessage(ws, msg.srv); } catch (e) { console.error('[live]', e); }
      } else if (msg && Array.isArray(msg.b)) {
        const text = JSON.stringify({ b: msg.b });
        for (const other of set) if (other !== ws && other.readyState === 1) other.send(text);
      }
    });
    ws.on('close', () => {
      set.delete(ws);
      all.delete(ws);
      if (!set.size) rooms.delete(room);
      try { onClose(ws); } catch (e) { console.error('[live]', e); }
    });
    ws.on('error', () => {});
  }

  // Called by the web server for "Upgrade: websocket" requests to /live
  function upgrade(req, socket, head) {
    let r;
    try {
      const url = new URL(req.url, 'http://x');
      r = sessionUser(readSession(url.searchParams.get('s')));
    } catch {
      r = { error: true };
    }
    if (r.error) {
      socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
      return socket.destroy();
    }
    wss.handleUpgrade(req, socket, head, ws => attach(ws, r.session));
  }

  // Re-checks open sockets (all, or one user's): deleted, switched-off or expired accounts and replaced overlay
  // links are disconnected at once.
  function recheck(userId) {
    for (const ws of [...all]) {
      if (userId && ws.meta.sid !== userId) continue;
      const r = sessionUser(ws.meta.session);
      if (r.error) kick(ws, 'Your access has ended, or this link was replaced. Sign in again or copy the new overlay link.');
    }
  }
  const online = userId => [...all].some(ws => ws.meta.sid === userId);
  const overlaysOf = (userId, platform) => [...(rooms.get(`${userId}:${platform}`) || [])].filter(ws => ws.meta.role === 'overlay');

  const timer = setInterval(() => {
    recheck();
    for (const ws of all) {
      if (!ws.alive) { try { ws.terminate(); } catch {} continue; }
      ws.alive = false;
      try { ws.ping(); } catch {}
    }
  }, 30_000);
  timer.unref?.();

  function close() {
    clearInterval(timer);
    for (const ws of all) { try { ws.close(1001, 'server restarting'); } catch {} }
    wss.close();
  }
  return { upgrade, send, recheck, online, overlaysOf, close, count: () => all.size };
}
