// Accounts and the three user types.
//   admin  everything, plus the admin panel. Only an admin can create accounts.
//   paid   YouTube + TikTok. Optional end date: after it the account is locked (data kept) until an admin extends it.
//   trial  YouTube + TikTok for TRIAL_HOURS after the first sign-in, then the account and all its data are deleted.
//          A trial account nobody ever signed in to is deleted after 7 days.
import * as db from './db.js';
import { hashPassword, checkPassword, newId, newToken } from './auth.js';

export const ROLES = ['admin', 'paid', 'trial'];
export const trialMs = () => (Number(process.env.TRIAL_HOURS) > 0 ? Number(process.env.TRIAL_HOURS) : 12) * 3600_000;
export const UNUSED_TRIAL_MS = 7 * 24 * 3600_000;
const MAX_FAILS = 5;
const LOCK_MS = 15 * 60_000;

const bad = (message, status = 400) => Object.assign(new Error(message), { status });

export function checkUsername(name) {
  const u = String(name || '').trim();
  if (u.length < 3 || u.length > 40 || /\s/.test(u)) throw bad('A username is 3 to 40 characters with no spaces.');
  return u;
}
export function checkNewPassword(pw) {
  const p = String(pw || '');
  if (p.length < 8 || p.length > 200) throw bad('A password needs at least 8 characters.');
  return p;
}
// paid-until: empty → no end; otherwise a date in the future
function cleanPaidUntil(v) {
  if (v === null || v === undefined || v === '') return null;
  const t = typeof v === 'number' ? v : Date.parse(v);
  if (!Number.isFinite(t)) throw bad("That paid-until date isn't a date.");
  return t;
}

// Is this account allowed in right now? → { ok, reason, endsAt }
export function accessOf(user, now = Date.now()) {
  if (!user) return { ok: false, reason: 'gone', endsAt: null };
  if (user.disabled) return { ok: false, reason: 'disabled', endsAt: null };
  if (user.role === 'admin') return { ok: true, reason: '', endsAt: null };
  if (user.role === 'paid') {
    if (user.paid_until && now >= user.paid_until) return { ok: false, reason: 'paid-ended', endsAt: user.paid_until };
    return { ok: true, reason: '', endsAt: user.paid_until || null };
  }
  const endsAt = user.first_login_at ? user.first_login_at + trialMs() : null;
  if (endsAt && now >= endsAt) return { ok: false, reason: 'trial-ended', endsAt };
  return { ok: true, reason: '', endsAt };
}
export const REASON_TEXT = {
  gone: 'This account no longer exists.',
  disabled: 'This account has been switched off. Contact the admin.',
  'paid-ended': 'Your paid time has ended. Contact the admin to extend it.',
  'trial-ended': 'Your 12-hour trial has ended.'
};

// What a browser may know about an account (never the password hash or keys).
export function publicUser(u, now = Date.now()) {
  const a = accessOf(u, now);
  return {
    id: u.id, username: u.username, role: u.role, disabled: !!u.disabled, createdAt: u.created_at, firstLoginAt: u.first_login_at,
    paidUntil: u.paid_until, endsAt: a.endsAt, active: a.ok, reason: a.reason, note: u.note || '', locked: u.locked_until > now
  };
}

export function createUser({ username, password, role, paidUntil, note }) {
  const name = checkUsername(username);
  if (!ROLES.includes(role)) throw bad('Pick a type: admin, paid or trial.');
  if (db.userByUsername(name)) throw bad('That username is already taken.', 409);
  return db.insertUser({
    id: newId(), username: name, pass: hashPassword(checkNewPassword(password)), role, created_at: Date.now(),
    paid_until: role === 'paid' ? cleanPaidUntil(paidUntil) : null, overlay_token: newToken(), note: String(note || '').slice(0, 200)
  });
}

// patch: { role?, paidUntil?, disabled?, password?, note? }   actorId: the admin doing it
export function editUser(id, patch, actorId) {
  const u = db.userById(id);
  if (!u) throw bad('That account no longer exists.', 404);
  const next = {};
  if (patch.role !== undefined && patch.role !== u.role) {
    if (!ROLES.includes(patch.role)) throw bad('Pick a type: admin, paid or trial.');
    if (u.role === 'admin' && db.countAdmins() <= 1) throw bad('This is the only admin. Make another admin first.');
    next.role = patch.role;
    if (patch.role !== 'paid') next.paid_until = null;
  }
  if (patch.paidUntil !== undefined && (next.role || u.role) === 'paid') next.paid_until = cleanPaidUntil(patch.paidUntil);
  if (patch.disabled !== undefined) {
    if (patch.disabled && id === actorId) throw bad("You can't switch off your own account.");
    if (patch.disabled && u.role === 'admin' && db.countAdmins() <= 1) throw bad('This is the only admin.');
    next.disabled = patch.disabled ? 1 : 0;
  }
  if (patch.password !== undefined) {
    next.pass = hashPassword(checkNewPassword(patch.password));
    next.pass_version = u.pass_version + 1; // signs the account out everywhere
    next.fails = 0;
    next.locked_until = 0;
  }
  if (patch.note !== undefined) next.note = String(patch.note || '').slice(0, 200);
  db.updateUser(id, next);
  return db.userById(id);
}

export function removeUser(id, actorId) {
  const u = db.userById(id);
  if (!u) return;
  if (id === actorId) throw bad("You can't delete your own account.");
  if (u.role === 'admin' && db.countAdmins() <= 1) throw bad('This is the only admin.');
  db.deleteUser(id);
}

// → the user row. Throws a message safe to show on the sign-in page.
export function login(username, password, now = Date.now()) {
  const wrong = () => bad('Wrong username or password.', 401);
  const u = db.userByUsername(String(username || '').trim());
  if (!u) {
    hashPassword('same work for an unknown name, so timing does not reveal which usernames exist');
    throw wrong();
  }
  if (u.locked_until > now) throw bad(`Too many wrong passwords. Try again in ${Math.ceil((u.locked_until - now) / 60_000)} min.`, 429);
  if (!checkPassword(password, u.pass)) {
    const fails = u.fails + 1;
    db.updateUser(u.id, fails >= MAX_FAILS ? { fails: 0, locked_until: now + LOCK_MS } : { fails });
    throw wrong();
  }
  const a = accessOf(u, now);
  if (!a.ok) {
    if (a.reason === 'trial-ended') db.deleteUser(u.id);
    throw bad(REASON_TEXT[a.reason], 403);
  }
  const patch = { fails: 0, locked_until: 0 };
  if (!u.first_login_at) patch.first_login_at = now; // a trial's clock starts now
  db.updateUser(u.id, patch);
  return db.userById(u.id);
}

export function changeOwnPassword(id, current, next) {
  const u = db.userById(id);
  if (!u || !checkPassword(current, u.pass)) throw bad('Your current password is wrong.', 401);
  db.updateUser(id, { pass: hashPassword(checkNewPassword(next)), pass_version: u.pass_version + 1 });
  return db.userById(id);
}

// Deletes trial accounts whose time is up (and unused ones after a week). → the deleted users' ids
export function sweepTrials(now = Date.now()) {
  const gone = [];
  for (const u of db.listUsers()) {
    if (u.role !== 'trial') continue;
    const over = u.first_login_at ? now >= u.first_login_at + trialMs() : now >= u.created_at + UNUSED_TRIAL_MS;
    if (over) { db.deleteUser(u.id); gone.push(u.id); }
  }
  return gone;
}

// First start: make the admin account from the server's .env. The password is stored only as a hash.
// ADMIN_PASSWORD_RESET=1 sets that admin's password again (for a forgotten password).
export function ensureAdmin({ username = process.env.ADMIN_USERNAME, password = process.env.ADMIN_PASSWORD, reset = process.env.ADMIN_PASSWORD_RESET === '1' } = {}) {
  if (!username || !password) {
    return db.countAdmins() ? 'ok' : 'missing'; // 'missing': nobody can sign in until ADMIN_USERNAME / ADMIN_PASSWORD are set
  }
  const existing = db.userByUsername(username);
  if (!existing) {
    if (db.countAdmins()) return 'ok'; // an admin already exists under another name: leave accounts alone
    createUser({ username, password, role: 'admin' });
    return 'created';
  }
  if (reset) {
    db.updateUser(existing.id, { pass: hashPassword(checkNewPassword(password)), pass_version: existing.pass_version + 1, role: 'admin', disabled: 0, fails: 0, locked_until: 0 });
    return 'reset';
  }
  return 'ok';
}
