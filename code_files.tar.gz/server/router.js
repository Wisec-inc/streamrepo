// Every /api request arrives here (vps-server.mjs passes it on).
//   GET  /api/health, /api/config
//   POST /api/login, /api/logout, /api/password      GET /api/me        the sign-in cookie
//   POST /api/session         cookie or overlay link key (+ platform) → a short session for one platform
//   POST /api/data/load|save  the overlay's settings, game state and viewers' coins
//   POST /api/account         panel only: save the Gemini key, new overlay link, import coins
//   POST /api/yt/find|poll    YouTube live chat
//   POST /api/ai/...          Gemini, with the user's saved key added on the server
//   GET|POST /api/admin/...   admin only: accounts and server settings
// Every request re-reads the account, so a deleted, switched-off or expired user stops at the next request.
import fs from 'node:fs';
import { signSession, sessionFrom, cookieSession, setCookie, COOKIE_MS, tokenVersion, newToken, encryptKey, decryptKey } from './auth.js';
import * as db from './db.js';
import * as accounts from './accounts.js';
import * as yt from './yt.js';

const VERSION = (() => {
  try { return JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version; } catch { return ''; }
})();
const OVERLAY_SESSION_MS = 15 * 60_000;
const PANEL_SESSION_MS = 15 * 60_000;
const MAX_BODY = 1_500_000; // characters
const GEMINI = 'https://generativelanguage.googleapis.com';

// vps-server.mjs fills these in: tell the live connections when an account changed, and ask who is connected.
export const hooks = { userChanged: _id => {}, online: _id => false };

const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers } });
const deny = (status, message, kind = 'auth') => json({ ok: false, error: { kind, retry: 20_000, message } }, status);

async function body(request) {
  const text = await request.text();
  if (text.length > MAX_BODY) throw Object.assign(new Error('That request is too large'), { status: 413 });
  if (!text) return {};
  try {
    const b = JSON.parse(text);
    return b && typeof b === 'object' ? b : {};
  } catch {
    throw Object.assign(new Error('The request was not valid JSON'), { status: 400 });
  }
}

// A simple per-key limit, kept in memory (this site is one server process).
const hits = new Map();
function tooMany(who, max, windowMs) {
  const now = Date.now();
  const list = (hits.get(who) || []).filter(t => now - t < windowMs);
  list.push(now);
  hits.set(who, list);
  if (hits.size > 20_000) hits.clear();
  return list.length > max;
}

const isPlainObject = x => !!x && typeof x === 'object' && !Array.isArray(x);
function cleanUsers(users, max) {
  const out = {};
  let n = 0;
  for (const [k, u] of Object.entries(isPlainObject(users) ? users : {})) {
    const key = db.viewerKey(k);
    if (!key || key.length > 200 || !isPlainObject(u)) continue;
    if (++n > max) throw Object.assign(new Error(`Too many viewers in one request (max ${max})`), { status: 413 });
    out[key] = u;
  }
  return out;
}

// The account behind a session, if it is still allowed in. A trial whose time is up is deleted on the spot.
// → { user } or { error: Response }
function alive(userId) {
  const user = db.userById(userId);
  const a = accounts.accessOf(user);
  if (a.ok) return { user, access: a };
  if (user && a.reason === 'trial-ended') { db.deleteUser(user.id); hooks.userChanged(user.id); }
  return { error: deny(401, accounts.REASON_TEXT[a.reason] || 'Please sign in again.', 'access') };
}
// The signed-in person (cookie).
function cookieUser(request) {
  const s = cookieSession(request);
  if (!s) return { error: deny(401, 'Please sign in.') };
  const r = alive(s.sid);
  if (r.error) return r;
  if (r.user.pass_version !== s.pv) return { error: deny(401, 'Please sign in again.') };
  return r;
}
// A panel or overlay session (Authorization: Bearer …). Overlay sessions must match the current overlay link.
export function sessionUser(s) {
  if (!s || !db.PLATFORMS.includes(s.p) || (s.role !== 'panel' && s.role !== 'overlay')) return { error: deny(401, 'Your session ran out. Reload the page.') };
  const r = alive(s.sid);
  if (r.error) return r;
  if (s.role === 'overlay' && tokenVersion(r.user.overlay_token) !== s.v) return { error: deny(401, 'This overlay link is no longer valid.') };
  if (s.role === 'panel' && r.user.pass_version !== s.pv) return { error: deny(401, 'Please sign in again.') };
  return { ...r, session: s };
}
// Cookie requests that change something must come from this site's own pages.
function sameSite(request) {
  const origin = request.headers.get('origin');
  if (!origin) return true;
  try { return new URL(origin).host === (request.headers.get('host') || new URL(request.url).host); } catch { return false; }
}
const me = (user, access) => ({ ...accounts.publicUser(user), trialHours: accounts.trialMs() / 3600_000, endsAt: access.endsAt });

// ctx: { ip, secure } from the web server
export async function handle(request, ctx = {}) {
  const url = new URL(request.url);
  const route = url.pathname.replace(/^\/api\/?/, '').replace(/\/+$/, '');
  const ip = ctx.ip || 'local';
  const GET = request.method === 'GET';

  try {
    if (GET && route === 'health') return json({ ok: true, version: VERSION });
    if (GET && route === 'config') return json({ version: VERSION, trialHours: accounts.trialMs() / 3600_000, platforms: db.PLATFORMS });
    if (GET && route === 'me') {
      const r = cookieUser(request);
      return r.error || json({ ok: true, user: me(r.user, r.access) });
    }
    if (GET && route === 'admin/users') {
      const r = cookieUser(request);
      if (r.error) return r.error;
      if (r.user.role !== 'admin') return deny(403, 'Admins only.');
      return json({ ok: true, users: db.listUsers().map(u => ({ ...accounts.publicUser(u), online: hooks.online(u.id), viewers: db.viewerCount(u.id), you: u.id === r.user.id })), trialHours: accounts.trialMs() / 3600_000, hasEulerKey: !!db.getSetting('eulerKey') });
    }
    if (GET) return json({ ok: false, error: { message: 'Not found' } }, 404);
    if (request.method !== 'POST') return json({ ok: false, error: { message: 'Method not allowed' } }, 405);

    // ---------- sign in / out ----------
    if (route === 'login') {
      if (!sameSite(request)) return deny(403, 'Sign in from the site itself.');
      if (tooMany(`login:${ip}`, 20, 10 * 60_000)) return deny(429, 'Too many sign-in attempts from here. Try again in a few minutes.', 'busy');
      const b = await body(request);
      const user = accounts.login(b.username, b.password);
      const { session } = signSession({ sid: user.id, role: 'user', pv: user.pass_version }, COOKIE_MS);
      return json({ ok: true, user: me(user, accounts.accessOf(user)) }, 200, { 'set-cookie': setCookie(session, { secure: !!ctx.secure }) });
    }
    if (route === 'logout') return json({ ok: true }, 200, { 'set-cookie': setCookie('', { secure: !!ctx.secure, clear: true }) });

    if (route === 'password') {
      if (!sameSite(request)) return deny(403, 'Not allowed from another site.');
      const r = cookieUser(request);
      if (r.error) return r.error;
      if (tooMany(`pw:${r.user.id}`, 8, 10 * 60_000)) return deny(429, 'Too many attempts. Try again in a few minutes.', 'busy');
      const b = await body(request);
      const user = accounts.changeOwnPassword(r.user.id, b.current, b.next);
      hooks.userChanged(user.id);
      const { session } = signSession({ sid: user.id, role: 'user', pv: user.pass_version }, COOKIE_MS);
      return json({ ok: true }, 200, { 'set-cookie': setCookie(session, { secure: !!ctx.secure }) });
    }

    // ---------- a session for one platform's panel or overlay ----------
    if (route === 'session') {
      const b = await body(request);
      const platform = String(b.platform || '');
      if (!db.PLATFORMS.includes(platform)) return deny(400, 'Pick YouTube or TikTok.', 'input');
      if (b.overlayToken) {
        if (tooMany(`osess:${ip}`, 60, 60_000)) return deny(429, 'Too many attempts. Try again in a minute.', 'busy');
        const row = db.userByOverlayToken(String(b.overlayToken).slice(0, 200));
        if (!row) return deny(401, 'This overlay link is no longer valid.');
        const r = alive(row.id);
        if (r.error) return r.error;
        return json({ ok: true, ...signSession({ sid: row.id, role: 'overlay', p: platform, v: tokenVersion(row.overlay_token) }, OVERLAY_SESSION_MS), hasAiKey: !!row.ai_key, endsAt: r.access.endsAt });
      }
      if (!sameSite(request)) return deny(403, 'Not allowed from another site.');
      const r = cookieUser(request);
      if (r.error) return r.error;
      return json({ ok: true, ...signSession({ sid: r.user.id, role: 'panel', p: platform, pv: r.user.pass_version }, PANEL_SESSION_MS), overlayToken: r.user.overlay_token, hasAiKey: !!r.user.ai_key, user: me(r.user, r.access) });
    }

    // ---------- admin ----------
    if (route.startsWith('admin/')) {
      if (!sameSite(request)) return deny(403, 'Not allowed from another site.');
      const r = cookieUser(request);
      if (r.error) return r.error;
      if (r.user.role !== 'admin') return deny(403, 'Admins only.');
      const b = await body(request);
      if (route === 'admin/users/create') {
        const u = accounts.createUser({ username: b.username, password: b.password, role: b.role, paidUntil: b.paidUntil, note: b.note });
        return json({ ok: true, user: accounts.publicUser(u) });
      }
      if (route === 'admin/users/update') {
        const u = accounts.editUser(String(b.id || ''), { role: b.role, paidUntil: b.paidUntil, disabled: b.disabled, password: b.password, note: b.note }, r.user.id);
        hooks.userChanged(u.id);
        return json({ ok: true, user: accounts.publicUser(u) });
      }
      if (route === 'admin/users/delete') {
        accounts.removeUser(String(b.id || ''), r.user.id);
        hooks.userChanged(String(b.id || ''));
        return json({ ok: true });
      }
      if (route === 'admin/settings') {
        if (b.eulerKey !== undefined) {
          const k = String(b.eulerKey || '').trim();
          if (k.length > 300) return deny(400, "That doesn't look like a key.", 'input');
          db.setSetting('eulerKey', k ? encryptKey(k) : '');
        }
        return json({ ok: true, hasEulerKey: !!db.getSetting('eulerKey') });
      }
      return json({ ok: false, error: { message: 'Not found' } }, 404);
    }

    // Everything below needs a panel or overlay session.
    const r = sessionUser(sessionFrom(request));
    if (r.error) return r.error;
    const { user, session: s } = r;

    // ---------- YouTube chat ----------
    if (route === 'yt/find' || route === 'yt/poll') {
      if (s.p !== 'youtube') return deny(400, 'That is for the YouTube games.', 'input');
      const b = await body(request);
      if (route === 'yt/find') {
        if (tooMany(`find:${user.id}`, 12, 60_000)) return deny(429, 'Too many connection attempts. Waiting a minute.', 'busy');
        return json(await yt.find(b));
      }
      if (tooMany(`poll:${user.id}`, 30, 10_000)) return deny(429, 'Reading the chat too fast. Slowing down.', 'busy');
      return json(await yt.poll(b));
    }

    // ---------- Gemini ----------
    if (route.startsWith('ai/')) {
      const path = route.slice(3);
      if (!/^v1beta\/models\/[\w.\-]+:generateContent$/.test(path)) return json({ error: { message: 'Not found' } }, 404);
      if (s.role !== 'overlay') return json({ error: { message: 'Only the overlay asks Google' } }, 403);
      if (tooMany(`ai:${user.id}`, 30, 60_000)) return json({ error: { message: 'Too many questions at once' } }, 429);
      const key = decryptKey(user.ai_key);
      if (!key) return json({ error: { message: 'API key not valid. No Gemini API key is saved yet: paste one in Game Settings → Google answers.' } }, 400);
      const text = await request.text();
      if (text.length > 200_000) return json({ error: { message: 'Request too large' } }, 413);
      const res = await fetch(`${GEMINI}/${path}`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': key }, body: text });
      return new Response(await res.text(), { status: res.status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });
    }

    if (route === 'data/load') {
      if (s.role !== 'overlay') return deny(401, 'Only the overlay loads game data.');
      const all = db.loadAll(user.id, s.p);
      const config = isPlainObject(all.config) && Object.keys(all.config).length ? all.config : null;
      return json({ ok: true, config, state: all.state || {}, users: all.users, hasAiKey: !!user.ai_key });
    }

    if (route === 'data/save') {
      if (s.role !== 'overlay') return deny(401, 'Only the overlay saves game data.');
      const b = await body(request);
      const p = {};
      if (isPlainObject(b.config)) p.config = { ...b.config, ai: { ...(isPlainObject(b.config.ai) ? b.config.ai : {}), geminiApiKey: '' } }; // the key is never kept with the settings
      if (isPlainObject(b.state)) p.state = b.state;
      if (b.wipe === true) p.wipe = true;
      if (Array.isArray(b.removed)) p.removed = b.removed.slice(0, 5000).map(db.viewerKey).filter(Boolean);
      p.users = cleanUsers(b.users, 500);
      if (Array.isArray(b.lines)) p.lines = b.lines.slice(0, 200).filter(isPlainObject);
      if (Array.isArray(b.backups)) p.backups = b.backups.slice(0, 2).filter(x => x?.name);
      db.saveGame(user.id, s.p, p);
      return json({ ok: true });
    }

    if (route === 'account') {
      if (s.role !== 'panel') return deny(403, 'Only the control panel can do that.');
      const b = await body(request);
      if (b.action === 'setKey') {
        const key = String(b.key || '').trim();
        if (key.length > 200) return deny(400, "That doesn't look like a Gemini API key.", 'input');
        db.updateUser(user.id, { ai_key: key ? encryptKey(key) : null });
        return json({ ok: true, hasAiKey: !!key });
      }
      if (b.action === 'rotate') {
        const overlayToken = newToken();
        db.updateUser(user.id, { overlay_token: overlayToken });
        hooks.userChanged(user.id); // open overlays on the old link are cut off
        return json({ ok: true, overlayToken });
      }
      if (b.action === 'import') {
        const users = cleanUsers(b.users, 500);
        db.saveGame(user.id, s.p, { users });
        return json({ ok: true, count: Object.keys(users).length });
      }
      return deny(400, 'Unknown action.', 'input');
    }

    return json({ ok: false, error: { message: 'Not found' } }, 404);
  } catch (err) {
    const status = err?.status || 500;
    if (status >= 500) console.error(`[api/${route}]`, err);
    return json({ ok: false, error: { kind: status >= 500 ? 'server' : 'input', retry: 20_000, message: status >= 500 ? 'The game server had a problem. Trying again shortly.' : String(err.message) } }, status);
  }
}
