// YouTube live chat for the web edition, one request at a time (nothing stays running between requests):
//   find  handle / channel link / video link → the live video and where its chat starts
//   poll  one chat page: the new messages as small events, and where to continue
// Same library and steps as the local edition's "Direct" mode (lib/youtube.js).
import { Innertube, Parser, YTNodes, Log } from 'youtubei.js';
import { parseTarget, explainError, actionToEvents, withTimeout, STEP_TIMEOUT } from '../shared/yt-core.js';

// The library prints a long warning for every YouTube item type it doesn't know yet; real failures are thrown and handled below.
Log.setLevel(Log.Level.NONE);

// The YouTube client is kept between requests while this server instance stays warm.
let ytPromise = null;
function client() {
  ytPromise ||= Innertube.create({ retrieve_player: false, lang: 'en', location: 'US' });
  ytPromise.catch(() => { ytPromise = null; });
  return ytPromise;
}

function errorAnswer(err, label) {
  const e = explainError(err, label);
  if (e.kind === 'network' || e.kind === 'blocked') ytPromise = null; // start fresh next time
  return {
    ok: false,
    label,
    error: {
      kind: e.kind,
      retry: e.retry,
      message: e.message.replace("Can't reach YouTube from this PC", "The game server can't reach YouTube").replace(' Check your internet, VPN or firewall.', ''),
      details: `${err?.constructor?.name || 'Error'}: ${String(err?.message || err).slice(0, 200)}`
    }
  };
}

async function findVideo(yt, t) {
  if (t.videoId) return t.videoId;
  // /@handle/live redirects to the current live video when the channel is live
  const ep = await yt.resolveURL(`${t.channelUrl}/live`);
  const vid = ep?.payload?.videoId;
  if (vid) return vid;
  // fallback: look through the channel's Live tab
  const browseId = ep?.payload?.browseId;
  if (!browseId) return null;
  const channel = await yt.getChannel(browseId);
  if (!channel?.has_live_streams) return null;
  const live = await channel.getLiveStreams();
  const v = (live?.videos || []).find(x => x?.is_live);
  return v?.id || v?.video_id || null;
}

export async function find({ input }) {
  const target = parseTarget(input);
  if (!target) return { ok: false, error: { kind: 'input', retry: 0, message: 'Enter your YouTube channel handle (e.g. @yourname) or your live video link first' } };
  const label = target.label;
  try {
    const yt = await withTimeout(client(), STEP_TIMEOUT.setup, 'starting the YouTube client took over 30s');
    const videoId = await withTimeout(findVideo(yt, target), STEP_TIMEOUT.find, 'finding the live stream took over 30s');
    if (!videoId) return { ok: true, label, live: false };
    const info = await withTimeout(yt.getInfo(videoId), STEP_TIMEOUT.find, 'loading the live stream took over 30s');
    const b = info.basic_info || {};
    if (!b.is_live && !b.is_upcoming) return { ok: true, label, live: false, videoId };
    const first = info.livechat?.continuation;
    if (!first) throw new Error('Live Chat is not available');
    // The first chat page carries the header with the "Top chat / Live chat" switch: start from "Live chat" (all messages).
    const res = await withTimeout(yt.actions.execute('live_chat/get_live_chat', { continuation: first, parse: true }), STEP_TIMEOUT.chat, 'joining the chat took over 30s');
    const contents = res.continuation_contents;
    let continuation = contents?.continuation?.token;
    if (!continuation) throw new Error('Live Chat is not available');
    const all = contents.header?.view_selector?.sub_menu_items?.at(1);
    if (all && !all.selected && all.continuation) continuation = all.continuation;
    return { ok: true, label, live: true, videoId, title: String(b.title || ''), continuation };
  } catch (err) {
    return errorAnswer(err, label);
  }
}

async function viewers(yt, videoId, mcont) {
  const payload = { videoId };
  if (mcont) payload.continuation = mcont;
  const response = await yt.actions.execute('/updated_metadata', payload);
  const data = Parser.parseResponse(response.data);
  const node = data.actions?.array().firstOfType(YTNodes.UpdateViewershipAction)?.view_count_node;
  const raw = node?.original_view_count ?? String(node?.view_count?.toString?.() || node?.short_view_count?.toString?.() || '').replace(/[^\d]/g, '');
  return { viewers: Number(raw) || 0, mcont: data.continuation?.token || '' };
}

export async function poll({ continuation, videoId, since, wantMeta, mcont }) {
  if (typeof continuation !== 'string' || !continuation || continuation.length > 4000) {
    return { ok: false, error: { kind: 'input', retry: 20_000, message: 'Lost the place in the chat. Reconnecting in 20s.' } };
  }
  try {
    const yt = await withTimeout(client(), STEP_TIMEOUT.setup, 'starting the YouTube client took over 30s');
    const [res, meta] = await Promise.all([
      withTimeout(yt.actions.execute('live_chat/get_live_chat', { continuation, parse: true }), STEP_TIMEOUT.chat, 'the chat took over 30s to answer'),
      wantMeta && /^[\w-]{11}$/.test(String(videoId || '')) ? viewers(yt, videoId, mcont).catch(() => null) : null
    ]);
    const contents = res.continuation_contents;
    const next = contents?.continuation?.token || '';
    const out = { ok: true, events: [], continuation: next, ended: !contents || !next };
    const connectedAt = Number(since) || 0;
    for (const action of contents?.actions || []) {
      try {
        out.events.push(...actionToEvents(action, connectedAt));
      } catch {
        /* an item shape we don't know: skip it */
      }
    }
    if (meta?.viewers) out.viewers = meta.viewers;
    if (meta?.mcont) out.mcont = meta.mcont;
    return out;
  } catch (err) {
    return errorAnswer(err, '');
  }
}
