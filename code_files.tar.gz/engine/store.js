// Tiny JSON-file storage for settings and viewer points. No database install needed.
import fs from 'node:fs';
import path from 'node:path';
import { DEFAULT_CONFIG, CONFIG_VERSION, mergeDefaults } from './defaults.js';

export class Store {
  constructor(dataDir) {
    this.dataDir = dataDir;
    fs.mkdirSync(dataDir, { recursive: true });
    this.configFile = path.join(dataDir, 'config.json');
    this.pointsFile = path.join(dataDir, 'points.json');
    const saved = this.#readJson(this.configFile, null);
    if (saved && (saved.version || 1) < 3) {
      // v3 "Stream Arcade": the new game rules and numbers replace the old ones. Accounts, keys, host-bot and
      // hate-filter settings are kept; viewers keep their coins (points.json is untouched).
      fs.writeFileSync(path.join(dataDir, `config-before-arcade.json`), JSON.stringify(saved, null, 2));
      // YouTube's own reward amounts are kept (memberships, gifted memberships, Super Chats)
      const keepEarn = {};
      for (const k of ['memberPoints', 'giftedMembershipPoints', 'superChatPointsPerDollar']) if (saved.earn?.[k] !== undefined) keepEarn[k] = saved.earn[k];
      for (const k of ['games', 'earn', 'daily', 'startingPoints', 'overlay']) delete saved[k];
      if (Object.keys(keepEarn).length) saved.earn = keepEarn;
      if (saved.staff) delete saved.staff.donateMax;
    }
    if (saved) saved.version = CONFIG_VERSION;
    this.config = mergeDefaults(DEFAULT_CONFIG, saved || {});
    this.users = this.#readJson(this.pointsFile, {}); // key: lowercase username
    this.stateFile = path.join(dataDir, 'state.json');
    this.state = this.#readJson(this.stateFile, {}); // jackpot, heist level, boosts… survives restarts
    this.unlimitedCheck = () => false; // set by Games: streamer (and optionally mods) never lose points
    this.#saveTimer = null;
    this.saveConfig();
  }

  #saveTimer;

  #readJson(file, fallback) {
    try {
      return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch {
      return fallback;
    }
  }

  #writeJson(file, data) {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
    fs.renameSync(tmp, file);
  }

  saveConfig() {
    this.#writeJson(this.configFile, this.config);
  }

  updateConfig(next) {
    this.config = mergeDefaults(DEFAULT_CONFIG, next);
    this.saveConfig();
    return this.config;
  }

  savePointsSoon() {
    if (this.#saveTimer) return;
    this.#saveTimer = setTimeout(() => {
      this.#saveTimer = null;
      this.savePointsNow();
    }, 1500);
  }

  saveStateSoon() {
    if (this.stateTimer) return;
    this.stateTimer = setTimeout(() => {
      this.stateTimer = null;
      this.#writeJson(this.stateFile, this.state);
    }, 1000);
  }

  appendLine(file, obj) {
    try {
      fs.appendFileSync(path.join(this.dataDir, file), JSON.stringify(obj) + '\n');
    } catch {}
  }

  writeBackup(name, data) {
    this.#writeJson(path.join(this.dataDir, name), data);
  }

  savePointsNow() {
    if (this.#saveTimer) {
      clearTimeout(this.#saveTimer);
      this.#saveTimer = null;
    }
    this.#writeJson(this.pointsFile, this.users);
    if (this.state && Object.keys(this.state).length) this.#writeJson(this.stateFile, this.state);
  }

  key(username) {
    return String(username || '').replace(/^@/, '').trim().toLowerCase();
  }

  // Creates the viewer the first time we see them, refreshes name/avatar after that.
  touch({ username, nickname, avatar }) {
    const k = this.key(username);
    if (!k) return null;
    let u = this.users[k];
    if (!u) {
      u = this.users[k] = {
        username: String(username).replace(/^@/, ''),
        nickname: nickname || username,
        avatar: avatar || '',
        points: this.config.startingPoints,
        firstSeen: Date.now()
      };
    }
    if (nickname) u.nickname = nickname;
    if (avatar) u.avatar = avatar;
    u.lastSeen = Date.now();
    this.savePointsSoon();
    return u;
  }

  get(username) {
    return this.users[this.key(username)] || null;
  }

  findByMention(text) {
    const k = this.key(text);
    if (!k) return null;
    if (this.users[k]) return this.users[k];
    // fall back to display nickname (case-insensitive)
    return Object.values(this.users).find(u => String(u.nickname || '').toLowerCase() === k) || null;
  }

  add(username, amount) {
    const u = this.get(username);
    if (!u) return null;
    if (this.unlimitedCheck(u.username)) return u; // unlimited balance never changes
    u.points = Math.max(0, Math.floor(u.points + amount));
    this.savePointsSoon();
    return u;
  }

  set(username, amount) {
    const u = this.get(username);
    if (!u) return null;
    u.points = Math.max(0, Math.floor(Number(amount) || 0));
    this.savePointsSoon();
    return u;
  }

  remove(username) {
    delete this.users[this.key(username)];
    this.savePointsSoon();
  }

  top(n = 10) {
    return Object.values(this.users)
      .filter(u => !this.unlimitedCheck(u.username)) // streamer/unlimited staff stay off the leaderboard
      .sort((a, b) => b.points - a.points)
      .slice(0, n)
      .map(u => ({ username: u.username, nickname: u.nickname, avatar: u.avatar, points: u.points, lastSeen: u.lastSeen || 0, firstSeen: u.firstSeen || 0, banned: !!u.banned, badge: u.badge || '' }));
  }

  resetAll() {
    for (const u of Object.values(this.users)) u.points = this.config.startingPoints;
    this.savePointsNow();
  }

  wipeAll() {
    this.users = {};
    this.savePointsNow();
  }
}
