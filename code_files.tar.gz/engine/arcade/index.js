// Stream Arcade engine: one wallet per viewer, solo games, group rounds, economy and staff tools.
// It never talks to TikTok directly: it receives normalized events and emits overlay events.
import { SOLO_GAMES } from './solo.js';
import { GROUP_GAMES } from './group.js';
import { Rounds } from './rounds.js';
import { handleStaff } from './staff.js';

export const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
export const pick = arr => arr[Math.floor(Math.random() * arr.length)];
export const fmt = n => Math.floor(Number(n) || 0).toLocaleString('en-US');
const RANK_ICON = { bronze: '🥉', silver: '🥈', gold: '🥇', diamond: '💎' };
const DAY = 86_400_000;

export class Arcade {
  // platform: 'tiktok' (likes/taps, follows, shares, gifts) or 'youtube' (Super Chats, memberships, no taps)
  constructor(store, emit, log = () => {}, { platform = 'tiktok' } = {}) {
    this.platform = platform;
    this.canTap = platform === 'tiktok';
    this.store = store;
    this.rawEmit = emit;
    this.log = log;
    this.detectedMods = new Set();
    this.detectedHost = '';
    this.soloAt = new Map(); // key -> last solo game time
    this.duels = new Map(); // target key -> duel
    this.sharedThisStream = new Set();
    this.activeChat = new Map(); // key -> last chat time
    this.shown = []; // times of recently shown result cards
    this.tick = { plays: {}, hidden: 0 }; // for the busy-chat summary line
    this.rain = null;
    this.paused = false;
    this.pending = new Map(); // staff key -> group action waiting for !confirm
    this.undo = null;

    const st = store.state;
    if (typeof st.jackpot !== 'number') st.jackpot = this.cfg.economy.jackpotStart;
    if (!st.heistLevel) st.heistLevel = 1;
    this.hype = 0;

    store.unlimitedCheck = username => this.isUnlimited(username);
    this.solo = Object.fromEntries(SOLO_GAMES.map(g => [g.id, g]));
    this.group = Object.fromEntries(GROUP_GAMES.map(g => [g.id, g]));
    this.rounds = new Rounds(this);
    this.timer = setInterval(() => this.#tick(), 500);
    this.stateTimer = null;
  }

  get cfg() { return this.store.config; }
  get cur() { return this.cfg.currencyName; }
  get eco() { return this.cfg.economy; }
  key(name) { return this.store.key(name); }

  emit(type, payload) { this.rawEmit(type, payload); }
  // settings changed from chat (!mode, !game, !autopilot): save and tell the control panel, so it doesn't overwrite them
  configChanged() {
    this.store.saveConfig();
    this.onConfigChange?.();
    this.stateSoon();
  }

  // ---------- staff ----------
  isStreamer(username) {
    const k = this.key(username);
    return !!k && (k === this.key(this.ownName()) || k === this.detectedHost);
  }
  isMod(username) {
    const k = this.key(username);
    if (!k) return false;
    if (this.detectedMods.has(k)) return true;
    return String(this.cfg.staff.moderators || '').split(/[\s,;]+/).map(x => this.key(x)).filter(Boolean).includes(k);
  }
  isUnlimited(username) {
    const s = this.cfg.staff;
    return !!((s.streamerUnlimited && this.isStreamer(username)) || (s.modsUnlimited && this.isMod(username)));
  }
  canDonate(username) {
    return this.isStreamer(username) || (this.cfg.staff.modsCanDonate && this.isMod(username));
  }
  isStaff(username) { return this.isStreamer(username) || this.isMod(username); }
  staffLog(u, text) {
    const who = this.isStreamer(u.username) ? 'streamer' : 'mod';
    this.log(`🛡️ [${who}] ${u.username}: ${text}`);
    this.store.appendLine('staff-log.jsonl', { t: new Date().toISOString(), by: u.username, role: who, action: text });
  }

  // ---------- players ----------
  ranks() {
    return String(this.cfg.ranks || '').split(',').map(x => x.split('=')).map(([n, v]) => ({ name: String(n || '').trim(), min: Number(v) || 0 }))
      .filter(r => r.name).sort((a, b) => a.min - b.min);
  }
  rankOf(points) {
    let r = { name: '', min: 0 };
    for (const x of this.ranks()) if (points >= x.min) r = x;
    return r.name ? `${RANK_ICON[r.name.toLowerCase()] || '⭐'} ${r.name}` : '';
  }
  pub(u) {
    if (!u) return { username: '?', nickname: 'someone', avatar: '' };
    const unlimited = this.isUnlimited(u.username);
    return { username: u.username, nickname: u.nickname, avatar: u.avatar, rank: unlimited ? '👑 Streamer' : this.rankOf(u.points), badge: u.badge || '' };
  }
  bal(u) { return this.isUnlimited(u.username) ? null : u.points; }
  isRookie(u) { return Date.now() - (u.firstSeen || 0) < this.eco.rookieDays * DAY; }
  isShielded(u) { return !this.isUnlimited(u.username) && Date.now() - (u.firstSeen || 0) < this.eco.shieldHours * 3_600_000; }
  boost() {
    const b = this.store.state.boost;
    return b && Date.now() < b.until ? b.mult : 1;
  }

  // Winnings go through here so an active boost multiplies them.
  win(u, profit, { boosted = true } = {}) {
    const amount = Math.max(0, Math.floor(profit * (boosted ? this.boost() : 1)));
    if (amount > 0) this.store.add(u.username, amount);
    this.stateSoon();
    return amount;
  }
  // Losses respect the beginner shield: a new player's balance never drops below the floor.
  lose(u, amount) {
    if (this.isUnlimited(u.username)) return Math.max(0, Math.floor(amount)); // shown on screen, balance never changes
    let loss = Math.min(Math.floor(amount), u.points);
    if (this.isShielded(u)) loss = Math.max(0, Math.min(loss, u.points - this.eco.shieldFloor));
    if (loss > 0) this.store.add(u.username, -loss);
    this.stateSoon();
    return loss;
  }
  give(u, amount) { // plain payment, no boost (bonuses, staff gifts)
    const n = Math.max(0, Math.floor(amount));
    if (n > 0) this.store.add(u.username, n);
    this.stateSoon();
    return n;
  }
  addBet(u, bet) {
    if (this.isUnlimited(u.username)) return; // the streamer's bets are free
    this.store.state.jackpot += (bet * this.eco.jackpotPercent) / 100;
    this.store.saveStateSoon();
  }

  parseAmount(raw, balance) {
    const s = String(raw ?? '').toLowerCase().replace(/,/g, '');
    if (s === 'all' || s === 'allin' || s === 'max') return balance;
    if (s === 'half') return Math.floor(balance / 2);
    if (/^\d+(\.\d+)?%$/.test(s)) return Math.floor((balance * parseFloat(s)) / 100);
    if (/^\d+(\.\d+)?[km]$/.test(s)) return Math.floor(parseFloat(s) * (s.endsWith('m') ? 1e6 : 1e3));
    if (/^\d+$/.test(s)) return parseInt(s, 10);
    return NaN;
  }
  isAmount(a) { return /^(\d[\d,]*(\.\d+)?[km]?|\d+(\.\d+)?%|all|allin|max|half)$/i.test(String(a)); }

  // One word is enough: no amount = the default bet (or whatever is left if that is less).
  parseBet(u, raw, g) {
    const unlimited = this.isUnlimited(u.username);
    const max = g.maxBet > 0 ? g.maxBet : 0;
    const balance = unlimited ? (max || 1000) : u.points;
    let bet;
    if (raw === undefined || raw === null || raw === '') bet = Math.min(this.eco.defaultBet, balance);
    else {
      bet = this.parseAmount(raw, balance);
      if (!Number.isFinite(bet)) return { error: `"${raw}" isn't an amount. Try a number, "all" or "half"` };
    }
    if (max && bet > max) bet = max;
    if (this.isShielded(u)) {
      // the beginner shield keeps the floor safe, so only the coins above it can be bet
      const room = Math.max(0, u.points - this.eco.shieldFloor);
      bet = Math.min(bet, this.eco.shieldMaxBet, room);
      if (bet < Math.max(1, g.minBet)) return { error: `Your beginner shield keeps ${fmt(this.eco.shieldFloor)} ${this.cur} safe. Play free: !fish, or join the group games` };
    }
    if (!unlimited && bet > u.points) return { error: `You only have ${fmt(u.points)} ${this.cur}` };
    if (bet < Math.max(1, g.minBet)) {
      return { error: u.points < g.minBet && !unlimited ? `You're out of ${this.cur}! Try !work, !daily or !fish (free)` : `Minimum bet is ${fmt(g.minBet)}` };
    }
    return { bet };
  }

  // seenOnly: only people who already chatted/joined (a duel with someone who isn't here would just hang)
  resolveTarget(arg, mentions, { seenOnly = false } = {}) {
    if (mentions && mentions.length) {
      const m = mentions[0];
      return this.store.get(m.username) || this.store.findByMention(m.nickname || '') || (seenOnly ? null : this.store.touch(m));
    }
    return arg ? this.store.findByMention(arg) : null;
  }
  targetAndAmount(args) {
    const amountArg = [...args].reverse().find(a => this.isAmount(a));
    const targetArg = args.find(a => a.startsWith('@')) || args.find(a => a !== amountArg);
    return { targetArg, amountArg };
  }

  // ---------- overlay helpers ----------
  toast(text) { this.emit('toast', { text }); }
  error(u, text) { this.emit('card', { kind: 'error', tier: 'info', user: this.pub(u), title: u.nickname, text }); }
  info(icon, title, text, extra = {}) { this.emit('card', { kind: 'info', tier: 'info', icon, title, text, ...extra }); }

  // Busy chat: every play counts, but only highlights get a card. The rest go into the summary line.
  result(game, u, data) {
    const change = data.change || 0;
    const bet = data.bet || 0;
    const e = this.eco;
    let tier = change < 0 ? 'loss' : change === 0 ? 'info' : 'small';
    if (change >= e.bigWinAt || (bet > 0 && change >= bet * 9)) tier = 'big';
    if (change >= e.megaWinAt) tier = 'mega';
    if (data.jackpot) tier = 'jackpot';
    const s = (this.tick.plays[game] ||= { n: 0, won: 0, best: 0, bestName: '' });
    s.n++;
    if (change > 0) s.won++;
    if (change > s.best) { s.best = change; s.bestName = u.nickname; }

    const now = Date.now();
    this.shown = this.shown.filter(t => now - t < 3500);
    const highlight = tier === 'big' || tier === 'mega' || tier === 'jackpot' || data.always;
    if (!highlight && this.shown.length >= Math.max(1, this.cfg.overlay.maxCards)) {
      this.tick.hidden++;
      return;
    }
    this.shown.push(now);
    this.emit('solo', { game, user: this.pub(u), tier, balance: this.bal(u), currency: this.cur, boost: change > 0 ? this.boost() : 1, ...data });
    if (tier === 'mega' || tier === 'jackpot') this.log(`🎉 ${tier.toUpperCase()}: ${u.username} +${fmt(change)} on ${game}`);
  }

  state() {
    const st = this.store.state;
    const now = Date.now();
    const r = this.rounds;
    return {
      top: this.store.top(3).map(x => ({ ...x, rank: this.rankOf(x.points) })),
      jackpot: Math.floor(st.jackpot),
      hype: Math.round(this.hype),
      boost: st.boost && now < st.boost.until ? st.boost : null,
      rain: this.rain ? { until: this.rain.until, amount: this.rain.amount, caught: this.rain.got.size } : null,
      next: r.nextInfo(),
      paused: this.paused,
      playNow: ['slots', 'gamble', 'fish', 'duel'].filter(g => this.cfg.games[g].enabled).map(g => '!' + g),
      showPlayNow: this.cfg.overlay.showPlayNow,
      currency: this.cur
    };
  }
  stateSoon() {
    if (this.stateTimer) return;
    this.stateTimer = setTimeout(() => {
      this.stateTimer = null;
      this.emit('state', this.state());
    }, 350);
  }

  // ---------- economy events ----------
  addHype(x) {
    if (!this.cfg.hype.enabled || this.rain) return;
    this.hype = Math.min(100, this.hype + x);
    if (this.hype >= 100) {
      this.hype = 0;
      this.startRain(this.eco.rainAmount, 'The hype meter is full');
    }
    this.stateSoon();
  }
  startRain(amount, why) {
    const n = Math.max(1, Math.floor(amount || this.eco.rainAmount));
    this.rain = { until: Date.now() + this.eco.rainSeconds * 1000, amount: n, got: new Set() };
    this.emit('rain', { phase: 'start', amount: n, until: this.rain.until, why, currency: this.cur });
    this.log(`🌧️ Coin rain started (${n} each, ${why})`);
    this.stateSoon();
  }
  #catchRain(u) {
    const r = this.rain;
    if (!r || Date.now() > r.until + this.cfg.rounds.graceSeconds * 1000) return;
    const k = this.key(u.username);
    if (r.got.has(k) || this.isUnlimited(u.username)) return;
    r.got.add(k);
    this.give(u, r.amount);
  }
  // Called by the host bot when it pays the loot drop: rookies under the limit get a little extra.
  rookieBoost(keys) {
    let n = 0;
    for (const k of keys) {
      const u = this.store.get(k);
      if (u && this.isRookie(u) && u.points < this.eco.rookieBelow && !this.isUnlimited(k)) { this.give(u, this.eco.rookieBoost); n++; }
    }
    if (n) this.log(`🌱 Rookie boost: +${this.eco.rookieBoost} to ${n} new player${n === 1 ? '' : 's'}`);
    return n;
  }

  handleJoin(user) { this.store.touch(user); }

  handleLike(user, count) {
    const u = this.store.touch(user);
    if (!u) return;
    const n = Math.max(1, count || 1);
    const e = this.cfg.earn;
    if (e.likesPer > 0 && e.likesReward > 0) {
      u.likeAcc = (u.likeAcc || 0) + n;
      const packs = Math.floor(u.likeAcc / e.likesPer);
      if (packs > 0) { u.likeAcc -= packs * e.likesPer; this.give(u, packs * e.likesReward); }
    }
    this.addHype(n * this.cfg.hype.perLike);
    this.#catchRain(u);
    if (!u.banned && !this.paused) this.rounds.tap(u, n); // taps count as playing
  }

  // the streamer's own account name from the settings (TikTok username, or the @handle in the YouTube channel box)
  ownName() {
    if (this.cfg.tiktokUsername) return this.cfg.tiktokUsername;
    const c = String(this.cfg.channel || '');
    return (c.match(/@([\w.\-]+)/) || [])[1] || (/^[\w.\-]+$/.test(c) ? c : '');
  }
  tapText(word = ' or tap the screen') { return this.canTap ? word : ''; }

  // YouTube: a new channel member, rewarded once per person
  handleMember(user) {
    const u = this.store.touch(user);
    const pts = this.cfg.earn.memberPoints || 0;
    if (!u || pts <= 0 || u.memberRewarded) return { user: u, points: 0 };
    u.memberRewarded = true;
    this.give(u, pts);
    this.emit('card', { kind: 'member', tier: 'big', user: this.pub(u), title: u.nickname, text: `+${fmt(pts)} ${this.cur} for becoming a member` });
    this.addHype(30);
    return { user: u, points: pts };
  }

  // YouTube: Super Chats, Super Stickers and gifted memberships
  award(user, points, { what = 'support' } = {}) {
    const u = this.store.touch(user);
    points = Math.max(0, Math.round(points || 0));
    if (!u) return { user: u, points: 0 };
    if (points > 0) {
      this.give(u, points);
      this.emit('card', { kind: 'gift', tier: points >= this.eco.bigWinAt ? 'big' : 'small', user: this.pub(u), title: u.nickname, text: `+${fmt(points)} ${this.cur} for the ${what}` });
    }
    this.addHype((points / 10) * this.cfg.hype.perGiftCoin); // same hype as a TikTok gift of the same value
    return { user: u, points };
  }

  handleFollow(user) {
    const u = this.store.touch(user);
    const pts = this.cfg.earn.followPoints;
    if (!u || pts <= 0 || u.followRewarded) return { user: u, points: 0 };
    u.followRewarded = true;
    this.give(u, pts);
    return { user: u, points: pts };
  }

  handleShare(user) {
    const u = this.store.touch(user);
    const pts = this.cfg.earn.sharePoints;
    const k = u && this.key(u.username);
    if (!u || pts <= 0 || this.sharedThisStream.has(k)) return { user: u, points: 0 };
    this.sharedThisStream.add(k); // once per stream
    this.give(u, pts);
    return { user: u, points: pts };
  }

  handleGift(user, { diamonds = 0, count = 1, giftName = 'Gift' } = {}) {
    const u = this.store.touch(user);
    if (!u) return { user: u, points: 0, coins: 0 };
    const coins = Math.max(0, diamonds) * Math.max(1, count);
    const earned = coins * this.cfg.earn.giftPointsPerDiamond;
    if (earned > 0) {
      this.give(u, earned);
      this.emit('card', { kind: 'gift', tier: earned >= this.eco.bigWinAt ? 'big' : 'small', user: this.pub(u), title: u.nickname, text: `+${fmt(earned)} ${this.cur} · ${this.cfg.earn.giftPointsPerDiamond}× the ${fmt(coins)} coin${coins === 1 ? '' : 's'} gifted (${giftName})` });
    }
    this.addHype(coins * this.cfg.hype.perGiftCoin);
    return { user: u, points: earned, coins };
  }

  // ---------- chat ----------
  aliasMap() {
    const m = {};
    for (const pair of String(this.cfg.aliases || '').split(',')) {
      const [a, b] = pair.split('=').map(x => String(x || '').trim().toLowerCase().replace(/^!/, ''));
      if (a && b) m[a] = b;
    }
    return m;
  }

  // Returns true when the message was a command this engine handled.
  handleChat(user, text, mentions = [], role = {}) {
    const u = this.store.touch(user);
    if (!u) return false;
    const k = this.key(u.username);
    if (role.isMod) this.detectedMods.add(k);
    if (role.isHost) this.detectedHost = k;
    const msg = String(text || '').trim();
    const now = Date.now();
    this.activeChat.set(k, now);

    // starter pack card on a viewer's first message
    if (!u.starter) {
      u.starter = true;
      if (now - (u.firstSeen || 0) < DAY && !this.isUnlimited(k)) {
        this.emit('card', { kind: 'welcome', tier: 'welcome', user: this.pub(u), title: u.nickname, text: `Starter pack: ${fmt(this.cfg.startingPoints)} ${this.cur}! Type !slots to play` });
      }
    }
    this.addHype(this.cfg.hype.perChat);
    this.#catchRain(u);

    const lower = msg.toLowerCase();
    if (!msg.startsWith('!')) {
      if (!u.banned && !this.paused) {
        const word = lower.replace(/[^a-z]/g, '');
        if (word === 'blue' || word === 'orange') return this.rounds.word(u, word);
        this.rounds.chat(u); // any message pulls the rope for your team
      }
      return false;
    }

    const parts = msg.slice(1).split(/\s+/).filter(Boolean);
    let cmd = (parts.shift() || '').toLowerCase();
    cmd = this.aliasMap()[cmd] || cmd;
    const args = parts;

    if (this.isStaff(k) && handleStaff(this, u, cmd, args, mentions)) return true;

    switch (cmd) {
      case 'coins': this.#coins(u, args, mentions); return true;
      case 'daily': this.#daily(u); return true;
      case 'work': this.#work(u); return true;
      case 'top': this.#top(); return true;
      case 'give': this.#give(u, args, mentions); return true;
      case 'help': if (!args.length) return false; return this.#guide(args[0]); // bare !help = the host bot's command list
      case 'odds': this.#odds(args[0]); return true;
      case 'accept': case 'decline': this.solo.duel.answer(this, u, cmd === 'accept'); return true;
    }

    const solo = Object.values(this.solo).find(g => g.commands.includes(cmd));
    const isGroupCmd = this.rounds.ownsCommand(cmd);
    if (!solo && !isGroupCmd) return false;
    if (u.banned) { this.toast(`${u.nickname} can't play games right now`); return true; }
    if (this.paused) { this.toast('Games are paused for a moment ⏸️'); return true; }

    if (solo) {
      const g = this.cfg.games[solo.id];
      if (!g.enabled) { this.toast(`${solo.name} is switched off right now`); return true; }
      if (!solo.ownCooldown) {
        const wait = this.eco.soloCooldownSec * 1000 - (now - (this.soloAt.get(k) || 0));
        if (wait > 0) { this.toast(`${u.nickname}: next game in ${Math.ceil(wait / 1000)}s`); return true; }
        this.soloAt.set(k, now);
      }
      solo.play(this, u, args, mentions);
      return true;
    }
    return this.rounds.command(u, cmd, args);
  }

  // ---------- viewer commands ----------
  #coins(u, args, mentions) {
    const target = (args[0] || mentions.length) ? this.resolveTarget(args[0], mentions) || u : u;
    if (this.isUnlimited(target.username)) {
      return this.emit('card', { kind: 'coins', tier: 'info', user: this.pub(target), title: target.nickname, text: `∞ ${this.cur} · unlimited` });
    }
    const place = this.store.top(1e6).findIndex(x => x.username === target.username) + 1;
    const bits = [`${fmt(target.points)} ${this.cur}`, this.rankOf(target.points), place ? `#${place}` : ''];
    if (this.isShielded(target)) bits.push('🛡️ beginner shield');
    if (target.dailyStreak > 1) bits.push(`🔥 day ${target.dailyStreak}`);
    this.emit('card', { kind: 'coins', tier: 'info', user: this.pub(target), title: target.nickname, text: bits.filter(Boolean).join(' · ') });
  }

  #dateKey(d = new Date()) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }
  #daily(u) {
    if (this.isUnlimited(u.username)) return this.toast(`${u.nickname}, you already have unlimited ${this.cur} 😄`);
    const today = this.#dateKey();
    if (u.dailyLast === today) return this.toast(`${u.nickname}: daily already claimed 🔥 day ${u.dailyStreak || 1}. Come back tomorrow!`);
    const y = new Date();
    y.setDate(y.getDate() - 1);
    u.dailyStreak = u.dailyLast === this.#dateKey(y) ? (u.dailyStreak || 0) + 1 : 1;
    u.dailyLast = today;
    const e = this.eco;
    const day = Math.min(u.dailyStreak, e.dailyMaxDay);
    const coins = e.dailyBase + e.dailyStreakBonus * (day - 1);
    this.give(u, coins);
    this.emit('card', { kind: 'daily', tier: 'small', user: this.pub(u), title: `Daily · day ${u.dailyStreak} 🔥`, text: `+${fmt(coins)} ${this.cur}${day < e.dailyMaxDay ? ` · tomorrow +${fmt(coins + e.dailyStreakBonus)}` : ' · max streak!'}` });
  }

  #work(u) {
    const e = this.eco;
    if (this.isUnlimited(u.username)) return;
    if (u.points >= e.workBelow) return this.toast(`${u.nickname}: !work is for players under ${fmt(e.workBelow)} ${this.cur}`);
    const wait = e.workMinutes * 60_000 - (Date.now() - (u.workAt || 0));
    if (wait > 0) return this.toast(`${u.nickname}: next !work in ${Math.ceil(wait / 60_000)} min`);
    u.workAt = Date.now();
    this.give(u, e.workAmount);
    this.emit('card', { kind: 'work', tier: 'small', user: this.pub(u), title: 'Comeback coins 💼', text: `+${fmt(e.workAmount)} ${this.cur} · back in the game!` });
  }

  #top() {
    const list = this.store.top(10).map(x => ({ ...x, rank: this.rankOf(x.points) }));
    this.emit('top', { list, currency: this.cur });
  }

  #give(u, args, mentions) {
    const { targetArg, amountArg } = this.targetAndAmount(args);
    const target = this.resolveTarget(targetArg, mentions);
    if (!target) return this.error(u, '!give: who? Use !give @name 100');
    if (this.key(target.username) === this.key(u.username)) return this.error(u, "You can't give to yourself");
    const unlimited = this.isUnlimited(u.username);
    const amount = this.parseAmount(amountArg ?? '', unlimited ? 0 : u.points);
    if (!Number.isFinite(amount) || amount <= 0) return this.error(u, '!give: add an amount, e.g. !give @name 100');
    if (!unlimited && amount > u.points) return this.error(u, `You only have ${fmt(u.points)} ${this.cur}`);
    if (this.isShielded(u) && u.points - amount < this.eco.shieldFloor) {
      return this.error(u, `Your beginner shield keeps ${fmt(this.eco.shieldFloor)} ${this.cur} safe · you can give ${fmt(Math.max(0, u.points - this.eco.shieldFloor))}`);
    }
    const fee = unlimited ? 0 : Math.floor((amount * this.eco.giveFeePercent) / 100);
    if (!unlimited) this.store.add(u.username, -amount);
    this.give(target, amount - fee);
    if (fee) { this.store.state.jackpot += fee; this.store.saveStateSoon(); } // the fee feeds the jackpot
    this.log(`🤝 ${u.username} gave ${amount} to ${target.username} (fee ${fee})`);
    this.emit('card', { kind: 'give', tier: 'small', user: this.pub(u), title: `${u.nickname} → ${target.nickname}`, text: `${fmt(amount - fee)} ${this.cur}${fee ? ` (${this.eco.giveFeePercent}% fee went to the jackpot)` : ''}` });
  }

  findGame(name) {
    const n = (this.aliasMap()[String(name || '').toLowerCase().replace(/^!/, '')] || String(name || '').toLowerCase().replace(/^!/, ''));
    return this.solo[n] || this.group[n] || Object.values({ ...this.solo, ...this.group }).find(g => g.commands.includes(n) || g.name.toLowerCase() === n) || null;
  }
  #guide(name) {
    const g = this.findGame(name);
    if (!g) return false;
    this.emit('guide', { game: g.id, name: g.name, emoji: g.emoji, steps: g.guide(this), seconds: 9 });
    return true;
  }
  #odds(name) {
    const g = this.findGame(name);
    if (!g) return this.toast('Try !odds slots, gamble, fish, duel, heist, raid, raffle or tug');
    this.emit('card', { kind: 'odds', tier: 'info', icon: g.emoji, title: `${g.name} · real odds`, lines: g.odds(this) });
  }

  // ---------- timers ----------
  #tick() {
    const now = Date.now();
    // hype drains slowly
    if (this.hype > 0) {
      this.hype = Math.max(0, this.hype - this.cfg.hype.drainPerMinute / 120);
      if (Math.round(this.hype) !== this.lastHypeShown) { this.lastHypeShown = Math.round(this.hype); this.stateSoon(); }
    }
    // coin rain end
    if (this.rain && now > this.rain.until + this.cfg.rounds.graceSeconds * 1000) {
      const r = this.rain;
      this.rain = null;
      this.emit('rain', { phase: 'end', amount: r.amount, caught: r.got.size, currency: this.cur });
      this.log(`🌧️ Coin rain over: ${r.got.size} player${r.got.size === 1 ? "" : "s"} got ${r.amount}`);
      this.stateSoon();
    }
    // boost end
    const b = this.store.state.boost;
    if (b && now >= b.until) {
      this.store.state.boost = null;
      this.store.saveStateSoon();
      this.info('⏱️', 'Boost over', 'Winnings are back to normal');
      this.stateSoon();
    }
    // busy-chat summary line, every 6 seconds
    if (!this.tickAt) this.tickAt = now;
    if (now - this.tickAt >= 6000) {
      this.tickAt = now;
      if (this.tick.hidden > 0 && this.cfg.overlay.showTicker) {
        const [id, s] = Object.entries(this.tick.plays).sort((a, b) => b[1].n - a[1].n)[0];
        const name = this.solo[id]?.name || id;
        this.emit('ticker', { text: `${s.n} played ${name} · ${s.won} won${s.best > 0 ? ` · best ${s.bestName} +${fmt(s.best)}` : ''}` });
      }
      this.tick = { plays: {}, hidden: 0 };
    }
    // forget old duel requests, old chat activity
    for (const [k, d] of this.duels) if (now > d.endsAt + this.cfg.rounds.graceSeconds * 1000) { this.duels.delete(k); this.solo.duel.expired(this, d); }
    this.rounds.tick(now);
  }

  activeChatters(windowMs) {
    const now = Date.now();
    const out = [];
    for (const [k, t] of this.activeChat) {
      if (now - t <= windowMs) out.push(k);
      else if (now - t > 3_600_000) this.activeChat.delete(k);
    }
    return out;
  }

  // state for overlays that connect mid-stream
  snapshot() {
    return { arcade: true, platform: this.platform, state: this.state(), round: this.rounds.snapshot(), overlay: this.cfg.overlay, currency: this.cur };
  }

  cancelAll() {
    this.rounds.skip('Stopped by the streamer');
    for (const d of this.duels.values()) this.solo.duel.expired(this, d);
    this.duels.clear();
  }
}
