// Group games: one at a time, in rounds, run by rounds.js. Each game is its own module:
//   { id, name, emoji, commands, hint(a), guide(a) -> 3 steps, odds(a) -> lines, create(a) -> a fresh round }
// A round has: start(now), command(u, cmd, args), word(u, w), chat(u), tap(u, n), tick(now) -> result | null, view().
// Set `this.dirty = true` whenever the overlay should redraw. See _template.js to add a new game.
import { rand, pick, fmt } from './index.js';

const names = (list, n = 14) => list.slice(0, n).map(x => x.nickname);
const grace = a => a.cfg.rounds.graceSeconds * 1000;

// ---------- HEIST ----------
function heistInfo(a) {
  const g = a.cfg.games.heist;
  const level = Math.max(1, a.store.state.heistLevel || 1);
  const places = String(g.places).split(',').map(x => x.trim()).filter(Boolean);
  const place = places[level - 1] || `Vault #${level - places.length}`;
  const chance = Math.max(g.minChance, g.startChance - g.chanceStep * (level - 1));
  const payout = Math.round((Math.min(1, 0.9 + 0.02 * (level - 1)) / (chance / 100)) * 100) / 100;
  return { level, place, chance, payout };
}

export const heist = {
  id: 'heist', name: 'Heist', emoji: '💰', commands: ['heist', 'run'],
  hint: a => `Type !heist to join (bets ${fmt(a.eco.defaultBet)})`,
  guide: a => {
    const h = heistInfo(a);
    return [`Type !heist (bets ${fmt(a.eco.defaultBet)}) or !heist 500 to join the crew`, `Target: ${h.place} · ${h.chance}% escape · pays ×${h.payout}`, 'If the ALARM rings, type !run fast!'];
  },
  odds: a => {
    const g = a.cfg.games.heist, h = heistInfo(a);
    return [`Now: ${h.place} (level ${h.level})`, `Escape chance: ${h.chance}% · pays ×${h.payout}`, `Crew bonus: +${g.crewBonusPercent}% per extra player (max +${g.crewBonusMax}%)`, `Alarm: ${g.alarmChance}% of heists · no !run = −${g.alarmPenalty}% chance`, 'Win as a crew and the next target is harder and richer'];
  },
  create: a => new HeistRound(a)
};

class HeistRound {
  constructor(a) { this.a = a; this.g = a.cfg.games.heist; this.crew = new Map(); this.ran = new Set(); this.info = heistInfo(a); }
  start(now) { this.stage = 'join'; this.startedAt = now; this.endsAt = now + this.g.joinSeconds * 1000; this.dirty = true; }
  join(u, raw) {
    const a = this.a, k = a.key(u.username);
    if (this.stage !== 'join') return a.toast(`${u.nickname}: the crew already went in. Catch the next one!`);
    if (this.crew.has(k)) return;
    const p = a.parseBet(u, raw, this.g);
    if (p.error) return a.error(u, `!heist: ${p.error}`);
    this.crew.set(k, { u, bet: p.bet });
    this.dirty = true;
  }
  command(u, cmd, args) {
    if (cmd === 'heist') this.join(u, args[0]);
    else if (cmd === 'run') this.run(u);
    return true;
  }
  run(u) {
    const k = this.a.key(u.username);
    if (this.stage === 'alarm' && this.crew.has(k) && !this.ran.has(k)) { this.ran.add(k); this.dirty = true; }
  }
  word() {}
  chat() {}
  tap(u) { this.run(u); } // joining costs coins, so only typing !heist joins; taps help the crew !run
  tick(now) {
    const g = this.g;
    if (this.stage === 'join' && now >= this.endsAt + grace(this.a)) {
      if (!this.crew.size) return { empty: true };
      this.stage = 'breakin';
      this.startedAt = now;
      this.endsAt = now + 4000;
      this.dirty = true;
    } else if (this.stage === 'breakin' && now >= this.endsAt) {
      if (Math.random() * 100 < g.alarmChance) {
        this.stage = 'alarm';
        this.alarm = true;
        this.startedAt = now;
        this.endsAt = now + g.runSeconds * 1000;
        this.dirty = true;
      } else return this.finish();
    } else if (this.stage === 'alarm' && now >= this.endsAt + grace(this.a)) return this.finish();
    return null;
  }
  finish() {
    const a = this.a, g = this.g, h = this.info;
    const bonus = Math.min(g.crewBonusMax, g.crewBonusPercent * (this.crew.size - 1));
    const escaped = [], caught = [];
    for (const [k, m] of this.crew) {
      const u = a.store.get(k);
      if (!u) continue;
      let chance = h.chance + bonus;
      if (this.alarm && !this.ran.has(k)) chance -= g.alarmPenalty;
      const bet = a.isUnlimited(k) ? m.bet : Math.min(m.bet, u.points); // they may have spent some since joining
      if (bet <= 0) continue;
      a.addBet(u, bet);
      if (Math.random() * 100 < chance) escaped.push({ ...a.pub(u), change: a.win(u, Math.floor(bet * h.payout) - bet) });
      else caught.push({ ...a.pub(u), change: -a.lose(u, bet) });
    }
    const st = a.store.state;
    const won = escaped.length * 2 >= escaped.length + caught.length && escaped.length > 0;
    st.heistLevel = Math.max(1, h.level + (won ? 1 : -1));
    a.store.saveStateSoon();
    const next = heistInfo(a);
    escaped.sort((x, y) => y.change - x.change);
    a.log(`💰 Heist at ${h.place}: ${escaped.length} escaped, ${caught.length} caught${this.alarm ? ' (alarm!)' : ''} → next: ${next.place}`);
    return { place: h.place, level: h.level, won, alarm: !!this.alarm, escaped, caught, next: next.place, nextLevel: next.level, loot: escaped.reduce((s, x) => s + x.change, 0) };
  }
  view() {
    const crew = [...this.crew.values()];
    return { stage: this.stage, endsAt: this.endsAt, startedAt: this.startedAt, ...this.info, count: crew.length, pot: crew.reduce((s, m) => s + m.bet, 0), names: names(crew.map(m => m.u)), ran: this.ran.size,
      hint: this.stage === 'join' ? `Type !heist to join` : this.stage === 'alarm' ? 'ALARM! Type !run' : 'Breaking in…' };
  }
}

// ---------- BOSS RAID ----------
const BOSSES = [['Coin Dragon', '🐉'], ['Lag Monster', '👾'], ['Yeti King', '🦍'], ['Giant Kraken', '🐙'], ['Robo Titan', '🤖'], ['Shadow Tiger', '🐯']];

export const raid = {
  id: 'raid', name: 'Boss Raid', emoji: '🐉', commands: ['attack'],
  hint: a => `Type !attack${a.tapText()}`,
  guide: a => [`Type !attack${a.tapText()} to hit the boss · it is free`, 'Once you hit, every message you send hits again!', `Beat it in ${a.cfg.games.raid.seconds}s and share the loot · most damage gets a bonus`],
  odds: a => {
    const g = a.cfg.games.raid;
    return ['Free to play, nothing to lose', `Each hit: ${g.hitMin}-${g.hitMax} damage · ${g.critChance}% chance of a ×${g.critMultiplier} critical`, `Loot: ${fmt(g.lootBase)} + ${fmt(g.lootPerPlayer)} per player, shared by damage`, `Top damage: +${g.topBonusPercent}% bonus`, `If the boss escapes you still share ${g.escapeSharePercent}%`];
  },
  create: a => new RaidRound(a)
};

class RaidRound {
  constructor(a) { this.a = a; this.g = a.cfg.games.raid; this.players = new Map(); this.total = 0; this.hits = []; this.combo = 0; this.comboAt = 0; this.best = 0; [this.boss, this.icon] = pick(BOSSES); }
  start(now) { this.stage = 'fight'; this.startedAt = now; this.endsAt = now + this.g.seconds * 1000; this.hpMax = this.g.baseHp; this.dirty = true; }
  hit(u, times = 1) {
    if (this.stage !== 'fight') return;
    const a = this.a, g = this.g, k = a.key(u.username), now = Date.now();
    let p = this.players.get(k);
    if (!p) { p = { u, dmg: 0, at: 0 }; this.players.set(k, p); this.hpMax += g.hpPerPlayer; }
    if (now - p.at < 400) return; // one hit per player per 0.4 s keeps it fair for typers and tappers
    p.at = now;
    let dmg = 0, crit = false;
    for (let i = 0; i < times; i++) {
      let d = rand(g.hitMin, g.hitMax);
      if (Math.random() * 100 < g.critChance) { d *= g.critMultiplier; crit = true; }
      dmg += d;
    }
    dmg = Math.min(dmg, this.hpMax - this.total);
    p.dmg += dmg;
    this.total += dmg;
    this.combo = now - this.comboAt < 3000 ? this.combo + 1 : 1;
    this.comboAt = now;
    this.best = Math.max(this.best, this.combo);
    if (this.hits.length < 8) this.hits.push({ name: u.nickname, dmg, crit });
    this.dirty = true;
  }
  command(u, cmd) { if (cmd === 'attack') this.hit(u); return true; }
  word() {}
  chat(u) { if (this.players.has(this.a.key(u.username))) this.hit(u); } // once you've hit, any message hits again
  tap(u, n) { this.hit(u, Math.min(Math.ceil(n / 3), 5)); }
  tick(now) {
    if (this.stage !== 'fight') return null;
    if (this.combo && now - this.comboAt >= 3000) { this.combo = 0; this.dirty = true; }
    const dead = this.players.size > 0 && this.total >= this.hpMax;
    if (!dead && now < this.endsAt) return null;
    if (!this.players.size) return { empty: true };
    const a = this.a, g = this.g;
    const list = [...this.players.values()].filter(p => p.dmg > 0).sort((x, y) => y.dmg - x.dmg);
    const full = g.lootBase + g.lootPerPlayer * this.players.size;
    const pool = dead ? full : Math.floor((full * g.escapeSharePercent) / 100);
    const sum = list.reduce((s, p) => s + p.dmg, 0) || 1;
    const out = list.map((p, i) => {
      let coins = Math.floor((pool * p.dmg) / sum);
      if (dead && i === 0) coins += Math.floor((pool * g.topBonusPercent) / 100);
      return { ...a.pub(p.u), damage: p.dmg, change: a.win(p.u, coins) };
    });
    a.log(`🐉 Boss raid: ${this.boss} ${dead ? 'defeated' : 'escaped'} · ${list.length} players · top ${out[0]?.nickname || '-'}`);
    return { boss: this.boss, icon: this.icon, won: dead, players: out, loot: out.reduce((s, x) => s + x.change, 0), bestCombo: this.best };
  }
  view() {
    const top = [...this.players.values()].sort((x, y) => y.dmg - x.dmg).slice(0, 3).map(p => ({ nickname: p.u.nickname, damage: p.dmg }));
    const hits = this.hits;
    this.hits = [];
    return { stage: this.stage, endsAt: this.endsAt, startedAt: this.startedAt, boss: this.boss, icon: this.icon, hp: Math.max(0, this.hpMax - this.total), hpMax: this.hpMax, count: this.players.size, top, hits, combo: this.combo, hint: `Type !attack${this.a.tapText()} · then keep chatting to hit` };
  }
}

// ---------- RAFFLE ----------
export const raffle = {
  id: 'raffle', name: 'Raffle', emoji: '🎟️', commands: ['join'],
  hint: a => `Type !join${a.tapText()}`,
  guide: a => [`Type !join${a.tapText()} · it is free`, 'More players = a bigger prize', `One winner takes the prize · two runner-ups get ${a.cfg.games.raffle.runnerUpPercent}% each`],
  odds: a => {
    const g = a.cfg.games.raffle;
    return ['Free to enter, one ticket each', `Prize: ${fmt(g.prizeBase)} + ${fmt(g.prizePerEntrant)} per player`, 'Everyone has the same chance: 1 in the number of players', `Two runner-ups get ${g.runnerUpPercent}% of the prize each`];
  },
  create: a => new RaffleRound(a)
};

class RaffleRound {
  constructor(a) { this.a = a; this.g = a.cfg.games.raffle; this.entries = new Map(); }
  start(now) { this.stage = 'join'; this.startedAt = now; this.endsAt = now + this.g.joinSeconds * 1000; this.dirty = true; }
  enter(u) {
    const k = this.a.key(u.username);
    if (this.stage !== 'join' || this.entries.has(k)) return;
    this.entries.set(k, u);
    this.dirty = true;
  }
  prize() { return this.g.prizeBase + this.g.prizePerEntrant * this.entries.size; }
  command(u, cmd) { if (cmd === 'join') this.enter(u); return true; }
  word() {}
  chat() {}
  tap(u) { this.enter(u); }
  tick(now) {
    if (this.stage === 'join' && now >= this.endsAt + grace(this.a)) {
      if (!this.entries.size) return { empty: true };
      this.stage = 'spin';
      this.endsAt = now + 5000;
      this.dirty = true;
    } else if (this.stage === 'spin' && now >= this.endsAt) {
      const a = this.a, pool = [...this.entries.values()], prize = this.prize();
      const draw = () => pool.splice(rand(0, pool.length - 1), 1)[0];
      const w = draw();
      const winner = { ...a.pub(w), change: a.win(w, prize) };
      const runners = [];
      while (runners.length < 2 && pool.length) {
        const r = draw();
        runners.push({ ...a.pub(r), change: a.win(r, Math.floor((prize * this.g.runnerUpPercent) / 100)) });
      }
      a.log(`🎟️ Raffle: ${winner.nickname} won ${fmt(winner.change)} (${this.entries.size} players)`);
      return { winner, runners, entrants: this.entries.size, prize, loot: winner.change + runners.reduce((s, x) => s + x.change, 0) };
    }
    return null;
  }
  view() {
    const list = [...this.entries.values()];
    return { stage: this.stage, endsAt: this.endsAt, startedAt: this.startedAt, count: list.length, prize: this.prize(), names: names(list.slice(-14)), hint: this.stage === 'join' ? `Type !join${this.a.tapText()}` : 'Drawing the winner…' };
  }
}

// ---------- TUG OF WAR ----------
export const tug = {
  id: 'tug', name: 'Tug of War', emoji: '🪢', commands: ['blue', 'orange'],
  hint: a => `Type blue or orange, then keep chatting${a.tapText(' or tapping')}`,
  guide: a => ['Type blue or orange to pick your team', `Every message${a.tapText(' and tap')} pulls the rope for your team`, `After ${a.cfg.games.tug.seconds}s the stronger team shares the prize`],
  odds: a => {
    const g = a.cfg.games.tug;
    return ['Free to play', `Prize: ${fmt(g.prizeBase)} + ${fmt(g.prizePerPlayer)} per player, shared by the winning team`, `The other team gets ${fmt(g.consolation)} each for trying`, 'The team that chats and taps more wins'];
  },
  create: a => new TugRound(a)
};

class TugRound {
  constructor(a) { this.a = a; this.g = a.cfg.games.tug; this.team = new Map(); this.power = { blue: 0, orange: 0 }; this.size = { blue: 0, orange: 0 }; }
  start(now) { this.stage = 'pull'; this.startedAt = now; this.endsAt = now + this.g.seconds * 1000; this.dirty = true; }
  join(u, t) {
    const k = this.a.key(u.username);
    if (this.stage !== 'pull') return null;
    let m = this.team.get(k);
    if (!m) {
      if (Date.now() > this.endsAt) return null;
      m = { u, t, at: 0, pulls: 0 };
      this.team.set(k, m);
      this.size[t]++;
      this.dirty = true;
    }
    return m;
  }
  pull(m, n = 1, gap = 700) {
    const now = Date.now();
    if (!m || this.stage !== 'pull' || now - m.at < gap) return;
    m.at = now;
    m.pulls += n;
    this.power[m.t] += n;
    this.dirty = true;
  }
  command(u, cmd) { this.word(u, cmd); return true; }
  word(u, w) { this.pull(this.join(u, w), 1, 0); return true; }
  chat(u) { this.pull(this.team.get(this.a.key(u.username))); }
  tap(u, n) {
    const m = this.team.get(this.a.key(u.username)) || this.join(u, this.size.blue <= this.size.orange ? 'blue' : 'orange');
    this.pull(m, Math.min(Math.ceil(n / 5), 3));
  }
  tick(now) {
    if (this.stage !== 'pull' || now < this.endsAt + grace(this.a)) return null;
    if (!this.team.size) return { empty: true };
    const a = this.a, g = this.g, { blue, orange } = this.power;
    const winner = blue === orange ? (Math.random() < 0.5 ? 'blue' : 'orange') : blue > orange ? 'blue' : 'orange';
    const all = [...this.team.values()];
    const winners = all.filter(m => m.t === winner), losers = all.filter(m => m.t !== winner);
    const prize = g.prizeBase + g.prizePerPlayer * all.length;
    const each = winners.length ? Math.floor(prize / winners.length) : 0;
    const paid = winners.sort((x, y) => y.pulls - x.pulls).map(m => ({ ...a.pub(m.u), pulls: m.pulls, change: a.win(m.u, each) }));
    for (const m of losers) a.win(m.u, g.consolation, { boosted: false });
    a.log(`🪢 Tug of war: ${winner} won ${blue}-${orange} · ${winners.length} winners got ${each} each`);
    return { winner, power: this.power, size: this.size, each: paid[0]?.change || each, winners: paid, consolation: losers.length ? g.consolation : 0, losers: losers.length, tie: blue === orange, loot: paid.reduce((s, x) => s + x.change, 0) };
  }
  view() {
    return { stage: this.stage, endsAt: this.endsAt, startedAt: this.startedAt, power: this.power, size: this.size, count: this.team.size, prize: this.g.prizeBase + this.g.prizePerPlayer * this.team.size, hint: `Type blue or orange, then keep chatting${this.a.tapText(' or tapping')}` };
  }
}

export const GROUP_GAMES = [heist, raid, raffle, tug];
