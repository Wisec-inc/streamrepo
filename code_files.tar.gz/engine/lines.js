// Everything the host bot says. {names}, {name}, {streamer}, {points}, {currency}, {gift}, {streak}, {count}, {winners}
// are filled in automatically. Add or edit lines freely — one is picked at random each time.

export const LINES = {
  welcomeNew: [
    'Welcome to the stream, {names}! 👋 So happy you\'re here. Type !help to play',
    'Hey {names}! 🎉 Welcome in, grab a seat and say hi!',
    '{names} just arrived! 🙌 Welcome, make yourself at home 💛',
    'A warm welcome to {names}! ✨ You got {start} free {currency} to play with. Try !help',
    'Welcome, {names}! 😊 This is a chill, friendly place. Chat away!'
  ],
  welcomeBack: [
    'Welcome back, {names}! 💛 So good to see you again',
    '{names} is back! 🔥 We missed you',
    'Look who\'s here! Welcome back, {names} 🙌',
    'Hey {names}, welcome back! 😊 Don\'t forget your !daily coins'
  ],
  welcomeGroup: [
    'Welcome {names}! 👋 So glad you\'re all here 💛',
    'Hi {names}! 🎉 The more the merrier. Say hi in chat!',
    'Big welcome to {names}! 🙌 Type !help to join the games'
  ],
  follow: [
    'Welcome to the membership, {names}! ⭐ Thank you so much (+{points} {currency})',
    '{names} just became a member! 🎉 You\'re amazing. +{points} {currency}',
    'A new member! Thank you {names} for supporting {streamer} ⭐ +{points} {currency}'
  ],
  followGroup: [
    'Welcome to the membership, {names}! ⭐ +{points} {currency} each',
    'So many new members! {names}, thank you all 🎉 +{points} {currency} each'
  ],
  share: [
    'Thanks for sharing the stream, {names}! 🔁'
  ],
  gift: [
    'Thank you so much {name} for the {gift}! 💛 +{points} {currency}',
    '{name}, thank you for the {gift}! 🙏 You\'re amazing. +{points} {currency}',
    'WOW, {gift} from {name}! 🎉 Thank you! +{points} {currency}',
    '{name} with the {gift}! 💛 That means a lot (+{points} {currency})'
  ],
  goodbye: [
    'Bye {name}! 👋 Thanks for hanging out. See you next stream 💛',
    'Take care, {name}! 🌙 Come back soon',
    'See you later, {name}! 🙌 Thanks for the good vibes',
    'Goodbye {name}! 💛 It was great having you here',
    'Catch you next time, {name}! ✨ Stay awesome'
  ],
  goodnight: [
    'Goodnight {name} 🌙 Sleep well and come back soon!',
    'Sweet dreams, {name}! 😴💛 Thanks for watching',
    'Night night {name} 🌙 See you next stream!'
  ],
  memberMilestone: [
    '{name}, {months} as a member! ⭐ Thank you so much 💛',
    'Huge thanks to {name} for {months} of membership! 🎉'
  ],
  viewerDrop: [
    'Thank you to everyone who stopped by 💛 You\'re welcome back anytime!',
    'To everyone heading out, thanks for watching 🙏 See you next time!',
    'Thanks for spending time here, everyone 💛 Safe travels and see you soon!'
  ],
  nudgeLike: [
    'Enjoying the stream? Hit the 👍 like button, it really helps {streamer} reach more people!',
    'If you\'re having fun, smash that 👍 like! Thank you, everyone 💛',
    'A quick 👍 on the stream helps a lot. Thanks for the likes, everyone!'
  ],
  nudgeShare: [
    'Know someone who\'d love this? Share the stream with them 🔁',
    'Sharing is caring 💛 Send this stream to a friend who\'d enjoy it!'
  ],
  nudgeFollow: [
    'Not subscribed yet? Hit subscribe and the 🔔 so you never miss a stream 💛',
    'Enjoying the vibes? Subscribe to {streamer} for more streams like this 🔔'
  ],
  nudgeHelp: [
    'New here? Type !help to see all the games 🎮',
    'Want to play? Just type !slots or !fish 🎰 Type !help for everything'
  ],
  nudgeDaily: [
    'Free {currency} every day: type !daily 🔥 Your streak grows each day you come back!',
    'Have you claimed your !daily {currency} yet? 🔥 Don\'t break the streak!'
  ],
  nudgeAsk: [
    'Got a question? Type !ask and anything you want to know 🤔',
    'Curious about something? !ask me anything, I\'ll look it up 🔎'
  ],
  nudgeChat: [
    'Chatting earns +{bonus} {currency} every {minutes} minutes 💸 Keep the vibes going!',
    'This chat is the best part of the stream 💛 Keep talking, it earns you {currency} too!'
  ],
  focus: [
    '{streamer} is locked in on this round 🎮 Every message gets read right after. Thank you for your patience 🙏',
    'Big focus moment! 😤 Keep chatting, {streamer} loves reading your messages and will catch up soon 💛',
    '{streamer} might be quiet for a bit, but your messages mean a lot 🙏 Try !slots or !fish while you wait!',
    'Thanks for hanging out, everyone 💛 {streamer} will be back on chat in a moment',
    'Quick focus break for {streamer} 🎮 You\'re honestly the best chat, thank you for being so patient 🙌',
    'Shh… focus mode 🤫🎮 {streamer} sees you all and appreciates every one of you 💛'
  ],
  focusStart: [
    '{streamer} is going into focus mode 🎮 Chat freely, everything will be read after this round 💛'
  ],
  focusEnd: [
    '{streamer} is back on chat! 🙌 Say hi and drop your questions!',
    'And {streamer} is back! 💛 Thank you all for waiting so patiently'
  ],
  busy: [
    'Chat is on fire today 🔥 {streamer} is reading as fast as possible. Thank you for your patience 💛',
    'So many lovely messages! 🙏 {streamer} might miss a few, but every one of you is appreciated 💛',
    'Wow, this chat is busy! 😄 Thanks for being here, everyone. You make this stream special 💛'
  ],
  uplift: [
    'This chat runs on good vibes only 💛 Thank you for keeping it kind, everyone!',
    'Every great community is built by kind people, and that\'s all of you 🙌',
    'Spread love, not hate 🌸 You all make this stream amazing',
    'Kindness is free and it looks good on everyone 😊',
    'We lift each other up here 🚀 Thanks for being awesome, chat!',
    'Be the reason someone smiles today 😊💛',
    'Positive vibes only! ✨ Thank you to everyone making this a happy place'
  ],
  bonusMany: [
    '💸 Loot drop! +{points} {currency} to {count} active chatters. Keep chatting to earn more',
    '💸 Chat bonus! {count} chatters just got +{points} {currency} each. Keep it going!'
  ],
  bonusOne: [
    '💸 +{points} {currency} to {names} for chatting! Keep it up'
  ],
  daily: [
    '🔥 {name} claimed {points} daily {currency}! Day {streak} streak',
    '{name} grabbed their daily {points} {currency} 🔥 Streak: {streak} day{s}!'
  ],
  dropStart: [
    '🎁 COIN DROP! First {winners} to type !claim get {points} {currency}! Go go go!',
    '🎁 Surprise drop! Type !claim now. {winners} lucky viewers get {points} {currency}!'
  ],
  dropEnd: [
    'Drop over! 🎉 {names} grabbed the {currency}. Next drop soon 👀',
    'That was fast! 🎉 Congrats {names}! Stay tuned for the next drop 👀'
  ],
  dropEmpty: [
    'Nobody claimed the drop this time 👀 Next one, be quick!'
  ],
  askSkip: [
    'Let\'s keep questions fun and friendly 😊 Try asking something else!',
    'Hmm, I\'ll pass on that one 😊 Ask me something else!'
  ]
};
