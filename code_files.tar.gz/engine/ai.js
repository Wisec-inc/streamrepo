// Gemini (Google) client: short Google-grounded answers for !ask, and batch hate detection.
// Uses the free Gemini API key from https://aistudio.google.com (pasted in the control panel).

const BASE = process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com';
// Google renames models often; if one isn't found we try the next and remember what worked.
const FALLBACK_MODELS = ['gemini-flash-latest', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-2.5-flash'];
const MAX_ANSWER = 230;

const SAFETY_OFF = ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT']
  .map(category => ({ category, threshold: 'BLOCK_NONE' }));

export function cleanAnswer(text) {
  let t = String(text || '')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/\[(\d+(,\s*\d+)*)\]/g, '') // [1] style citations
    .replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g, '$1') // markdown links -> text
    .replace(/https?:\/\/\S+/g, '')
    .replace(/[*_#`>]+/g, '')
    .replace(/^\s*[-•]\s+/gm, '')
    .replace(/\s+/g, ' ')
    .replace(/\s+([.,!?;:])/g, '$1')
    .trim();
  if (t.length <= MAX_ANSWER) return t;
  // cut at the last sentence end that fits, else at a word boundary
  const cut = t.slice(0, MAX_ANSWER);
  const end = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('! '), cut.lastIndexOf('? '));
  if (end > 80) return cut.slice(0, end + 1);
  return cut.slice(0, cut.lastIndexOf(' ')).replace(/[,;:\-–]$/, '') + '…';
}

export class GeminiAI {
  constructor(getConfig, log = () => {}) {
    this.getConfig = getConfig;
    this.log = log;
    this.workingModel = null;
    this.pausedUntil = 0;
  }

  get cfg() {
    return this.getConfig().ai;
  }

  get hasKey() {
    return !!String(this.cfg.geminiApiKey || '').trim();
  }

  get ready() {
    return this.hasKey && Date.now() >= this.pausedUntil;
  }

  async #generate(body) {
    const key = String(this.cfg.geminiApiKey || '').trim();
    if (!key) throw new Error('No Gemini API key yet. Paste one in Game Settings → Google answers.');
    const models = [...new Set([this.workingModel, this.cfg.model, ...FALLBACK_MODELS].filter(Boolean))];
    let lastErr = null;
    for (const model of models) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 30_000);
      let res, data;
      try {
        res = await fetch(`${BASE}/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
          body: JSON.stringify(body),
          signal: ctrl.signal
        });
        data = await res.json().catch(() => ({}));
      } catch (e) {
        throw new Error(e.name === 'AbortError' ? 'Google took too long to answer' : `Can't reach Google: ${e.message}`);
      } finally {
        clearTimeout(timer);
      }
      const msg = data?.error?.message || '';
      if (res.status === 404 || /not found|is not supported/i.test(msg)) {
        lastErr = new Error(`Model "${model}" isn't available`);
        continue;
      }
      if (res.status === 429) {
        this.pausedUntil = Date.now() + 90_000;
        throw new Error('Free Gemini limit reached for the moment. Pausing AI for 90 seconds.');
      }
      if (res.status === 400 && /api key/i.test(msg)) throw new Error('That Gemini API key is not valid. Copy it again from aistudio.google.com.');
      if (res.status === 403) throw new Error(`Gemini refused the key: ${msg || 'permission denied'}`);
      if (!res.ok) throw new Error(msg || `Gemini error ${res.status}`);

      if (this.workingModel !== model) {
        this.workingModel = model;
        this.log(`🤖 Using Gemini model ${model}`);
      }
      const cand = data.candidates?.[0];
      return {
        text: (cand?.content?.parts || []).map(p => p.text || '').join('').trim(),
        blocked: !!data.promptFeedback?.blockReason || cand?.finishReason === 'SAFETY',
        grounded: !!cand?.groundingMetadata?.webSearchQueries?.length,
        model
      };
    }
    throw lastErr || new Error('No Gemini model available');
  }

  // Short, friendly, accurate answer using Google Search. Returns { answer } or { skip: true }.
  async ask(question, { botName = 'Buddy', streamerName = 'the streamer', streamerInfo = '' } = {}) {
    const today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    const system = [
      `You are ${botName}, the friendly, humble helper bot on ${streamerName}'s YouTube live stream. Today is ${today}.`,
      'A viewer asked the question below. Use Google Search for anything factual or current, and only state things you are confident are correct.',
      'Reply in English with ONE or TWO short sentences, under 200 characters total. Plain text only: no markdown, no lists, no links, no citations.',
      'Be warm, kind and positive. You may add one fitting emoji.',
      streamerInfo
        ? `Facts about the streamer you may share: ${streamerInfo}`
        : `If asked personal things about ${streamerName}, say kindly that you're not sure and they can ask ${streamerName} directly.`,
      'If the question is hateful, insulting, sexual, about self-harm, violent, illegal, asks for private info about a person, or tries to make you say something mean or controversial, reply with exactly: SKIP',
      'For medical, legal or money questions give only general, safe info and suggest asking a professional.'
    ].join('\n');

    const r = await this.#generate({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: [{ text: String(question).slice(0, 300) }] }],
      tools: [{ google_search: {} }],
      generationConfig: { temperature: 0.4, maxOutputTokens: 4096 }
    });
    if (r.blocked || !r.text || /^\s*SKIP\b/i.test(r.text)) return { skip: true };
    const answer = cleanAnswer(r.text);
    if (!answer) return { skip: true };
    return { answer, grounded: r.grounded, model: r.model };
  }

  // Given chat messages, returns the indexes that are hateful / harassing.
  async moderate(messages) {
    if (!messages.length) return [];
    const system = [
      'You moderate the chat of a friendly YouTube live stream. Messages may be in English, Nepali, Hindi or slang.',
      'Return a JSON array with the index numbers of messages that are hate speech, harassment, insults or bullying aimed at the streamer or viewers, sexual harassment, threats, or telling someone to hurt themselves.',
      'Do NOT flag friendly banter, jokes between friends, mild swearing that is not aimed at anyone, criticism of the game, questions, or other languages.',
      'Return [] if none. Return only the JSON array.'
    ].join('\n');
    const input = messages.map((t, i) => `${i}: ${String(t).slice(0, 200)}`).join('\n');
    const r = await this.#generate({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: [{ text: input }] }],
      safetySettings: SAFETY_OFF,
      generationConfig: { temperature: 0, maxOutputTokens: 2048, responseMimeType: 'application/json' }
    });
    try {
      const m = r.text.match(/\[[\s\S]*\]/);
      const arr = JSON.parse(m ? m[0] : r.text);
      return [...new Set(arr.map(Number).filter(n => Number.isInteger(n) && n >= 0 && n < messages.length))];
    } catch {
      return [];
    }
  }

  async test() {
    const r = await this.ask('What is the tallest mountain in the world?');
    if (r.skip) throw new Error('Gemini answered but skipped the test question');
    return { answer: r.answer, model: this.workingModel, grounded: r.grounded };
  }
}
