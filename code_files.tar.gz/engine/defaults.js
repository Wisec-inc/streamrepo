// Default settings. The control panel edits a copy saved in data/config.json.
// Anything missing from data/config.json is filled in from here on startup.

export const CONFIG_VERSION = 3;

export const DEFAULT_CONFIG = {
  version: CONFIG_VERSION,
  channel: '',
  autoReconnect: true,
  connectionMode: 'browser', // 'browser' = this PC's own Chrome/Edge reading YouTube's pop-out chat · 'service' = direct, no window

  currencyName: 'Coins',
  startingPoints: 500,

  staff: {
    streamerUnlimited: true,
    modsUnlimited: false,
    modsCanDonate: true,
    modsCanTake: false,
    moderators: '',
    donateMax: 0,
    modDailyCap: 10000,
    takeMaxPercent: 20
  },

  // Used by the host bot (loot drop = active chatter bonus) and by the arcade.
  earn: {
    activeBonusPoints: 25,
    activeBonusMinutes: 10,
    memberPoints: 1000, // new channel member (once per person)
    giftedMembershipPoints: 500, // per membership gifted
    superChatPointsPerDollar: 750, // Super Chat / Super Sticker, any currency converted approximately (same value as TikTok's 10×)
    joinPoints: 0
  },

  economy: {
    defaultBet: 100,
    soloCooldownSec: 5,
    shieldHours: 3,
    shieldMaxBet: 200,
    shieldFloor: 100,
    dailyBase: 250,
    dailyStreakBonus: 50,
    dailyMaxDay: 7,
    workAmount: 50,
    workMinutes: 5,
    workBelow: 100,
    rookieDays: 7,
    rookieBelow: 500,
    rookieBoost: 100,
    jackpotStart: 5000,
    jackpotPercent: 1,
    giveFeePercent: 5,
    rainAmount: 50,
    rainSeconds: 30,
    bigWinAt: 1000,
    megaWinAt: 10000
  },

  hype: {
    enabled: true,
    perChat: 1,
    perLike: 0.05,
    perGiftCoin: 1,
    drainPerMinute: 10
  },

  ranks: 'Bronze=0, Silver=5000, Gold=25000, Diamond=100000',
  aliases: 'paisa=coins, bal=coins, me=coins, points=coins, balance=coins, khel=slots, spin=slots, slot=slots, hit=attack, lb=top, leaderboard=top, bet=gamble, g=gamble, rob=heist, fight=duel, deny=decline, no=decline, yes=accept',

  host: {
    botName: 'Buddy',
    streamerName: '',
    welcomes: true,
    welcomeBatchSec: 10,
    giftThanks: true,
    goodbyes: true,
    viewerDropThanks: true,
    nudgeMinutes: 10,
    focusMessageMinutes: 4,
    busyChatMessages: true
  },

  drops: {
    enabled: true,
    everyMinutes: 15,
    points: 50,
    winners: 5,
    claimSeconds: 60
  },

  ai: {
    geminiApiKey: '',
    model: 'gemini-flash-latest',
    askEnabled: true,
    askCooldownSec: 120,
    aiModeration: true,
    moderationIntervalSec: 30,
    streamerInfo: ''
  },

  moderation: {
    upliftMessages: true,
    blockedWords: ''
  },

  // Group games run in rounds. 0 means "no limit" for every limit.
  rounds: {
    autopilot: true,
    mode: 'auto', // 'auto' = random, or 'heist' | 'raid' | 'raffle' | 'tug' to always play one game
    gapSeconds: 45,
    graceSeconds: 5,
    pickerSeconds: 4,
    howtoSeconds: 6,
    resultSeconds: 9,
    activeWindowSec: 120,
    minActiveChatters: 1
  },

  games: {
    slots: {
      enabled: true,
      minBet: 10,
      maxBet: 0,
      pairMultiplier: 1.4,
      reel: [
        { symbol: '🍒', weight: 39, pays: 4 },
        { symbol: '🍋', weight: 16, pays: 5 },
        { symbol: '🍇', weight: 15, pays: 8 },
        { symbol: '🍉', weight: 12, pays: 10 },
        { symbol: '🔔', weight: 10, pays: 15 },
        { symbol: '💎', weight: 9, pays: 25 },
        { symbol: '7', weight: 7, pays: 50 }
      ]
    },
    gamble: {
      enabled: true,
      minBet: 10,
      maxBet: 0,
      winFrom: 54,
      tripleFrom: 99
    },
    fish: {
      enabled: true,
      cooldownSec: 120,
      catches: [
        { tier: 'Junk', chance: 35, coins: 5, emoji: '🥾', names: 'Old Boot, Tin Can, Seaweed, Soggy Sock' },
        { tier: 'Common', chance: 45, coins: 30, emoji: '🐟', names: 'Rohu, Sardine, Carp, Tilapia' },
        { tier: 'Rare', chance: 15, coins: 100, emoji: '🐠', names: 'Clownfish, Rainbow Trout, Snow Trout' },
        { tier: 'Epic', chance: 4, coins: 400, emoji: '🐡', names: 'Pufferfish, Golden Mahseer, Swordfish' },
        { tier: 'Legendary', chance: 0.8, coins: 2500, emoji: '🦈', names: 'Great White, Giant Catfish' },
        { tier: 'Mythic', chance: 0.2, coins: 5000, emoji: '🐉', names: 'Lake Dragon, Kraken' }
      ]
    },
    duel: {
      enabled: true,
      minBet: 10,
      maxBet: 0,
      acceptSeconds: 60
    },
    heist: {
      enabled: true,
      minBet: 10,
      maxBet: 0,
      joinSeconds: 30,
      places: 'Corner Shop, Bank, Casino, Museum, Gold Train, Space Station',
      startChance: 70,
      chanceStep: 5,
      minChance: 30,
      alarmChance: 30,
      alarmPenalty: 25,
      runSeconds: 10,
      crewBonusPercent: 1,
      crewBonusMax: 10
    },
    raid: {
      enabled: true,
      seconds: 75,
      baseHp: 400,
      hpPerPlayer: 900,
      hitMin: 20,
      hitMax: 60,
      critChance: 10,
      critMultiplier: 3,
      lootBase: 300,
      lootPerPlayer: 150,
      topBonusPercent: 20,
      escapeSharePercent: 25
    },
    raffle: {
      enabled: true,
      joinSeconds: 30,
      prizeBase: 500,
      prizePerEntrant: 40,
      runnerUpPercent: 20
    },
    tug: {
      enabled: true,
      seconds: 40,
      prizeBase: 400,
      prizePerPlayer: 60,
      consolation: 20
    }
  },

  overlay: {
    soundEffects: true,
    maxCards: 3,
    showTicker: true,
    showPlayNow: true
  }
};

export function mergeDefaults(defaults, saved) {
  if (Array.isArray(defaults)) return Array.isArray(saved) ? saved : defaults;
  if (defaults && typeof defaults === 'object') {
    const out = {};
    const src = saved && typeof saved === 'object' && !Array.isArray(saved) ? saved : {};
    for (const key of Object.keys(defaults)) out[key] = mergeDefaults(defaults[key], src[key]);
    return out;
  }
  if (saved === undefined || saved === null) return defaults;
  if (typeof defaults === 'number') {
    const n = Number(saved);
    return Number.isFinite(n) ? n : defaults;
  }
  if (typeof defaults === 'boolean') return saved === true || saved === 'true';
  return String(saved);
}
