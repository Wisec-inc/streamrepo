// Makes sourcecode.zip: everything the server needs, nothing private.
// Left out: node_modules, dist (built on the server), data folders, .env files (secrets), other zips.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { zipSync } from 'fflate';

const here = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.join(here, 'sourcecode.zip');
const SKIP_DIRS = new Set(['node_modules', 'dist', 'data', '.vercel', '.git']);
const skipFile = name => name.endsWith('.zip') || name.endsWith('.db') || /^\.baseline/.test(name) || name === '.env' || (name.startsWith('.env.') && name !== '.env.example');

const files = {};
(function walk(dir, rel) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const r = rel ? `${rel}/${e.name}` : e.name;
    if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name)) walk(path.join(dir, e.name), r); } else if (!skipFile(e.name)) files[r] = new Uint8Array(fs.readFileSync(path.join(dir, e.name)));
  }
})(here, '');

for (const must of ['package.json', 'package-lock.json', 'build.mjs', 'vps-server.mjs', 'server/router.js', 'server/tiktok-bridge/tiktok.js', 'engine/arcade/index.js', 'engine-tiktok/arcade/index.js', 'pages-src/youtube/panel.html', 'pages-src/tiktok/panel.html', 'static/index.html', 'static/admin.html', 'deploy/Caddyfile', 'deploy/stream-arcade.service', 'DEPLOY-VPS.md', 'README.md', '.env.example']) {
  if (!files[must]) throw new Error(`make-zip: ${must} is missing`);
}
for (const name of Object.keys(files)) if (/points\.json$|staff-log|(^|\/)\.env$/.test(name)) throw new Error(`make-zip: ${name} must not be in the zip`);
fs.writeFileSync(OUT, zipSync(files, { level: 9 }));
console.log(`sourcecode.zip: ${Object.keys(files).length} files, ${(fs.statSync(OUT).size / 1024).toFixed(0)} KB`);
