# Deploying Stream Arcade on a VPS: step by step

You need:

- A VPS running **Ubuntu 24.04** (or 22.04), 2 GB RAM or more, and its IP address and root password or SSH key.
- A **domain name** you can add a record to (for example `arcade.yourdomain.com`). HTTPS needs one, and OBS and
  TikTok LIVE Studio need a normal `https://` link.
- `sourcecode.zip` from this folder.

Every step ends with a **Check** so you know it worked before moving on. Replace `arcade.yourdomain.com` and
`YOUR_SERVER_IP` with your own values everywhere.

## Before you start: on your Windows PC

- **Where to type the "on your PC" commands:** open the `web` folder in File Explorer, click the address bar,
  type `cmd` and press Enter. A Command Prompt opens in that folder, next to `sourcecode.zip`.
- `ssh` and `scp` are built into Windows 10 and 11. The first time you connect, answer `yes` to the
  fingerprint question, then type the server's root password (nothing shows while you type; that is normal).
- **Pasting into the server window:** right-click pastes. Paste one block at a time and wait for it to finish.
- **Your VPS provider's firewall:** many providers (Hetzner, DigitalOcean, Vultr, AWS, Oracle…) have their own
  firewall in their website. Open ports **22, 80 and 443** there too.
- **Accounts don't move over.** The server starts empty with your admin account; create your users again there.
  Your PC's `web\data` and `.env` are never uploaded (they are not in the zip).

---

## 1. Point your domain at the server

At your domain provider, add a DNS record: type **A**, name `arcade`, value `YOUR_SERVER_IP`.

**Check** (on your own PC; it can take a few minutes to start working):

```bash
nslookup arcade.yourdomain.com
```

It should show your server's IP.

## 2. Log in and lock the door

On your PC:

```bash
ssh root@YOUR_SERVER_IP
```

Everything from here is typed on the server. Update it and allow only SSH and web traffic:

```bash
apt update && apt upgrade -y
```

```bash
apt install -y ufw unzip curl sqlite3
```

```bash
ufw allow OpenSSH && ufw allow 80 && ufw allow 443 && ufw --force enable
```

**Check:**

```bash
ufw status
```

It lists `OpenSSH`, `80` and `443` as ALLOW. (The app's own port 3000 is not opened: only Caddy talks to it.)

## 3. Install Node.js and Caddy

Node.js 24 (the app needs 22.13 or newer):

```bash
curl -fsSL https://deb.nodesource.com/setup_24.x | bash - && apt install -y nodejs
```

Caddy (the web server that adds HTTPS):

```bash
apt install -y debian-keyring debian-archive-keyring apt-transport-https
```

```bash
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
```

```bash
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
```

```bash
apt update && apt install -y caddy
```

**Check:**

```bash
node --version && caddy version
```

Node shows `v24.…` (22.13 or higher is fine) and Caddy shows a version.

## 4. Upload the app and build it

On **your PC**, in the folder that holds `sourcecode.zip`:

```bash
scp sourcecode.zip root@YOUR_SERVER_IP:/tmp/
```

Back on the **server**: make a user for the app, unpack, install and build.

```bash
useradd --system --home /opt/stream-arcade --shell /usr/sbin/nologin arcade
```

```bash
mkdir -p /opt/stream-arcade /var/lib/stream-arcade && unzip -o /tmp/sourcecode.zip -d /opt/stream-arcade
```

```bash
cd /opt/stream-arcade && npm ci && npm run build
```

**Check:** the last line starts with `Built dist/ for v3.0.0`.

## 5. Settings and your admin account

```bash
cd /opt/stream-arcade && cp .env.example .env && nano .env
```

Fill in these lines (no quotes, nothing after the value):

| Line | What to put |
|---|---|
| `PUBLIC_URL=` | `https://arcade.yourdomain.com` |
| `DATA_DIR=` | leave as `/var/lib/stream-arcade` |
| `APP_SECRET=` | a long random text. Make one in another terminal with `openssl rand -base64 48` and paste it |
| `ADMIN_USERNAME=` | your admin username |
| `ADMIN_PASSWORD=` | your admin password (8 characters or more) |

Save with **Ctrl+O, Enter**, leave with **Ctrl+X**. Then make the file private and hand the folders to the app's user:

```bash
chmod 600 .env && chown -R arcade:arcade /opt/stream-arcade /var/lib/stream-arcade
```

The password is used once, to create the account, and is stored only as a scrambled hash. After your first
sign-in you can delete the `ADMIN_PASSWORD` line from `.env`.

**Check:**

```bash
ls -l /opt/stream-arcade/.env
```

It starts with `-rw-------` and shows `arcade arcade`.

## 6. Run it as a service

```bash
cp /opt/stream-arcade/deploy/stream-arcade.service /etc/systemd/system/ && systemctl daemon-reload && systemctl enable --now stream-arcade
```

**Check:**

```bash
systemctl status stream-arcade --no-pager
```

It says `active (running)`, and the log lines include `Admin account "…" created` and `Listening on
http://127.0.0.1:3000`. One more:

```bash
curl -s http://127.0.0.1:3000/api/health
```

answers `{"ok":true,"version":"3.0.0"}`. The service restarts by itself after a crash or a reboot.

## 7. HTTPS with Caddy

```bash
nano /opt/stream-arcade/deploy/Caddyfile
```

Change `arcade.example.com` to your address, save, then:

```bash
cp /opt/stream-arcade/deploy/Caddyfile /etc/caddy/Caddyfile && systemctl reload caddy
```

Caddy fetches the certificate by itself within a minute.

**Check** (on your PC):

```bash
curl -s https://arcade.yourdomain.com/api/health
```

answers `{"ok":true,"version":"3.0.0"}`.

## 8. First sign-in

1. Open `https://arcade.yourdomain.com` and sign in with your admin username and password.
2. On the home page, **change your password** (bottom of the page).
3. Open **Admin panel**:
   - **Create an account**: pick **Paid** (optional paid-until date) or **Trial** (12 hours from their first
     sign-in, then the account and its data are deleted). Click **Make a password**, then give the person the
     username and password. The password is shown once.
   - **TikTok connection key**: paste an Euler Stream key if you will have more than a few TikTok streamers.
4. Open **YouTube Live** or **TikTok LIVE**, copy the overlay link into OBS (Browser source) or TikTok LIVE Studio
   (Link source), click **Test overlay**, then connect your channel.

**Check:** the demo cards appear on the overlay, and after reloading the overlay the demo viewers are still on
the scoreboard (saved to the database).

## 9. Backups, updates, logs

**Backup** the database every night at 03:30, keeping 14 days:

```bash
mkdir -p /var/backups/stream-arcade && (crontab -l 2>/dev/null; echo '30 3 * * * sqlite3 /var/lib/stream-arcade/arcade.db ".backup /var/backups/stream-arcade/arcade-$(date +\%F).db" && find /var/backups/stream-arcade -name "arcade-*.db" -mtime +14 -delete') | crontab -
```

Copy those files off the server now and then. To restore: stop the service, copy a backup over
`/var/lib/stream-arcade/arcade.db`, delete `arcade.db-wal` and `arcade.db-shm` if they exist, start the service.

**Update** to a new `sourcecode.zip` (your `.env` and database are not touched):

```bash
unzip -o /tmp/sourcecode.zip -d /opt/stream-arcade && cd /opt/stream-arcade && npm ci && npm run build && chown -R arcade:arcade /opt/stream-arcade && systemctl restart stream-arcade
```

Streamers' overlays reconnect by themselves after the restart; a group round in progress starts over.

**Logs:**

```bash
journalctl -u stream-arcade -f
```

## If something goes wrong

| Problem | What to do |
|---|---|
| Step 6 shows `failed` | `journalctl -u stream-arcade -n 40 --no-pager` shows the reason. "The site is not built yet" → run `npm run build` in `/opt/stream-arcade`. "No admin account yet" → fill in `ADMIN_USERNAME` / `ADMIN_PASSWORD` in `.env` and `systemctl restart stream-arcade` |
| Node says `node:sqlite` is unknown | Node is too old. Repeat step 3; `node --version` must be 22.13 or higher |
| The site doesn't open on https | Check step 1 (`nslookup`), that ports 80 and 443 are open at your VPS provider's own firewall too, then `journalctl -u caddy -n 40 --no-pager` |
| "Wrong username or password" for the admin | The account is made only on the first start. To set the password again: put the new one in `ADMIN_PASSWORD`, add the line `ADMIN_PASSWORD_RESET=1`, restart once, then remove both lines |
| Locked out after wrong passwords | Wait 15 minutes, or reset as above |
| YouTube: "asking for a bot check" | Paste the live video link instead of the handle. If it keeps happening, YouTube is limiting your server's address |
| TikTok: rate limit or sign errors | Add an Euler Stream key in the admin panel. The free allowance is shared and small |
| Overlay says the link is no longer valid | Copy the overlay link again from the control panel (it changes after **New overlay link**) |
