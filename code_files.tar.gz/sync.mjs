// Refreshes the copies of the two PC editions' game code and pages inside web/.
// It only READS from the PC editions' folders and only WRITES inside web/. Run: npm run sync
//   YouTube edition: the folder web/ sits in            (or set YOUTUBE_DIR)
//   TikTok edition:  a sibling folder "TikTok-LIVE-Chat-Games-…"   (or set TIKTOK_DIR)
// The zip already contains the copies, so this is only needed after changing a PC edition.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

export function sources() {
  const youtube = process.env.YOUTUBE_DIR || path.resolve(here, '..');
  let tiktok = process.env.TIKTOK_DIR || '';
  if (!tiktok) {
    const up = path.resolve(here, '..', '..');
    try {
      const hit = fs.readdirSync(up, { withFileTypes: true }).filter(e => e.isDirectory() && /^TikTok-LIVE-Chat-Games/i.test(e.name)).map(e => e.name).sort().at(-1); // the newest version's folder
      if (hit) tiktok = path.join(up, hit);
    } catch {}
  }
  const ok = (dir, bridge) => !!dir && fs.existsSync(path.join(dir, 'lib', 'arcade', 'index.js')) && fs.existsSync(path.join(dir, 'lib', bridge));
  return { youtube: ok(youtube, 'youtube.js') ? youtube : '', tiktok: ok(tiktok, 'tiktok.js') ? tiktok : '' };
}

// [edition, from (in that PC edition), to (inside web/)]
export const COPIES = [
  ['youtube', 'lib/arcade', 'engine/arcade'],
  ['youtube', 'lib/host.js', 'engine/host.js'],
  ['youtube', 'lib/lines.js', 'engine/lines.js'],
  ['youtube', 'lib/defaults.js', 'engine/defaults.js'],
  ['youtube', 'lib/ai.js', 'engine/ai.js'],
  ['youtube', 'lib/store.js', 'engine/store.js'],
  ['youtube', 'public/overlay.html', 'pages-src/youtube/overlay.html'],
  ['youtube', 'public/panel.html', 'pages-src/youtube/panel.html'],
  ['youtube', 'public/fonts', 'static/fonts'],
  ['youtube', 'public/icons', 'static/icons'],
  ['tiktok', 'lib/arcade', 'engine-tiktok/arcade'],
  ['tiktok', 'lib/host.js', 'engine-tiktok/host.js'],
  ['tiktok', 'lib/lines.js', 'engine-tiktok/lines.js'],
  ['tiktok', 'lib/defaults.js', 'engine-tiktok/defaults.js'],
  ['tiktok', 'lib/ai.js', 'engine-tiktok/ai.js'],
  ['tiktok', 'lib/store.js', 'engine-tiktok/store.js'],
  ['tiktok', 'lib/tiktok.js', 'server/tiktok-bridge/tiktok.js'],
  ['tiktok', 'public/overlay.html', 'pages-src/tiktok/overlay.html'],
  ['tiktok', 'public/panel.html', 'pages-src/tiktok/panel.html']
];

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const src = sources();
  for (const edition of ['youtube', 'tiktok']) {
    if (!src[edition]) { console.log(`${edition}: PC edition not found; keeping the copies that are already here.`); continue; }
    let n = 0;
    for (const [ed, from, to] of COPIES) {
      if (ed !== edition) continue;
      const a = path.join(src[edition], from);
      const b = path.join(here, to);
      fs.rmSync(b, { recursive: true, force: true });
      fs.mkdirSync(path.dirname(b), { recursive: true });
      fs.cpSync(a, b, { recursive: true });
      n += fs.statSync(a).isDirectory() ? fs.readdirSync(a, { recursive: true }).length : 1;
    }
    const version = JSON.parse(fs.readFileSync(path.join(src[edition], 'package.json'), 'utf8')).version;
    const dir = edition === 'youtube' ? 'engine' : 'engine-tiktok';
    fs.writeFileSync(path.join(here, dir, 'SOURCE.txt'), `Unchanged copies of the ${edition === 'youtube' ? 'YouTube' : 'TikTok'} PC edition v${version}. Do not edit here: edit the PC edition and run "npm run sync".\n`);
    console.log(`${edition}: copied ${n} files from v${version}.`);
  }
}
