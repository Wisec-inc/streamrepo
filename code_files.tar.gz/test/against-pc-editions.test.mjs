// Checks against the two PC editions, when their folders are found (skipped in a bare copy of web/):
//   1. the engines, pages, fonts, icons and the TikTok bridge in web/ are byte-for-byte the PC editions' files
//   2. each web host handles every panel command its server.js handles, with the same code
//   3. the web YouTube chat parser gives the same handler calls as the PC edition's handleAction()
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { parseMoney, parseTarget, actionToEvents, applyEvent, explainError } from '../shared/yt-core.js';
import { sources, COPIES } from '../sync.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const web = path.resolve(here, '..');
const src = sources();
const skipIfNo = edition => (src[edition] ? false : `the ${edition} PC edition was not found`);

const walk = dir => fs.readdirSync(dir, { withFileTypes: true }).flatMap(e => (e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]));

for (const edition of ['youtube', 'tiktok']) {
  test(`${edition}: the copies in web/ are unchanged files of the PC edition`, { skip: skipIfNo(edition) }, () => {
    let n = 0;
    for (const [ed, from, to] of COPIES) {
      if (ed !== edition) continue;
      const a = path.join(src[edition], from);
      const files = fs.statSync(a).isDirectory() ? walk(a).map(f => path.relative(a, f)) : [''];
      for (const rel of files) {
        const bPath = path.join(web, to, rel);
        assert.ok(fs.existsSync(bPath), `${to}/${rel} is missing: run "npm run sync"`);
        assert.ok(fs.readFileSync(path.join(a, rel)).equals(fs.readFileSync(bPath)), `${to}/${rel} differs from the PC edition: run "npm run sync"`);
        n++;
      }
    }
    assert.ok(n >= 14);
  });
}

// The panel commands whose code must be identical once the socket.io wrapping is taken off.
const SAME = ['simulate', 'setPoints', 'addPoints', 'addPointsMany', 'addPointsAll', 'deleteUser', 'resetPoints', 'wipePoints', 'cancelGames', 'staffCommand', 'liveState', 'startDrop', 'showHelp', 'hostSay', 'testAi', 'testOverlay'];
const HOSTS = {
  youtube: { host: 'src/engine-host.js', bridge: 'const stream = new', same: [...SAME, 'disconnectStream'] },
  tiktok: { host: 'src/engine-host-tiktok.js', bridge: 'const tiktok = ', same: [...SAME, 'disconnectTikTok'] }
};
for (const [edition, h] of Object.entries(HOSTS)) {
  test(`${edition}: the web host covers every panel command and uses the same code as server.js`, { skip: skipIfNo(edition) }, () => {
    const server = fs.readFileSync(path.join(src[edition], 'server.js'), 'utf8');
    const host = fs.readFileSync(path.join(web, h.host), 'utf8');
    const panel = fs.readFileSync(path.join(src[edition], 'public', 'panel.html'), 'utf8');

    const serverCommands = [...server.matchAll(/socket\.on\('(\w+)'/g)].map(m => m[1]).filter(c => c !== 'hello');
    const hostCommands = new Set([...host.matchAll(/\bon\('(\w+)'/g)].map(m => m[1]));
    assert.ok(serverCommands.length >= 20);
    for (const c of serverCommands) assert.ok(hostCommands.has(c), `${h.host} does not handle the panel command "${c}"`);
    for (const [, c] of panel.matchAll(/socket\.emit\('(\w+)'/g)) if (c !== 'hello') assert.ok(hostCommands.has(c), `panel.html sends "${c}" but ${h.host} does not handle it`);

    // the chat / gift / … handlers: identical text apart from indentation
    const block = (text, startMark, endMark) => {
      const a = text.indexOf(startMark);
      const b = text.indexOf(endMark, a);
      assert.ok(a >= 0 && b > a, `could not find "${startMark}" … "${endMark}"`);
      return text.slice(a, b).split('\n').map(l => l.trim()).filter(Boolean).join('\n');
    };
    assert.equal(block(host, 'const handlers = {', h.bridge), block(server, 'const handlers = {', h.bridge));

    const normalize = text => text
      .replace(/socket\.on\('(\w+)', panelOnly\(/g, "on('$1', ")
      .replace(/\)\)\);/g, '));')
      .replace(/\}\)\);/g, '});')
      .replace(/io\.to\('panel'\)\.emit\(/g, 'bus.emitPanel(')
      .replace(/io\.emit\(/g, 'bus.emitAll(')
      .split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('//')).join('\n');
    const body = (text, cmd) => {
      const oneLine = text.match(new RegExp(`^on\\('${cmd}', .*\\);$`, 'm'));
      const m = oneLine || text.match(new RegExp(`^on\\('${cmd}', [\\s\\S]*?\\n\\}\\);$`, 'm'));
      return m ? m[0] : null;
    };
    const sNorm = normalize(server);
    const hNorm = normalize(host);
    for (const cmd of h.same) {
      const s = body(sNorm, cmd);
      assert.ok(s, `could not find "${cmd}" in server.js`);
      assert.equal(body(hNorm, cmd), s, `the "${cmd}" command differs from server.js`);
    }
  });
}

test('youtube: the web chat parser makes the same handler calls as the PC edition', { skip: skipIfNo('youtube') }, async t => {
  let YouTubeBridge, local$;
  try {
    local$ = await import(pathToFileURL(path.join(src.youtube, 'lib', 'youtube.js')).href);
    YouTubeBridge = local$.YouTubeBridge;
  } catch (e) {
    return t.skip(`the PC edition's packages are not installed (${e.code || e.message})`);
  }
  const now = Date.now();
  const txt = s => ({ toString: () => s });
  const author = (name, id, extra = {}) => ({ name, id, thumbnails: [{ url: `https://img/${id}` }], badges: [], ...extra });
  const item = (type, fields) => ({ type: 'AddChatItemAction', item: { type, timestamp: now, ...fields } });
  const actions = [
    item('LiveChatTextMessage', { author: author('@viewer1', 'UC1'), message: txt('!slots 50') }),
    item('LiveChatTextMessage', { author: author('@viewer1', 'UC1'), message: txt('second message') }),
    item('LiveChatTextMessage', { author: author('@themod', 'UC2', { is_moderator: true }), message: txt('!start raid') }),
    item('LiveChatTextMessage', { author: author('@owner', 'UC3', { badges: [{ icon_type: 'OWNER' }] }), message: txt('hello chat') }),
    item('LiveChatTextMessage', { author: author('', 'UC4'), message: txt('no name, id only') }),
    item('LiveChatTextMessage', { author: null, message: txt('no author') }),
    item('LiveChatTextMessage', { author: author('@old', 'UC5'), message: txt('too old'), timestamp: now - 60_000 }),
    item('LiveChatPaidMessage', { author: author('@rich', 'UC6'), message: txt('take my money'), purchase_amount: '$10.00', header_background_color: 0xffffb300 }),
    item('LiveChatPaidMessage', { author: author('@euro', 'UC7'), message: txt(''), purchase_amount: '10,00 €' }),
    item('LiveChatPaidMessage', { author: author('@npr', 'UC8'), message: txt('namaste'), purchase_amount: 'NPR 500.00' }),
    item('LiveChatPaidSticker', { author: author('@sticker', 'UC9'), purchase_amount: '¥500', money_chip_background_color: 0xff00bfa5 }),
    item('LiveChatPaidMessage', { author: author('@odd', 'UC10'), message: txt('?'), purchase_amount: '??? 3', header_background_color: 0xffe62117 }),
    item('LiveChatMembershipItem', { author: author('@newmember', 'UC11') }),
    item('LiveChatMembershipItem', { author: author('@loyal', 'UC12'), header_primary_text: txt('Member for 6 months') }),
    item('LiveChatSponsorshipsGiftPurchaseAnnouncement', { author_external_channel_id: 'UC13', header: { author_name: txt('@gifter'), primary_text: txt('Gifted 5 memberships'), author_photo: [{ url: 'https://img/g' }] } }),
    item('LiveChatSponsorshipsGiftRedemptionAnnouncement', { author: author('@lucky', 'UC14') }),
    item('LiveChatViewerEngagementMessage', { message: txt('welcome to live chat') }),
    { type: 'RemoveChatItemAction' },
    { type: 'AddChatItemAction' }
  ];
  const recorder = () => {
    const calls = [];
    const rec = name => (...args) => calls.push([name, JSON.parse(JSON.stringify(args))]);
    return { calls, h: { chat: rec('chat'), join: rec('join'), member: rec('member'), milestone: rec('milestone'), superchat: rec('superchat'), giftMemberships: rec('giftMemberships') } };
  };

  const a = recorder();
  const bridge = new YouTubeBridge({ onStatus() {}, onLog() {}, handlers: a.h });
  bridge.connectedAt = now;
  bridge.seen = new Set();
  for (const action of actions) bridge.handleAction(action);

  const b = recorder();
  const seen = new Set();
  // as in production: the server makes events, they travel as JSON, the overlay applies them
  for (const action of actions) for (const ev of JSON.parse(JSON.stringify(actionToEvents(action, now)))) applyEvent(ev, b.h, seen);

  assert.ok(a.calls.length >= 20, `the fixtures should produce plenty of handler calls (got ${a.calls.length})`);
  assert.deepEqual(b.calls, a.calls);

  for (const s of ['$5.00', 'CA$20', '10,00 €', '₹100', 'NPR 250', '¥1,000', 'R$ 15,50', '1.234,56 €', 'zzz', '']) {
    assert.deepEqual(parseMoney(s, 0xff1565c0), local$.parseMoney(s, 0xff1565c0), `parseMoney("${s}")`);
  }
  for (const s of ['@name', 'name', 'https://www.youtube.com/@some.name/live', 'https://youtu.be/dQw4w9WgXcQ', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=1', 'https://www.youtube.com/channel/UCxxxxxxxxxxxxxxxxxxxxxx', 'UCxxxxxxxxxxxxxxxxxxxxxx', 'https://www.youtube.com/live/dQw4w9WgXcQ', '  ', '']) {
    assert.deepEqual(parseTarget(s), local$.parseTarget(s), `parseTarget("${s}")`);
  }
  for (const m of ['fetch failed', 'Live Chat is not available', 'Failed to resolve URL', 'Sign in to confirm you’re not a bot', '429 too many', 'something else']) {
    assert.deepEqual(explainError(new Error(m), '@x'), local$.explainError(new Error(m), '@x'), `explainError("${m}")`);
  }
});
