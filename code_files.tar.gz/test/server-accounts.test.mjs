// The server's accounts and data rules, end to end through server/router.js on an in-memory database:
// only an admin creates accounts · Admin / Paid / Trial · trial deleted with its data after its hours ·
// paid locked at its date · sessions · two users and two platforms kept apart · the Gemini key stays on the
// server · new overlay link cuts off the old one.
import test, { before, after, mock } from 'node:test';
import assert from 'node:assert/strict';
import * as db from '../server/db.js';
import { setAppSecret } from '../server/auth.js';
import * as accounts from '../server/accounts.js';
import { handle, hooks } from '../server/router.js';

const realFetch = globalThis.fetch;
const gemini = [];
const changed = [];
const ADMIN = { username: 'boss@site', password: 'Admin-pass-1!' };

before(() => {
  db.openDb(':memory:');
  setAppSecret('test-secret');
  hooks.userChanged = id => changed.push(id);
  assert.equal(accounts.ensureAdmin({ username: ADMIN.username, password: ADMIN.password }), 'created');
  assert.equal(accounts.ensureAdmin({ username: ADMIN.username, password: 'something else' }), 'ok', 'a restart never changes the admin password by itself');
  // Gemini is not called for real: record what the server would send it.
  globalThis.fetch = async (input, init) => {
    const u = String(input?.url || input);
    if (u.startsWith('https://generativelanguage.googleapis.com/')) {
      gemini.push({ url: u, key: new Headers(init.headers).get('x-goog-api-key') });
      return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: 'Mount Everest.' }] } }] }), { status: 200 });
    }
    return realFetch(input, init);
  };
});
after(() => {
  globalThis.fetch = realFetch;
  db.closeDb();
});

// opts: { cookie, session, method, origin }
async function api(path, body, opts = {}) {
  const headers = { 'content-type': 'application/json', host: 'site.test' };
  if (opts.cookie) headers.cookie = opts.cookie;
  if (opts.session) headers.authorization = `Bearer ${opts.session}`;
  if (opts.origin) headers.origin = opts.origin;
  const method = opts.method || (body === undefined ? 'GET' : 'POST');
  const res = await handle(new Request(`http://site.test/api/${path}`, { method, headers, body: method === 'GET' ? undefined : JSON.stringify(body ?? {}) }), { ip: opts.ip || '1.2.3.4', secure: true });
  const set = res.headers.get('set-cookie') || '';
  return { status: res.status, data: await res.json(), cookie: set.split(';')[0], setCookie: set };
}
const signIn = async (username, password) => {
  const r = await api('login', { username, password });
  assert.equal(r.status, 200, `sign in as ${username}: ${r.data.error?.message}`);
  return r.cookie;
};
const viewer = (name, points) => ({ username: name, nickname: name, avatar: '', points, firstSeen: 1, lastSeen: 2 });

test('accounts, user types, sessions and data rules', async () => {
  // ----- nothing without signing in; no way to sign up -----
  assert.equal((await api('me')).status, 401);
  assert.equal((await api('admin/users')).status, 401);
  assert.equal((await api('admin/users/create', { username: 'sneaky', password: 'password123', role: 'admin' })).status, 401);
  assert.equal((await api('signup', { username: 'x', password: 'y' })).status, 401, 'there is no sign-up route');
  assert.equal((await api('session', { platform: 'youtube' })).status, 401);
  assert.equal((await api('login', { username: ADMIN.username, password: 'wrong' })).status, 401);
  assert.equal((await api('login', { username: 'nobody', password: 'wrong' })).data.error.message, 'Wrong username or password.');

  // ----- the admin signs in -----
  const login = await api('login', ADMIN);
  assert.equal(login.data.user.role, 'admin');
  assert.match(login.setCookie, /HttpOnly/);
  assert.match(login.setCookie, /SameSite=Lax/);
  assert.match(login.setCookie, /Secure/);
  assert.ok(!JSON.stringify(login.data).includes('scrypt'), 'no password hash is ever sent');
  const admin = login.cookie;
  assert.equal((await api('login', { username: 'BOSS@SITE', password: ADMIN.password })).status, 200, 'usernames ignore upper/lower case');
  assert.equal((await api('admin/users/create', { username: 'evil', password: 'password123', role: 'paid' }, { cookie: admin, origin: 'https://evil.example' })).status, 403, 'another website cannot use the admin\'s sign-in');

  // ----- only the admin creates accounts -----
  const mk = async (username, role, extra = {}) => (await api('admin/users/create', { username, password: `${username}-pass-1`, role, ...extra }, { cookie: admin })).data;
  const paid = await mk('paula', 'paid');
  const paid2 = await mk('pedro', 'paid', { paidUntil: Date.now() + 5 * 86_400_000 });
  const trial = await mk('trudy', 'trial');
  assert.equal(paid.ok && paid2.ok && trial.ok, true);
  assert.equal((await mk('paula', 'paid')).ok, false, 'no two accounts with one username');
  assert.equal((await mk('PAULA', 'paid')).ok, false);
  assert.equal((await api('admin/users/create', { username: 'shorty', password: '123', role: 'paid' }, { cookie: admin })).status, 400, 'short passwords are refused');
  assert.equal((await api('admin/users/create', { username: 'who', password: 'password123', role: 'owner' }, { cookie: admin })).status, 400);

  const paula = await signIn('paula', 'paula-pass-1');
  for (const route of ['admin/users/create', 'admin/users/update', 'admin/users/delete', 'admin/settings']) {
    assert.equal((await api(route, { username: 'x2', password: 'password123', role: 'admin', id: trial.user.id }, { cookie: paula })).status, 403, `a paid user cannot use ${route}`);
  }
  assert.equal((await api('admin/users', undefined, { cookie: paula })).status, 403);
  const list = (await api('admin/users', undefined, { cookie: admin })).data;
  assert.deepEqual(list.users.map(u => `${u.username}:${u.role}`).sort(), ['boss@site:admin', 'paula:paid', 'pedro:paid', 'trudy:trial']);
  assert.ok(!JSON.stringify(list).includes('scrypt') && !JSON.stringify(list).includes('overlay_token'));

  // ----- panel and overlay sessions, both platforms -----
  assert.equal((await api('session', { platform: 'twitch' }, { cookie: paula })).status, 400);
  const panelYt = (await api('session', { platform: 'youtube' }, { cookie: paula })).data;
  const panelTt = (await api('session', { platform: 'tiktok' }, { cookie: paula })).data;
  assert.equal(panelYt.ok && panelTt.ok, true);
  const token = panelYt.overlayToken;
  assert.ok(token.length >= 30);
  const ovYt = (await api('session', { overlayToken: token, platform: 'youtube' })).data;
  const ovTt = (await api('session', { overlayToken: token, platform: 'tiktok' })).data;
  assert.equal((await api('session', { overlayToken: 'made-up', platform: 'youtube' })).status, 401);
  assert.equal(ovYt.overlayToken, undefined);

  // sessions can't be forged or used for the wrong thing
  const [bodyPart, mac] = ovYt.session.split('.');
  const forged = Buffer.from(JSON.stringify({ ...JSON.parse(Buffer.from(bodyPart, 'base64url').toString()), sid: trial.user.id })).toString('base64url');
  assert.equal((await api('data/load', {}, { session: `${forged}.${mac}` })).status, 401, 'a changed session is refused');
  assert.equal((await api('data/load', {}, {})).status, 401);
  assert.equal((await api('data/load', {}, { session: panelYt.session })).status, 401, 'only the overlay loads game data');
  assert.equal((await api('data/save', { wipe: true }, { session: panelYt.session })).status, 401);
  assert.equal((await api('account', { action: 'rotate' }, { session: ovYt.session })).status, 403, 'the overlay link alone cannot change the account');
  assert.equal((await api('yt/find', { input: '@x' }, { session: ovTt.session })).status, 400, 'the YouTube proxy is for YouTube sessions');
  assert.equal((await api('yt/find', { input: '@x' }, {})).status, 401);

  // ----- save and load; YouTube and TikTok are separate -----
  const empty = (await api('data/load', {}, { session: ovYt.session })).data;
  assert.deepEqual({ config: empty.config, state: empty.state, users: empty.users }, { config: null, state: {}, users: {} });
  assert.deepEqual((await api('data/save', {
    config: { version: 3, channel: '@paula', ai: { geminiApiKey: 'SHOULD-NOT-BE-STORED' } }, state: { jackpot: 5100 },
    users: { ann: viewer('Ann', 500), ben: viewer('Ben', 750), '@Cy ': viewer('Cy', 20) },
    lines: [{ file: 'staff-log.jsonl', entry: { by: 'paula', action: '!donate @ann 5' } }], backups: [{ name: 'season-backup-1.json', data: { ann: 1 } }]
  }, { session: ovYt.session })).data, { ok: true });
  await api('data/save', { config: { version: 3, tiktokUsername: 'paula_tt' }, state: { jackpot: 9 }, users: { ann: viewer('Ann', 1), tik: viewer('Tik', 2) } }, { session: ovTt.session });
  const yt = (await api('data/load', {}, { session: ovYt.session })).data;
  const tt = (await api('data/load', {}, { session: ovTt.session })).data;
  assert.deepEqual(Object.keys(yt.users).sort(), ['ann', 'ben', 'cy'], "viewer keys are stored in the game's lowercase form");
  assert.equal(yt.users.ann.points, 500);
  assert.equal(yt.config.ai.geminiApiKey, '', 'a key inside the settings is never stored');
  assert.deepEqual(Object.keys(tt.users).sort(), ['ann', 'tik']);
  assert.equal(tt.users.ann.points, 1, 'the same viewer name has separate coins on each platform');
  assert.equal(tt.state.jackpot, 9);
  assert.equal(yt.state.jackpot, 5100);
  await api('data/save', { users: { ben: viewer('Ben', 900) }, removed: ['cy'] }, { session: ovYt.session });
  await api('data/save', { wipe: true, users: { only: viewer('Only', 3) } }, { session: ovTt.session });
  assert.deepEqual(Object.keys((await api('data/load', {}, { session: ovYt.session })).data.users).sort(), ['ann', 'ben'], 'a TikTok wipe leaves the YouTube viewers alone');
  assert.deepEqual(Object.keys((await api('data/load', {}, { session: ovTt.session })).data.users), ['only']);

  // ----- another user sees and touches nothing of this -----
  const pedro = await signIn('pedro', 'pedro-pass-1');
  const pedroPanel = (await api('session', { platform: 'youtube' }, { cookie: pedro })).data;
  assert.notEqual(pedroPanel.overlayToken, token);
  const pedroOv = (await api('session', { overlayToken: pedroPanel.overlayToken, platform: 'youtube' })).data;
  assert.deepEqual((await api('data/load', {}, { session: pedroOv.session })).data.users, {});
  await api('data/save', { wipe: true, users: { zed: viewer('Zed', 2) } }, { session: pedroOv.session });
  assert.equal((await api('data/load', {}, { session: ovYt.session })).data.users.ann.points, 500, "another user's wipe does not touch these viewers");

  // ----- many viewers: saved in parts -----
  const many = Object.fromEntries(Array.from({ length: 1250 }, (_, i) => [`v${String(i).padStart(4, '0')}`, viewer(`v${i}`, i)]));
  assert.equal((await api('data/save', { users: many }, { session: ovYt.session })).status, 413, 'one request may carry at most 500 viewers');
  const entries = Object.entries(many);
  for (let i = 0; i < entries.length; i += 400) assert.equal((await api('data/save', { users: Object.fromEntries(entries.slice(i, i + 400)) }, { session: ovYt.session })).status, 200);
  assert.equal(Object.keys((await api('data/load', {}, { session: ovYt.session })).data.users).length, 1252);

  // ----- the Gemini key: saved from the panel, used by the server, never sent back -----
  assert.deepEqual((await api('account', { action: 'setKey', key: 'AIza-real-key' }, { session: panelYt.session })).data, { ok: true, hasAiKey: true });
  const stored = db.userByUsername('paula').ai_key;
  assert.ok(stored && !stored.includes('AIza-real-key'), 'the key is encrypted in the database');
  const everything = [await api('me', undefined, { cookie: paula }), await api('session', { platform: 'tiktok' }, { cookie: paula }), await api('session', { overlayToken: token, platform: 'youtube' }), await api('data/load', {}, { session: ovYt.session }), await api('admin/users', undefined, { cookie: admin })];
  assert.ok(!JSON.stringify(everything).includes('AIza-real-key'), 'no answer to a browser contains the key');
  assert.equal((await api('ai/v1beta/models/gemini-flash-latest:generateContent', { contents: [] }, { session: ovTt.session })).status, 200);
  assert.equal(gemini.at(-1).key, 'AIza-real-key', "the server adds the user's own key (one key for both platforms)");
  assert.equal((await api('ai/v1beta/models/gemini-flash-latest:generateContent', {}, { session: pedroOv.session })).status, 400, "a user without a key cannot use another user's");
  assert.equal((await api('ai/v1beta/models/gemini-flash-latest:generateContent', {}, { session: panelYt.session })).status, 403);

  // ----- import coins -----
  assert.deepEqual((await api('account', { action: 'import', users: { Old_Fan: viewer('Old_Fan', 4321), bad: 'not a viewer' } }, { session: panelTt.session })).data, { ok: true, count: 1 });
  assert.equal((await api('data/load', {}, { session: ovTt.session })).data.users.old_fan.points, 4321);

  // ----- new overlay link: the old one stops at once, for both platforms -----
  changed.length = 0;
  const rot = (await api('account', { action: 'rotate' }, { session: panelYt.session })).data;
  assert.notEqual(rot.overlayToken, token);
  assert.deepEqual(changed, [paid.user.id], 'open overlays are told to re-check');
  assert.equal((await api('session', { overlayToken: token, platform: 'youtube' })).status, 401);
  assert.equal((await api('data/load', {}, { session: ovYt.session })).status, 401);
  assert.equal((await api('data/save', { wipe: true }, { session: ovTt.session })).status, 401);
  const ovYt2 = (await api('session', { overlayToken: rot.overlayToken, platform: 'youtube' })).data;
  assert.equal(Object.keys((await api('data/load', {}, { session: ovYt2.session })).data.users).length, 1252, 'coins are kept');

  // ----- passwords -----
  assert.equal((await api('password', { current: 'wrong', next: 'new-password-1' }, { cookie: paula })).status, 401);
  const pw = await api('password', { current: 'paula-pass-1', next: 'new-password-1' }, { cookie: paula });
  assert.equal(pw.status, 200);
  assert.equal((await api('me', undefined, { cookie: paula })).status, 401, 'the old sign-in stops after a password change');
  assert.equal((await api('data/load', {}, { session: panelYt.session })).status, 401, 'and so do its panel sessions');
  assert.equal((await api('me', undefined, { cookie: pw.cookie })).status, 200);
  assert.equal((await api('login', { username: 'paula', password: 'paula-pass-1' })).status, 401);
  // five wrong passwords lock the account for a while
  for (let i = 0; i < 5; i++) await api('login', { username: 'pedro', password: 'nope' }, { ip: `9.9.9.${i}` });
  assert.equal((await api('login', { username: 'pedro', password: 'pedro-pass-1' }, { ip: '9.9.9.9' })).status, 429);
  // the admin resets it
  assert.equal((await api('admin/users/update', { id: paid2.user.id, password: 'reset-pass-12' }, { cookie: admin })).status, 200);
  assert.equal((await api('login', { username: 'pedro', password: 'reset-pass-12' }, { ip: '9.9.9.9' })).status, 200);

  // ----- admin safety rails -----
  const adminId = list.users.find(u => u.role === 'admin').id;
  assert.equal((await api('admin/users/delete', { id: adminId }, { cookie: admin })).status, 400, "an admin can't delete their own account");
  assert.equal((await api('admin/users/update', { id: adminId, role: 'paid' }, { cookie: admin })).status, 400, 'the only admin stays an admin');
  assert.equal((await api('admin/users/update', { id: adminId, disabled: true }, { cookie: admin })).status, 400);

  // ----- switched off: locked out at once, data kept -----
  await api('admin/users/update', { id: paid2.user.id, disabled: true }, { cookie: admin });
  assert.equal((await api('data/load', {}, { session: pedroOv.session })).status, 401);
  assert.equal((await api('login', { username: 'pedro', password: 'reset-pass-12' }, { ip: '8.8.8.8' })).status, 403);
  await api('admin/users/update', { id: paid2.user.id, disabled: false }, { cookie: admin });
  assert.deepEqual(Object.keys((await api('data/load', {}, { session: pedroOv.session })).data.users), ['zed']);

  // ----- server setting: the TikTok key is write-only -----
  const set = await api('admin/settings', { eulerKey: 'euler-secret-key' }, { cookie: admin });
  assert.deepEqual(set.data, { ok: true, hasEulerKey: true });
  assert.ok(!db.getSetting('eulerKey').includes('euler-secret-key'), 'stored encrypted');
  assert.ok(!JSON.stringify((await api('admin/users', undefined, { cookie: admin })).data).includes('euler-secret-key'));
});

test('paid time ends: locked, not deleted · trial time ends: deleted with all its data', async () => {
  let admin = await signIn(ADMIN.username, ADMIN.password);
  const t0 = Date.now();
  mock.timers.enable({ apis: ['Date'], now: t0 });
  try {
    const mk = async (username, role, extra = {}) => (await api('admin/users/create', { username, password: `${username}-pass-1`, role, ...extra }, { cookie: admin })).data.user;
    const pat = await mk('pat', 'paid', { paidUntil: t0 + 3 * 86_400_000 });
    const tess = await mk('tess', 'trial');
    const tim = await mk('tim', 'trial'); // never signs in

    // a trial's clock starts at the first sign-in, not when the account is made
    mock.timers.tick(30 * 3600_000);
    const tessCookie = await signIn('tess', 'tess-pass-1');
    const me = (await api('me', undefined, { cookie: tessCookie })).data.user;
    assert.equal(me.role, 'trial');
    assert.equal(me.endsAt, Date.now() + 12 * 3600_000, '12 hours from the first sign-in');
    const tessPanel = (await api('session', { platform: 'tiktok' }, { cookie: tessCookie })).data;
    const tessOv = (await api('session', { overlayToken: tessPanel.overlayToken, platform: 'tiktok' })).data;
    assert.equal((await api('data/save', { users: { fan: viewer('Fan', 10) }, state: { jackpot: 1 } }, { session: tessOv.session })).status, 200, 'a trial has everything, TikTok included');
    const tessYt = (await api('session', { overlayToken: tessPanel.overlayToken, platform: 'youtube' })).data;
    assert.equal(tessYt.ok, true, '…and YouTube');

    mock.timers.tick(11 * 3600_000 + 59 * 60_000);
    assert.deepEqual(accounts.sweepTrials(), [], 'still inside the 12 hours');
    assert.equal((await api('me', undefined, { cookie: tessCookie })).status, 200);

    mock.timers.tick(2 * 60_000); // 12 h 01 min after the first sign-in
    assert.equal((await api('session', { overlayToken: tessPanel.overlayToken, platform: 'tiktok' })).status, 401, 'the overlay link stops');
    assert.equal(db.userByUsername('tess'), null, 'the account is deleted the moment it is used after its time');
    assert.equal(db.viewerCount(tess.id), 0, 'and its viewers with it');
    assert.equal(db.loadAll(tess.id, 'tiktok').state.jackpot, undefined, 'and its game state');
    assert.equal((await api('login', { username: 'tess', password: 'tess-pass-1' })).status, 401);
    assert.equal((await api('me', undefined, { cookie: tessCookie })).status, 401);

    // the sweeper removes ended trials nobody touches, and unused ones after 7 days
    const ty = await mk('tyra', 'trial');
    await signIn('tyra', 'tyra-pass-1');
    mock.timers.tick(12 * 3600_000 + 1000);
    assert.deepEqual(accounts.sweepTrials(), [ty.id]);
    assert.ok(db.userById(tim.id), 'an unused trial is kept for a week');
    mock.timers.tick(6 * 86_400_000);
    const trudyId = db.userByUsername('trudy').id; // made in the first test and never signed in to
    assert.deepEqual(accounts.sweepTrials().sort(), [tim.id, trudyId].sort(), 'unused trial accounts go after 7 days');

    // more than 7 days have passed on the test clock: the admin's own sign-in has run out too
    assert.equal((await api('me', undefined, { cookie: admin })).status, 401, 'a sign-in lasts 7 days');
    admin = await signIn(ADMIN.username, ADMIN.password);

    // upgrading a trial to paid before it ends keeps the account
    const una = await mk('una', 'trial');
    await signIn('una', 'una-pass-1');
    await api('admin/users/update', { id: una.id, role: 'paid' }, { cookie: admin });
    mock.timers.tick(13 * 3600_000);
    assert.deepEqual(accounts.sweepTrials(), []);
    assert.equal((await api('login', { username: 'una', password: 'una-pass-1' })).status, 200);

    // paid until a date: locked afterwards, data kept, unlocked when extended
    assert.equal(accounts.accessOf(db.userById(pat.id)).reason, 'paid-ended', 'more than 3 days have passed');
    const denied = await api('login', { username: 'pat', password: 'pat-pass-1' });
    assert.equal(denied.status, 403);
    assert.match(denied.data.error.message, /paid time has ended/);
    assert.ok(db.userById(pat.id), 'a paid account is never deleted by the clock');
    await api('admin/users/update', { id: pat.id, paidUntil: Date.now() + 86_400_000 }, { cookie: admin });
    assert.equal((await api('login', { username: 'pat', password: 'pat-pass-1' })).status, 200);
    await api('admin/users/update', { id: pat.id, paidUntil: '' }, { cookie: admin });
    assert.equal(db.userById(pat.id).paid_until, null, 'an empty date means no end');

    // deleting an account removes its data
    await api('admin/users/delete', { id: pat.id }, { cookie: admin });
    assert.equal(db.userById(pat.id), null);
  } finally {
    mock.timers.reset();
  }
});
