// Does the web edition play exactly like the PC editions?
// For YouTube and for TikTok, the same scripted stream (same random numbers, same clock) is played twice through
// that platform's web host:
//   A) with the PC edition's Store on a real folder, as server.js uses it
//   B) as the browser runs it: bundled, with the Store on the in-memory file system and a backend
// Every event sent to the overlay and panel must be identical, the final coins identical, and what the backend
// received must equal what the game holds (nothing lost on the way to the database).
import test, { mock } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { build } from 'esbuild';

const here = path.dirname(fileURLToPath(import.meta.url));
const web = path.resolve(here, '..');
const START = Date.UTC(2026, 0, 15, 12, 0, 0);

function seededRandom(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

class FakeBus {
  events = [];
  commands = new Map();
  emitAll(t, p) { this.events.push(['all', t, JSON.parse(JSON.stringify(p ?? null))]); }
  emitPanel(t, p) { this.events.push(['panel', t, JSON.parse(JSON.stringify(p ?? null))]); }
  onCommand(ev, fn) { this.commands.set(ev, fn); }
  onHello(fn) { this.hello = fn; }
  run(ev, arg) { return this.commands.get(ev)(arg); }
}

const settle = async (ms, step = 250) => {
  for (let t = 0; t < ms; t += step) {
    mock.timers.tick(step);
    await new Promise(r => setImmediate(r));
  }
};

// One stream: viewers arrive, play every solo game, group rounds run, staff tools and panel buttons are used.
// `extras` adds what only that platform has (Super Chats and memberships, or likes, follows, shares and gifts).
async function playStream(bus, engine, { ownName, extras }) {
  const sim = (username, text, extra = {}) => bus.run('simulate', { kind: 'chat', username, text, ...extra });
  bus.hello('panel');
  bus.run('saveConfig', { ...engine.store.config, ...ownName, autoReconnect: false });
  for (const n of ['alice', 'bob', 'carol', 'dave', 'erin']) bus.run('simulate', { kind: 'join', username: n });
  await settle(1000);
  const lines = ['!slots', '!gamble 50', '!fish', '!daily', '!coins', '!slots all', '!gamble half', '!work', '!odds slots', '!help slots', '!top', '!help'];
  for (let i = 0; i < 60; i++) {
    sim(['alice', 'bob', 'carol', 'dave', 'erin'][i % 5], lines[i % lines.length]);
    await settle(1500);
  }
  sim('alice', '!give @bob 40');
  sim('bob', '!duel @carol 50');
  await settle(500);
  sim('carol', '!accept');
  await settle(6000);
  sim('dave', '!duel @erin 20');
  await settle(500);
  sim('erin', '!decline');
  for (const e of extras) bus.run('simulate', e);
  bus.run('simulate', { kind: 'viewers', amount: 42 });
  await settle(3000);
  for (const game of ['raffle', 'tug', 'raid', 'heist']) {
    bus.run('staffCommand', `!start ${game}`);
    await settle(12_000);
    const word = { raffle: '!join', tug: 'blue', raid: '!attack', heist: '!heist' }[game];
    for (const n of ['alice', 'bob', 'carol', 'dave']) sim(n, n === 'bob' && game === 'tug' ? 'orange' : word);
    for (let i = 0; i < 20; i++) {
      sim(['alice', 'bob', 'carol'][i % 3], `go go ${i}`);
      if (extras.some(e => e.kind === 'like')) bus.run('simulate', { kind: 'like', username: 'dave', amount: 30 }); // taps count as playing on TikTok
      await settle(4000);
    }
    await settle(40_000);
  }
  bus.run('staffCommand', '!2x 1m');
  bus.run('staffCommand', '!donate @erin 500');
  bus.run('staffCommand', '!coinrain 25');
  sim('erin', 'catching the rain');
  await settle(70_000);
  bus.run('setPoints', { username: 'dave', points: 1234 });
  bus.run('addPoints', { username: 'newbie', amount: 77 });
  bus.run('addPointsMany', { usernames: ['alice', 'bob'], amount: 10 });
  bus.run('addPointsAll', { amount: 5 });
  bus.run('deleteUser', { username: 'erin' });
  bus.run('setFocus', true);
  bus.run('hostSay', 'hello everyone');
  bus.run('startDrop');
  await settle(2000);
  sim('alice', '!claim');
  bus.run('setFocus', false);
  bus.run('staffCommand', '!resetseason');
  await settle(500);
  bus.run('staffCommand', '!confirm');
  await settle(15 * 60_000, 1000); // a quiet quarter of an hour: loot drops, nudges, autopilot
  bus.run('cancelGames');
  await settle(5000);
}

async function run(startEngine, makeStore, script) {
  mock.timers.enable({ apis: ['setTimeout', 'setInterval', 'Date'], now: START });
  const realRandom = Math.random;
  Math.random = seededRandom(20260115);
  const quiet = console.log;
  console.log = () => {};
  try {
    const bus = new FakeBus();
    const store = makeStore();
    const never = { find: async () => ({ ok: false }), poll: async () => ({ ok: false }) };
    const noLink = { onServer() {}, onState() {}, sendServer() {} };
    const engine = startEngine({ store, bus, api: never, link: noLink, ai: { hasKey: false, onServer: false }, autoConnect: false });
    await playStream(bus, engine, script);
    store.savePointsNow();
    await settle(5000);
    return { events: bus.events, users: JSON.parse(JSON.stringify(store.users)), config: JSON.parse(JSON.stringify(store.config)), state: JSON.parse(JSON.stringify(store.state)) };
  } finally {
    console.log = quiet;
    Math.random = realRandom;
    mock.timers.reset();
  }
}

const EDITIONS = {
  youtube: {
    host: 'src/engine-host.js', store: 'engine/store.js',
    script: { ownName: { channel: '@teststreamer' }, extras: [{ kind: 'superchat', username: 'alice', amount: 10 }, { kind: 'member', username: 'bob' }, { kind: 'gifts', username: 'carol', amount: 3 }] },
    kinds: ['solo', 'card', 'round', 'state', 'top', 'duel', 'rain', 'host', 'focus', 'drop', 'toast', 'guide', 'users', 'config', 'log', 'snapshot']
  },
  tiktok: {
    host: 'src/engine-host-tiktok.js', store: 'engine-tiktok/store.js',
    script: { ownName: { tiktokUsername: 'teststreamer' }, extras: [{ kind: 'like', username: 'alice', amount: 250 }, { kind: 'follow', username: 'bob' }, { kind: 'share', username: 'carol' }, { kind: 'gift', username: 'dave', amount: 99 }, { kind: 'follow', username: 'bob' }] },
    kinds: ['solo', 'card', 'round', 'state', 'top', 'duel', 'rain', 'host', 'focus', 'drop', 'toast', 'guide', 'users', 'config', 'log', 'snapshot']
  }
};

for (const [platform, ed] of Object.entries(EDITIONS)) {
  test(`${platform}: the web engine plays the same stream as the PC edition's Store, and saves all of it`, async () => {
    // A) the PC edition's Store on a real (temporary) folder
    const dirA = fs.mkdtempSync(path.join(os.tmpdir(), `arcade-parity-${platform}-`));
    const { startEngine } = await import(pathToFileURL(path.join(web, ed.host)).href);
    const { Store } = await import(pathToFileURL(path.join(web, ed.store)).href);
    const a = await run(startEngine, () => new Store(dirA), ed.script);

    // B) the browser build: same sources, node:fs → in-memory files, saved through a backend
    const out = path.join(os.tmpdir(), `arcade-parity-${platform}-${process.pid}.mjs`);
    await build({
      stdin: { contents: `export { startEngine } from './${ed.host}'; export { createStore } from './src/web-store.js'; export { Store } from './${ed.store}';`, resolveDir: web },
      outfile: out, bundle: true, format: 'esm', platform: 'neutral', logLevel: 'silent',
      alias: { 'node:fs': path.join(web, 'src', 'vfs.js'), 'node:path': path.join(web, 'src', 'vpath.js') },
      define: { 'process.env.GEMINI_BASE_URL': '"/api/ai"' }
    });
    const webBuild = await import(pathToFileURL(out).href);
    const saved = { users: {}, config: null, state: null, lines: [], backups: [] };
    const backend = {
      async save(p) {
        if (p.wipe) saved.users = {};
        if (p.config) saved.config = p.config;
        if (p.state) saved.state = p.state;
        for (const k of p.removed || []) delete saved.users[k];
        Object.assign(saved.users, p.users || {});
        saved.lines.push(...(p.lines || []));
        saved.backups.push(...(p.backups || []));
      },
      beacon() {}
    };
    const b = await run(webBuild.startEngine, () => webBuild.createStore(webBuild.Store, { config: null, state: {}, users: {} }, backend), ed.script);
    fs.rmSync(out, { force: true });

    assert.ok(a.events.length > 300, `the scripted stream should produce plenty of events (got ${a.events.length})`);
    const kinds = new Set(a.events.map(e => e[1]));
    for (const k of ed.kinds) assert.ok(kinds.has(k), `the scripted stream should exercise "${k}" events`);
    assert.equal(b.events.length, a.events.length, 'same number of events');
    for (let i = 0; i < a.events.length; i++) assert.deepEqual(b.events[i], a.events[i], `event #${i} (${a.events[i][1]}) differs`);
    assert.deepEqual(b.users, a.users, 'final coins and viewer records');
    assert.deepEqual(b.state, a.state, 'jackpot / heist level / boost');
    assert.deepEqual(b.config, a.config, 'settings');

    // nothing lost between the game and the backend
    assert.deepEqual(saved.users, b.users, 'the backend holds exactly the viewers the game holds');
    assert.deepEqual(saved.state, b.state, 'the backend holds the game state');
    assert.deepEqual(saved.config, b.config, 'the backend holds the settings');

    // …and the same as what the PC edition wrote to its folder
    const onDisk = f => JSON.parse(fs.readFileSync(path.join(dirA, f), 'utf8'));
    assert.deepEqual(saved.users, onDisk('points.json'), 'backend viewers = points.json');
    assert.deepEqual(saved.state, onDisk('state.json'), 'backend state = state.json');
    const staffLines = fs.readFileSync(path.join(dirA, 'staff-log.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l));
    assert.deepEqual(saved.lines.map(l => l.entry), staffLines, 'staff log lines');
    const backupsOnDisk = fs.readdirSync(dirA).filter(f => f.startsWith('season-backup-'));
    assert.equal(saved.backups.length, backupsOnDisk.length, 'season backups');
    assert.ok(backupsOnDisk.length >= 1, '!resetseason should have made a backup');
    assert.deepEqual(saved.backups[0].data, onDisk(backupsOnDisk[0]), 'season backup contents');
    fs.rmSync(dirA, { recursive: true, force: true });
  });
}
