// The live channel and the TikTok manager, with real WebSockets on a local port:
// pages of one account + platform hear each other and nobody else · no session, no connection ·
// a deleted account is disconnected · TikTok events reach the overlay that asked, survive an overlay reload,
// and the chat connection is closed when the overlay stays away or the account ends.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import WebSocket from 'ws';
import * as db from '../server/db.js';
import { setAppSecret, signSession, tokenVersion } from '../server/auth.js';
import * as accounts from '../server/accounts.js';
import { createHub } from '../server/hub.js';
import { createTikTokManager } from '../server/tiktok.js';

let server, hub, tiktok, port;
const bridges = [];
const wait = ms => new Promise(r => setTimeout(r, ms));

// A stand-in for the PC edition's TikTokBridge: records calls and lets the test fire events.
class FakeBridge {
  constructor(opts) { this.opts = opts; this.wanted = false; this.status = { state: 'disconnected', username: '', viewers: 0, message: 'Not connected' }; this.disconnects = 0; bridges.push(this); }
  async connect(username, options) {
    this.wanted = true;
    this.username = username;
    this.options = options;
    this.status = { state: 'connected', username, viewers: 0, message: `Live with @${username}` };
    this.opts.onStatus(this.status);
    this.opts.onLog('The connection service needs a free API key. Get one at eulerstream.com, paste it under Advanced, then press Connect. Retrying in 60s.');
  }
  async disconnect() { this.wanted = false; this.disconnects++; }
}

before(async () => {
  db.openDb(':memory:');
  setAppSecret('test-secret');
  hub = createHub({ onServerMessage: (ws, m) => tiktok.onMessage(ws, m), onClose: ws => tiktok.onClose(ws) });
  tiktok = createTikTokManager({ send: hub.send, signKey: () => 'server-euler-key', makeBridge: o => new FakeBridge(o) });
  server = http.createServer((_q, r) => r.end());
  server.on('upgrade', (req, socket, head) => hub.upgrade(req, socket, head));
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  port = server.address().port;
});
after(async () => {
  hub.close();
  await tiktok.stopAll();
  await new Promise(r => server.close(r));
  db.closeDb();
});

const user = name => accounts.createUser({ username: name, password: 'password-123', role: 'paid' });
const overlaySession = (u, p) => signSession({ sid: u.id, role: 'overlay', p, v: tokenVersion(u.overlay_token) }, 60_000).session;
const panelSession = (u, p) => signSession({ sid: u.id, role: 'panel', p, pv: u.pass_version }, 60_000).session;

function open(session) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://127.0.0.1:${port}/live?s=${encodeURIComponent(session || '')}`);
    ws.got = [];
    ws.on('message', d => ws.got.push(JSON.parse(d.toString())));
    ws.on('open', () => resolve(ws));
    ws.on('unexpected-response', (_req, res) => reject(Object.assign(new Error('refused'), { status: res.statusCode })));
    ws.on('error', reject);
  });
}
const closed = ws => new Promise(r => (ws.readyState === 3 ? r() : ws.on('close', r)));

test('pages of one account and platform hear each other, and nobody else', async () => {
  const a = user('anna');
  const b = user('bert');
  await assert.rejects(open(''), e => e.status === 401, 'no session, no connection');
  await assert.rejects(open('made.up'), e => e.status === 401);

  const aOverlay = await open(overlaySession(a, 'youtube'));
  const aPanel = await open(panelSession(a, 'youtube'));
  const aTikTok = await open(panelSession(a, 'tiktok'));
  const bPanel = await open(panelSession(b, 'youtube'));

  aPanel.send(JSON.stringify({ b: [{ k: 'cmd', ev: 'setPoints', a: { username: 'x', points: 5 } }] }));
  aOverlay.send(JSON.stringify({ b: [{ k: 'ev', t: 'status', p: { state: 'connected' } }] }));
  await wait(150);
  assert.deepEqual(aOverlay.got, [{ b: [{ k: 'cmd', ev: 'setPoints', a: { username: 'x', points: 5 } }] }]);
  assert.deepEqual(aPanel.got, [{ b: [{ k: 'ev', t: 'status', p: { state: 'connected' } }] }], 'a page does not hear itself');
  assert.deepEqual(aTikTok.got, [], "the same account's TikTok pages are a separate group");
  assert.deepEqual(bPanel.got, [], "another account hears nothing");
  assert.equal(hub.online(a.id), true);

  // an account that is deleted is disconnected, with a message for the page
  db.deleteUser(b.id);
  hub.recheck(b.id);
  await closed(bPanel);
  assert.equal(bPanel.got.at(-1).srv.t, 'kick');
  assert.equal(hub.online(b.id), false);
  assert.equal(aPanel.readyState, 1, 'other accounts stay connected');

  // a replaced overlay link disconnects the overlay but not the signed-in panel
  db.updateUser(a.id, { overlay_token: 'a-brand-new-overlay-token-0000000000' });
  hub.recheck(a.id);
  await closed(aOverlay);
  assert.equal(aPanel.readyState, 1);
  for (const ws of [aPanel, aTikTok]) ws.close();
});

test('TikTok chat reaches the overlay that asked, survives a reload, and ends with the overlay or the account', async () => {
  const u = user('tina');
  const other = user('otto');
  const overlay = await open(overlaySession(u, 'tiktok'));
  const panel = await open(panelSession(u, 'tiktok'));
  const otherOverlay = await open(overlaySession(other, 'tiktok'));
  const ytOverlay = await open(overlaySession(u, 'youtube'));
  const before = bridges.length;

  panel.send(JSON.stringify({ srv: { t: 'tt-connect', username: 'tina_live' } }));
  ytOverlay.send(JSON.stringify({ srv: { t: 'tt-connect', username: 'tina_live' } }));
  await wait(100);
  assert.equal(bridges.length, before, 'only a TikTok overlay may start a TikTok connection');

  overlay.send(JSON.stringify({ srv: { t: 'tt-connect', username: '@Tina_Live', autoReconnect: true } }));
  await wait(150);
  assert.equal(bridges.length, before + 1);
  const bridge = bridges.at(-1);
  assert.deepEqual(bridge.options, { signApiKey: 'server-euler-key', autoReconnect: true, mode: 'service' }, "the server's own key, never the browser mode");
  assert.equal(overlay.got[0].srv.t, 'tt-status');
  assert.equal(overlay.got[0].srv.status.state, 'connected');
  assert.equal(overlay.got[1].srv.t, 'tt-log');
  assert.ok(!overlay.got[1].srv.text.includes('under Advanced'), 'hints written for the PC app are reworded');

  bridge.opts.handlers.chat({ username: 'fan1', nickname: 'Fan', avatar: '' }, '!slots', [], { isMod: false, isHost: false });
  bridge.opts.handlers.gift({ username: 'fan1', nickname: 'Fan', avatar: '' }, { diamonds: 5, giftName: 'Rose', count: 2 });
  bridge.opts.handlers.like({ username: 'fan2', nickname: 'Fan2', avatar: '' }, 15);
  bridge.opts.handlers.viewers(321);
  await wait(150);
  assert.deepEqual(overlay.got.slice(2).map(m => [m.srv.ev, m.srv.args]), [
    ['chat', [{ username: 'fan1', nickname: 'Fan', avatar: '' }, '!slots', [], { isMod: false, isHost: false }]],
    ['gift', [{ username: 'fan1', nickname: 'Fan', avatar: '' }, { diamonds: 5, giftName: 'Rose', count: 2 }]],
    ['like', [{ username: 'fan2', nickname: 'Fan2', avatar: '' }, 15]],
    ['viewers', [321]]
  ]);
  assert.deepEqual(panel.got, [], 'TikTok events go to the overlay, where the engine runs');
  assert.deepEqual(otherOverlay.got, [], "another account's overlay gets nothing");

  // the overlay reloads: same chat connection, events now go to the new page
  overlay.close();
  await closed(overlay);
  const overlay2 = await open(overlaySession(db.userById(u.id), 'tiktok'));
  overlay2.send(JSON.stringify({ srv: { t: 'tt-connect', username: 'tina_live' } }));
  await wait(150);
  assert.equal(bridges.length, before + 1, 'no second TikTok connection for a reload');
  assert.equal(bridge.disconnects, 0);
  assert.equal(overlay2.got[0].srv.status.state, 'connected');
  bridge.opts.handlers.follow({ username: 'fan3', nickname: 'Fan3', avatar: '' });
  await wait(100);
  assert.equal(overlay2.got.at(-1).srv.ev, 'follow');

  // a different username: the old connection is closed and a new one made
  overlay2.send(JSON.stringify({ srv: { t: 'tt-connect', username: 'someone_else' } }));
  await wait(150);
  assert.equal(bridge.disconnects, 1);
  assert.equal(bridges.length, before + 2);

  // Disconnect from the panel's button (the overlay engine sends it)
  overlay2.send(JSON.stringify({ srv: { t: 'tt-disconnect' } }));
  await wait(150);
  assert.equal(bridges.at(-1).disconnects, 1);
  assert.equal(tiktok.has(u.id), false);

  // the account ends while connected: the chat connection is closed
  otherOverlay.send(JSON.stringify({ srv: { t: 'tt-connect', username: 'otto_live' } }));
  await wait(150);
  assert.equal(tiktok.has(other.id), true);
  await tiktok.drop(other.id);
  assert.equal(bridges.at(-1).disconnects, 1);
  assert.equal(tiktok.count(), 0);
  for (const ws of [overlay2, panel, otherOverlay, ytOverlay]) ws.close();
});
