// Stream Arcade web edition: the server. One always-on process for your VPS (or your PC for testing):
//   the site's pages (dist/), /api/..., the live channel (/live), TikTok chat connections, the database file.
// Start: npm start      Settings: .env (see .env.example)      It sits behind Caddy, which adds HTTPS.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
// .env: KEY=value lines. Values already set in the environment win.
try {
  for (const line of fs.readFileSync(path.join(here, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^(["'])(.*)\1$/, '$2');
  }
} catch {}

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '127.0.0.1'; // only this machine; Caddy is the public door
if (PORT === 4545 || PORT === 4546) throw new Error('Ports 4545 and 4546 belong to the PC editions. Pick another PORT.');
const DATA_DIR = path.resolve(here, process.env.DATA_DIR || 'data');
const SECURE = /^https:/i.test(process.env.PUBLIC_URL || '');
const dist = path.join(here, 'dist');
if (!fs.existsSync(path.join(dist, 'index.html'))) throw new Error('The site is not built yet. Run: npm run build');

const db = await import('./server/db.js');
const { setAppSecret, decryptKey } = await import('./server/auth.js');
const accounts = await import('./server/accounts.js');
const { handle, hooks } = await import('./server/router.js');
const { createHub } = await import('./server/hub.js');
const { createTikTokManager } = await import('./server/tiktok.js');

db.openDb(path.join(DATA_DIR, 'arcade.db'));
// The server secret signs sessions and encrypts saved keys. From .env, or made once and kept in the database.
let appSecret = process.env.APP_SECRET || db.getSetting('appSecret');
if (!appSecret) { appSecret = crypto.randomBytes(48).toString('base64url'); db.setSetting('appSecret', appSecret); }
setAppSecret(appSecret);

const admin = accounts.ensureAdmin();
if (admin === 'created') console.log(`  Admin account "${process.env.ADMIN_USERNAME}" created.`);
if (admin === 'reset') console.log(`  Admin password for "${process.env.ADMIN_USERNAME}" was set again. Remove ADMIN_PASSWORD_RESET from .env now.`);
if (admin === 'missing') console.log('  ⚠ No admin account yet: set ADMIN_USERNAME and ADMIN_PASSWORD in .env and restart. Nobody can sign in until then.');

let tiktok;
const hub = createHub({ onServerMessage: (ws, msg) => tiktok.onMessage(ws, msg), onClose: ws => tiktok.onClose(ws) });
tiktok = createTikTokManager({ send: hub.send, signKey: () => decryptKey(db.getSetting('eulerKey')) });
hooks.online = id => hub.online(id);
hooks.userChanged = id => {
  hub.recheck(id);
  if (!accounts.accessOf(db.userById(id)).ok) tiktok.drop(id);
};

// Trial accounts whose time is up are deleted, with their data, once a minute.
const sweep = () => {
  try {
    for (const id of accounts.sweepTrials()) { hub.recheck(id); tiktok.drop(id); console.log(`  Trial account ${id} ended and was deleted.`); }
  } catch (e) { console.error('[sweep]', e); }
};
sweep();
const sweeper = setInterval(sweep, 60_000);

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.json': 'application/json', '.txt': 'text/plain; charset=utf-8', '.png': 'image/png', '.ico': 'image/x-icon' };
const clientIp = req => String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'local';

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer'); // overlay links carry a private key: never pass them on
    if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
      const chunks = [];
      let size = 0;
      for await (const c of req) {
        size += c.length;
        if (size > 3_000_000) { res.writeHead(413, { 'content-type': 'application/json' }); return res.end('{"ok":false,"error":{"message":"That request is too large"}}'); }
        chunks.push(c);
      }
      const headers = new Headers();
      for (const [k, v] of Object.entries(req.headers)) if (typeof v === 'string') headers.set(k, v);
      const request = new Request(url, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks) });
      const out = await handle(request, { ip: clientIp(req), secure: SECURE });
      const h = {};
      out.headers.forEach((v, k) => { h[k] = v; });
      res.writeHead(out.status, h);
      return res.end(Buffer.from(await out.arrayBuffer()));
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    let rel;
    try { rel = decodeURIComponent(url.pathname); } catch { res.writeHead(400); return res.end(); }
    if (rel.endsWith('/')) rel += 'index.html';
    let file = path.join(dist, rel);
    if (file !== dist && !file.startsWith(dist + path.sep)) { res.writeHead(403); return res.end(); }
    if (!path.extname(file) && fs.existsSync(file + '.html')) file += '.html'; // clean addresses: /app → app.html
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('Not found'); }
    const ext = path.extname(file);
    const cache = ext === '.html' ? 'no-store' : /[\\/](fonts|icons)[\\/]/.test(file) ? 'public, max-age=604800' : 'public, max-age=0, must-revalidate';
    res.writeHead(200, { 'content-type': TYPES[ext] || 'application/octet-stream', 'cache-control': cache, ...(ext === '.html' ? { 'x-robots-tag': 'noindex' } : {}) });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) res.writeHead(500, { 'content-type': 'text/plain' });
    res.end('Server error');
  }
});

server.on('upgrade', (req, socket, head) => {
  if (new URL(req.url, 'http://x').pathname === '/live') return hub.upgrade(req, socket, head);
  socket.destroy();
});

server.listen(PORT, HOST, () => {
  const version = JSON.parse(fs.readFileSync(path.join(here, 'package.json'), 'utf8')).version;
  console.log(`\n  Stream Arcade web edition v${version}`);
  console.log(`  Listening on http://${HOST}:${PORT}${process.env.PUBLIC_URL ? `   public address: ${process.env.PUBLIC_URL}` : ''}`);
  console.log(`  Database: ${path.join(DATA_DIR, 'arcade.db')}   accounts: ${db.listUsers().length}\n`);
});

let stopping = false;
async function shutdown() {
  if (stopping) return;
  stopping = true;
  clearInterval(sweeper);
  hub.close();
  await Promise.race([tiktok.stopAll(), new Promise(r => setTimeout(r, 3000))]);
  server.close();
  db.closeDb();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('uncaughtException', err => console.error('💥', err?.stack || err));
process.on('unhandledRejection', err => console.error('💥', err?.stack || err));
